<template>
<view class="page-wrap">
  <view class="card profile">
    <view class="avatar">L</view>
    <view>
      <view style="font-size:32rpx;font-weight:700">Light RGBYW</view>
      <view class="muted">智能灯控用户</view>
    </view>
  </view>

  <view class="card">
    <!-- 调试日志入口：正式版隐藏（需要恢复时取消注释即可，toggleLog/log-panel 逻辑都还在） -->
    <!--
    <view class="row item" @tap="toggleLog">
      <text>调试日志</text>
      <text class="muted">{{showLog ? '收起 ∧' : (logCount ? logCount + ' 条 ∨' : 'BLE 收发日志 ∨')}}</text>
    </view>
    -->
    <view class="row item" @tap="onTapFactory">
      <text>厂商配置</text><text class="muted">产线/遥控器设置 ></text>
    </view>
    <view class="row item" @tap="toggleHelp">
      <text>帮助说明</text><text class="muted">{{showHelp ? '收起 ∧' : '使用说明 ∨'}}</text>
    </view>
    <view class="row item">
      <text>关于</text><text class="muted">V1.1.0</text>
    </view>
    <view class="row item" @tap="disconnect">
      <text>断开蓝牙</text><text class="muted">></text>
    </view>
  </view>

  <!-- 帮助说明文档（小字，可开关） -->
  <view class="card help-panel" v-if="showHelp">
    <view class="help-title">智慧世界 · 使用说明</view>
    <view class="help-sec" v-for="(sec, si) in helpDoc" :key="si">
      <view class="help-h">{{si + 1}}. {{sec.title}}</view>
      <view class="help-li" v-for="(line, li) in sec.lines" :key="li">· {{line}}</view>
    </view>
    <view class="help-foot">以上说明适用于 V1.1.0，功能以实际固件支持为准。</view>
  </view>

  <!-- 调试日志面板：入口已隐藏，面板一并隐藏（恢复入口时取消注释） -->
  <!--
  <view class="card log-panel" v-if="showLog">
    <view class="log-toolbar">
      <text class="muted">最近 {{logCount}} 条（BLE 收发）</text>
      <view class="log-btns">
        <text class="log-btn" @tap="refreshLog">刷新</text>
        <text class="log-btn" @tap="copyLog">复制</text>
        <text class="log-btn log-btn-danger" @tap="clearLog">清空</text>
      </view>
    </view>
    <scroll-view scroll-y class="log-scroll">
      <text class="log-text">{{logs || '暂无日志。连接设备并操作后，收发帧会记录在这里。'}}</text>
    </scroll-view>
  </view>
  -->
</view>
</template>

<script>
import { ble } from '@/utils/ble'
export default {
data() {
    return {
    showLog: false,
    logs: '',
    logCount: 0,
    showHelp: false,
    helpDoc: [
      {
        title: '添加与连接设备',
        lines: [
          '首页「设备」Tab 点击底部「添加新的设备」，搜索并绑定灯具。',
          '绑定后 App 会自动尝试连接；卡片显示「未连接」时，点击卡片手动连接。',
          '连接成功后卡片显示「已连接」，再点击卡片进入设备控制页。',
        ],
      },
      {
        title: '设备控制',
        lines: [
          '开关：控制灯具通电与断电。',
          '亮度：拖动滑块调节 0~100%。',
          '颜色：色环取色或调节 R/G/B 自定义颜色。',
          '色温：在冷暖之间调节，数值越大越暖。',
          '场景：内置场景模式下发，可快速切换氛围。',
          '音乐律动：开启后灯具随声音节奏变化，可选律动 1~6。',
          '拾音灵敏度：调节拾音触发音量，数值越高越灵敏。',
        ],
      },
      {
        title: '群组与群控',
        lines: [
          '首页「群组」Tab 点击「添加群组」，命名并勾选成员设备。',
          '点击群组卡片上的「一键群控」，可对全体成员统一下发开关、颜色等指令。',
          '群控仅对处于在线（已连接）状态的成员生效，离线成员会被跳过。',
        ],
      },
      {
        title: '联动（定时 / 手动）',
        lines: [
          '首页「联动」Tab 点击「添加联动」，填写名称并选择触发方式。',
          '触发方式支持「手动执行」与「定时执行」；定时又分绝对时间（每天某时刻）与相对时间（经过若干分钟/小时后执行一次）。',
          '作用目标可选单台设备或整个群组，可同时勾选多个。',
          '动作可组合开关、亮度、颜色、色温、场景、音乐律动、拾音灵敏度，未勾选的项不会下发。',
          '联动规则开关关闭后，定时任务不再执行。',
        ],
      },
      {
        title: '分享配置',
        lines: [
          '首页「分享」Tab 可将本机已绑定的设备与群组配置导出。',
          '导出后配置会复制到剪贴板，或通过系统分享发送给好友。',
        ],
      },
      {
        title: '常见问题',
        lines: [
          '搜索不到设备：确认灯具已上电并处于配网状态，手机蓝牙已打开。',
          '连接失败：靠近设备重试；确认系统已授予蓝牙与定位权限。',
          '下发无响应：先确认卡片显示「已连接」，靠近设备后重试；仍无响应可在本页「断开蓝牙」后重新连接。',
          '更换手机后设备丢失：需要通过「分享」导出的配置手动重新添加。',
        ],
      },
    ],
  }
  },

  methods: {
onTapFactory() {
    uni.navigateTo({ url: '/subpackages/factory/factory' });
  },
disconnect() {

    if (ble) ble.disconnectAll();
    uni.showToast({ title: '已断开', icon: 'none' });
  },
_logsText() {

    return (ble ? ble.getLogs() : []).join('\n\n');
  },
_refreshLogs() {

    const logs = ble ? ble.getLogs() : [];
    this.setData({ logs: logs.join('\n\n'), logCount: logs.length });
  },
toggleLog() {
    const show = !this.showLog;
    if (show) this._refreshLogs();
    this.setData({ showLog: show });
  },
toggleHelp() {
    this.setData({ showHelp: !this.showHelp });
  },
refreshLog() { this._refreshLogs(); },
copyLog() {
    const text = this.logs || '(暂无日志)';
    uni.setClipboardData({
      data: text,
      success: () => uni.showToast({ title: '已复制 ' + this.logCount + ' 条', icon: 'none' }),
    });
  },
clearLog() {

    if (ble) ble.clearLogs();
    this._refreshLogs();
  },
  },
}
</script>

<style>
.page-wrap { padding: 24rpx; }
.card { background:#fff; border-radius:20rpx; padding:28rpx; margin-bottom:24rpx; box-shadow:0 4rpx 24rpx rgba(0,0,0,.04); }
.profile { display:flex; align-items:center; gap:20rpx; }
.avatar { width:88rpx; height:88rpx; border-radius:24rpx; background:linear-gradient(135deg,#ff7a3c,#6c5ce7); color:#fff; font-size:40rpx; font-weight:700; display:flex; align-items:center; justify-content:center; }
.muted { color:#9aa0a6; font-size:24rpx; }
.row { display:flex; align-items:center; justify-content:space-between; }
.item { padding:22rpx 0; border-top:1rpx solid #ececf0; }
.item:first-child { border-top:none; }
.help-panel { padding: 24rpx 28rpx; }
.help-title { font-size: 26rpx; font-weight: 700; color: #333333; margin-bottom: 16rpx; }
.help-sec { margin-bottom: 18rpx; }
.help-sec:last-of-type { margin-bottom: 8rpx; }
.help-h { font-size: 22rpx; font-weight: 600; color: #444444; margin-bottom: 6rpx; }
.help-li { font-size: 20rpx; line-height: 1.7; color: #777777; }
.help-foot { font-size: 20rpx; color: #aaaab0; margin-top: 12rpx; padding-top: 12rpx; border-top: 1rpx solid #ececf0; }
.log-toolbar { display:flex; align-items:center; justify-content:space-between; margin-bottom:16rpx; }
.log-btns { display:flex; gap:24rpx; }
.log-btn { color:#6c5ce7; font-size:26rpx; padding:8rpx 20rpx; border:1rpx solid #d8d4ff; border-radius:12rpx; }
.log-btn-danger { color:#e74c3c; border-color:#f5c6c0; }
.log-scroll { height:520rpx; background:#11111f; border-radius:12rpx; padding:16rpx; box-sizing:border-box; }
.log-text { color:#8be28b; font-size:20rpx; font-family:Menlo,Consolas,monospace; line-height:1.5; white-space:pre-wrap; word-break:break-all; }
</style>
