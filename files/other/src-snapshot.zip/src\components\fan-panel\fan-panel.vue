<template>
<view class="fp-wrap" v-show="!(hidden)">
  <!-- 子 Tab：风扇 / 电动 / 设置 -->
  <view class="sub-tabs">
    <view v-for="(item, index) in subTabs" :class="'sub-tab ' + (currentSub === index ? 'active' : '')" :data-index="(index)" @tap="switchSubTab" :key="item.name">{{item.name}}</view>
  </view>

  <!-- ===== 风扇子页 ===== -->
  <view class="fan-page" v-show="!(currentSub !== 0)">
    <!-- 风扇可视化 -->
    <view class="fan-visual">
      <view class="dial-ring">
        <view v-for="(item, index) in 60" class="tick" :style="'transform:rotate(' + (item * 6) + 'deg)'" :key="item.i"></view>
      </view>
      <view class="fan-blades" :style="'transform:rotate(' + (fanAngle) + 'deg)'">
        <view v-for="(item, index) in 5" class="blade" :style="'transform:rotate(' + (item * 72) + 'deg)'" :key="item.i"></view>
      </view>
      <view class="fan-hub"></view>
    </view>

    <!-- 档位 -->
    <view class="control-row gear-row">
      <text class="row-label">档位</text>
      <slider class="gear-slider" min="1" max="10" :value="(gear)" activeColor="#8b5cf6" backgroundColor="rgba(255,255,255,.08)" block-size="32" block-color="#8b5cf6" @change="onGear" />
      <text class="row-value">{{gear}}档</text>
    </view>

    <!-- 模式 -->
    <view class="control-row vertical">
      <text class="row-label">模式</text>
      <view class="btn-group">
        <view v-for="(item, index) in modes" :class="'mode-btn ' + (modeIndex === index ? 'active' : '')" :data-index="(index)" @tap="onMode" :key="item.name">{{item.name}}</view>
      </view>
    </view>

    <!-- 旋转方向 -->
    <view class="control-row vertical">
      <text class="row-label">旋转方向</text>
      <view class="btn-group two">
        <view v-for="(item, index) in directions" :class="'mode-btn ' + (dirIndex === index ? 'active' : '')" :data-index="(index)" @tap="onDirection" :key="item.name">{{item.name}}</view>
      </view>
    </view>

    <!-- 摇头 -->
    <view class="control-row between">
      <text class="row-label">摇头</text>
      <switch :checked="(headShake)" color="#8b5cf6" @change="onHeadShake" />
    </view>
  </view>

  <!-- ===== 电动子页 ===== -->
  <view class="other-page" v-show="!(currentSub !== 1)">
    <view class="placeholder-box">
      <view class="ph-icon">⚙</view>
      <text class="ph-text">电动控制（敬请期待）</text>
    </view>
  </view>

  <!-- ===== 设置子页 ===== -->
  <view class="other-page" v-show="!(currentSub !== 2)">
    <view class="placeholder-box">
      <view class="ph-icon">🛠</view>
      <text class="ph-text">动类设置（敬请期待）</text>
    </view>
  </view>

  <!-- 底部操作按钮 -->
  <view class="action-row">
    <view class="act-btn clear" @tap="onClear">↻ 清空</view>
    <view class="act-btn save" @tap="onSave">📋 保存</view>
  </view>
</view>
</template>

<script>
import protocol from '@/utils/protocol';
import deviceType from '@/utils/deviceType';

export default {
  props: {
    typeId: { type: Number, default: 1 },
    caps: { type: Object, default: () => ({}) },
    status: { type: Object, default: null },
    hidden: { type: Boolean, default: false },
  },

  data() {

    return {
    subTabs: [{ name: '风扇' }, { name: '电动' }, { name: '设置' }],
    currentSub: 0,

    // 风扇状态
    gear: 5,
    modeIndex: 0, // 0自然风 1睡眠风 2自定义
    modes: [{ name: '自然风' }, { name: '睡眠风' }, { name: '自定义' }],
    dirIndex: 0, // 0正传 1反转
    directions: [{ name: '正传' }, { name: '反转' }],
    headShake: false,

    // 风叶动画
    fanAngle: 0,
  }

  },

  // 小程序 lifetimes.attached/detached → Vue mounted/unmounted
  mounted() {
    this._startAnim();
  },
  unmounted() {
    this._stopAnim();
  },

  // 小程序 observers → Vue watch
  watch: {
    hidden: {
      handler(v) {
        // hidden 时暂停动画，切回时恢复，避免非当前面板仍占用 CPU
        if (v) this._stopAnim();
        else this._startAnim();
      },
    },
    status: {
      handler(v) {
        const fan = v && v.fan;
        if (!fan) return;
        const upd = {};
        if (typeof fan.gear === 'number') upd.gear = Math.max(1, Math.min(10, fan.gear));
        if (typeof fan.mode === 'number') upd.modeIndex = Math.max(0, Math.min(2, fan.mode - 1));
        if (typeof fan.dir === 'number') upd.dirIndex = fan.dir ? 1 : 0;
        if (typeof fan.leftRight === 'number') upd.headShake = !!fan.leftRight;
        if (Object.keys(upd).length) this.setData(upd);
      },
      immediate: true,
      deep: true,
    },
  },

  methods: {
    _emit(func, data) {
      // 只有设备在白名单里才下发，避免 0xE2 指令无效
      const typeId = this.typeId;
      if (!deviceType.supports(typeId, func)) {
        uni.showToast({ title: '设备不支持该功能', icon: 'none' });
        return;
      }
      this.$emit('cmd', { func, data });
    },

    switchSubTab(e) { this.setData({ currentSub: Number(e.currentTarget.dataset.index) }); },

    // 档位 1~10
    onGear(e) {
      const v = e.detail.value;
      this.setData({ gear: v });
      this._emit(protocol.CMD.FAN_GEAR, protocol.motion.gear(v));
    },

    // 模式：0自然风 1睡眠风 2自定义 → 协议 1/2/3
    onMode(e) {
      const idx = e.currentTarget.dataset.index;
      this.setData({ modeIndex: idx });
      this._emit(protocol.CMD.FAN_MODE, protocol.motion.mode(idx + 1));
    },

    // 方向：0正传 1反转
    onDirection(e) {
      const idx = e.currentTarget.dataset.index;
      this.setData({ dirIndex: idx });
      this._emit(protocol.CMD.FAN_DIR, protocol.motion.dir(idx === 0));
    },

    // 摇头（左右摆风）
    onHeadShake(e) {
      const on = e.detail.value;
      this.setData({ headShake: on });
      this._emit(protocol.CMD.FAN_LR, protocol.motion.leftRight(on));
    },

    // ====== 风叶动画 ======
    _startAnim() {
      this._stopAnim();
      this._animTimer = setInterval(() => {
        const speed = Math.max(2, (this.gear / 10) * 16);
        this.setData({
          fanAngle: (this.fanAngle + speed) % 360,
        });
      }, 50);
    },
    _stopAnim() {
      if (this._animTimer) { clearInterval(this._animTimer); this._animTimer = null; }
    },

    // 底部操作
    onClear() {
      this.setData({ gear: 5, modeIndex: 0, dirIndex: 0, headShake: false });
      uni.showToast({ title: '已清空', icon: 'none' });
    },
    onSave() {
      this.$emit('saverequest', { panel: 'fan', action: 'save-all' });
    },
  },
}
</script>

<style>
.fp-wrap {
  padding: 0 28rpx 40rpx;
  min-height: 100%;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

/* ===== 子 Tab：参考图深色实底选中 ===== */
.sub-tabs {
  display: flex;
  gap: 16rpx;
  padding: 10rpx 0 28rpx;
}
.sub-tab {
  flex: 1;
  text-align: center;
  font-size: 26rpx;
  color: rgba(255,255,255,.42);
  padding: 14rpx 0;
  border-radius: 999rpx;
  background: rgba(255,255,255,.04);
  border: 1rpx solid rgba(255,255,255,.06);
  transition: all .2s;
}
.sub-tab.active {
  background: rgba(255,255,255,.14);
  color: #fff;
  font-weight: 500;
  border-color: rgba(255,255,255,.18);
}

/* ===== 风扇页 ===== */
.fan-page { flex: 1; }

/* 风扇可视化：更大、更青色 */
.fan-visual {
  position: relative;
  width: 460rpx;
  height: 460rpx;
  margin: 20rpx auto 44rpx;
  display: flex;
  align-items: center;
  justify-content: center;
}

.dial-ring {
  position: absolute;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  border: 3rpx solid rgba(59,130,246,.15);
  box-shadow: 0 0 80rpx rgba(59,130,246,.10), inset 0 0 60rpx rgba(59,130,246,.06);
}
.tick {
  position: absolute;
  left: 50%;
  top: 10rpx;
  width: 2rpx;
  height: 10rpx;
  background: rgba(139,168,246,.30);
  transform-origin: center 220rpx;
  border-radius: 2rpx;
}
.tick:nth-child(5n+1) {
  height: 16rpx;
  background: rgba(139,168,246,.50);
}

.fan-blades {
  position: absolute;
  width: 340rpx;
  height: 340rpx;
  border-radius: 50%;
  transition: transform .5s cubic-bezier(.23,1,.32,1);
}
.blade {
  position: absolute;
  left: 50%;
  top: 50%;
  width: 120rpx;
  height: 210rpx;
  background: linear-gradient(180deg, #5ee7df 0%, #38bdf8 40%, #2563eb 100%);
  border-radius: 50% 50% 40% 40%;
  transform-origin: center bottom;
  margin-left: -60rpx;
  margin-top: -210rpx;
  opacity: .95;
  box-shadow: inset 0 -12rpx 24rpx rgba(37,99,235,.35);
}
.blade::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
  height: 30%;
  background: linear-gradient(180deg, rgba(56,189,248,.55), rgba(37,99,235,.85));
  border-radius: 50% 50% 0 0;
}

.fan-hub {
  position: absolute;
  width: 80rpx;
  height: 80rpx;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, #f8fafc, #cbd5e1 55%, #94a3b8);
  box-shadow: 0 8rpx 30rpx rgba(0,0,0,.35), inset 0 2rpx 6rpx rgba(255,255,255,.6);
  z-index: 2;
}

/* ===== 控件行 ===== */
.control-row {
  display: flex;
  align-items: center;
  padding: 18rpx 0;
}
.control-row.vertical {
  flex-direction: column;
  align-items: flex-start;
  gap: 14rpx;
  padding: 20rpx 0;
}
.control-row.between {
  justify-content: space-between;
  padding: 22rpx 0;
}

.row-label {
  font-size: 28rpx;
  color: rgba(255,255,255,.7);
  min-width: 120rpx;
}

.row-value {
  font-size: 28rpx;
  color: #a78bfa;
  font-weight: 600;
  min-width: 72rpx;
  text-align: right;
}

/* 档位滑块：细轨 + 紫色圆 thumb */
.gear-row { gap: 20rpx; }
.gear-slider {
  flex: 1;
  margin: 0;
}

/* 按钮组：更细长 */
.btn-group {
  width: 100%;
  display: flex;
  gap: 16rpx;
}
.btn-group.two { gap: 16rpx; }
.mode-btn {
  flex: 1;
  text-align: center;
  padding: 14rpx 0;
  border-radius: 12rpx;
  font-size: 26rpx;
  color: rgba(255,255,255,.55);
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.08);
  transition: all .2s;
}
.mode-btn.active {
  background: rgba(139,92,246,.20);
  color: #a78bfa;
  border-color: rgba(139,92,246,.40);
}

/* switch 右对齐 */
.control-row.between switch {
  transform: scale(.85);
  transform-origin: right center;
}

/* ===== 其它子页 ===== */
.other-page { flex: 1; }
.placeholder-box {
  padding: 160rpx 0;
  text-align: center;
}
.ph-icon {
  font-size: 72rpx;
  color: rgba(139,92,246,.35);
  margin-bottom: 24rpx;
}
.ph-text {
  color: rgba(255,255,255,.3);
  font-size: 28rpx;
}

/* ===== 底部按钮：更扁、圆角更大 ===== */
.action-row {
  display: flex;
  gap: 24rpx;
  padding: 40rpx 0 12rpx;
  margin-top: auto;
}
.act-btn {
  flex: 1;
  height: 76rpx;
  line-height: 76rpx;
  border-radius: 999rpx;
  font-size: 28rpx;
  font-weight: 500;
  text-align: center;
  transition: all .2s;
}
.act-btn.clear {
  background: transparent;
  color: rgba(255,255,255,.55);
  border: 1rpx solid rgba(255,255,255,.14);
}
.act-btn.save {
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
  color: #fff;
  box-shadow: 0 8rpx 28rpx rgba(139,92,246,.30);
}
</style>
