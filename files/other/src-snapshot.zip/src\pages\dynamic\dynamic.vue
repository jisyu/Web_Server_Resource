<template>
<view class="page-wrap">
  <view class="card">
    <view class="card-title">动态</view>
    <view class="muted">官方玩法、社区分享与固件资讯将在此展示。</view>
  </view>
  <view class="empty">敬请期待</view>
</view>
</template>

<script>
export default {
  data() {
    return {
    posts: [],
  }
  },
  onShow() {
    // 动态信息流占位，后续接入云端内容
  },
}
</script>

<style>
.page-wrap { padding: 24rpx; }
.card { background:#fff; border-radius:20rpx; padding:28rpx; margin-bottom:24rpx; box-shadow:0 4rpx 24rpx rgba(0,0,0,.04); }
.card-title { font-size:30rpx; font-weight:600; margin-bottom:16rpx; }
.muted { color:#9aa0a6; font-size:24rpx; }
.empty { text-align:center; color:#9aa0a6; padding:80rpx 0; font-size:28rpx; }
</style>
