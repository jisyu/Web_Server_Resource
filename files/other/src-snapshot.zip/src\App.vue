<script>
/**
 * App.vue —— 由小程序 app.js / app.wxss 迁移
 *
 * 变更说明：
 *  - globalData 中的 ble 单例改为 utils/ble.js 模块级单例（import { ble } from '@/utils/ble'），
 *    避免 getApp() 时序问题；此处仍保留 globalData 供历史代码兼容。
 *  - systemInfo 直接用 uni.getWindowInfo() / uni.getSystemInfoSync() 获取，不再缓存到 globalData。
 *  - 蓝牙/定位/麦克风权限改为在真正使用处动态申请（见 utils/permission.js），
 *    替代小程序里由宿主代理的 wx.authorize。
 */
import { ble } from '@/utils/ble'

export default {
  globalData: {
    ble,
    connectedDevice: null,
    devices: [],
    systemInfo: null,
  },

  onLaunch() {
    // 关掉原生启动屏（白圈+应用名）：manifest 里已设 alwaysShowBeforeRender=false，
    // 该模式下启动屏不会自动关闭，需在 JS 启动后立即关闭，避免叠在我们的启动页前面。
    // #ifdef APP-PLUS
    try { plus.navigator.closeSplashscreen() } catch (e) { /* ignore */ }
    // #endif

    try {
      this.globalData.systemInfo = uni.getWindowInfo
        ? uni.getWindowInfo()
        : uni.getSystemInfoSync()
    } catch (e) {
      // ignore
    }
    console.log('[App] launch, BLE supported =', ble.isSupport())
  },

  onShow() {
    // App 回到前台：可在此恢复 BLE 连接状态（当前由各页面 onShow 自行处理）
  },

  onHide() {
    // 进入后台：可选断开以释放系统资源
  },
}
</script>

<style>
/* ====== 全局样式（迁移自 app.wxss）—— 暗色科技风 ====== */
page {
  --bg: #0d0d1a;
  --card: #1a1a2e;
  --card-alt: #16162a;
  --primary: #a855f7;
  --primary-dark: #9333ea;
  --primary-light: #c084fc;
  --text: #e4e4ed;
  --text-2: #7a7a96;
  --text-3: #555566;
  --line: rgba(255, 255, 255, .06);
  background: var(--bg);
  color: var(--text);
  font-family: -apple-system, "PingFang SC", "Helvetica Neue", Helvetica, sans-serif;
}

.page-wrap {
  padding: 24rpx;
  box-sizing: border-box;
}

.card {
  background: linear-gradient(135deg, var(--card), var(--card-alt));
  border-radius: 20rpx;
  padding: 28rpx;
  margin-bottom: 24rpx;
  box-shadow: 0 4rpx 24rpx rgba(0, 0, 0, .3);
  border: 1rpx solid rgba(168, 85, 247, .08);
}

.card-title {
  font-size: 30rpx;
  font-weight: 600;
  margin-bottom: 20rpx;
  color: var(--text);
}

.row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.muted {
  color: var(--text-2);
  font-size: 24rpx;
}

.btn-primary {
  background: linear-gradient(135deg, var(--primary-dark), var(--primary));
  color: #fff;
  border-radius: 999rpx;
  font-size: 30rpx;
}

.empty {
  text-align: center;
  color: var(--text-3);
  padding: 120rpx 0;
  font-size: 28rpx;
}
</style>
