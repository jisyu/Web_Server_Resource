/**
 * config.js —— 全局运行配置
 *
 * 小程序原本把云端域名写死在 request.js，且登录依赖 wx.login（App 端不存在微信 code）。
 * 这里统一抽离为配置项：
 *  - ENABLE_CLOUD = false 时，所有云端请求直接本地失败，BLE 直连控制不受任何影响；
 *    接好后端后打开开关、填好 BASE_URL 即可。
 *  - BASE_URL 支持运行时覆盖（调试时可在 App 内切换后端地址）。
 */
const DEFAULT_BASE_URL = 'https://api.example.com/miniapp/v1'

export default {
  BASE_URL: DEFAULT_BASE_URL,

  // 是否启用云端能力。false = 纯本地 BLE 控制模式
  ENABLE_CLOUD: false,

  // 请求超时（ms）
  HTTP_TIMEOUT: 10000,

  // 匿名登录端点（App 端无微信 code，改为匿名/账密方式换取 token）
  AUTH_PATH: '/auth/anonymous',

  // 本地存储 key
  STORAGE_TOKEN: 'access_token',
  STORAGE_REFRESH_TOKEN: 'refresh_token',
}

const OVERRIDE_KEY = 'rgbw_cloud_base_url'

/** 获取当前生效的云端地址（优先取运行期覆盖值） */
export function getBaseUrl() {
  try {
    return uni.getStorageSync(OVERRIDE_KEY) || DEFAULT_BASE_URL
  } catch (e) {
    return DEFAULT_BASE_URL
  }
}

/** 运行期切换云端地址 */
export function setBaseUrl(url) {
  uni.setStorageSync(OVERRIDE_KEY, url)
}
