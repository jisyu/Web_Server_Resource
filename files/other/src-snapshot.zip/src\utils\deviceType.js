/**
 * deviceType.js
 * 设备类型（2 字节：大类 + 小类）↔ 属性族 ↔ 功能模块 ↔ 指令白名单 映射
 *
 * 编号规则（2 字节）：
 *   高 8 位 = 设备大类（仅四个）
 *     0x1000 光类 / 0x2000 动类 / 0x3000 感类 / 0x4000 能类
 *   低 8 位 = 设备小类（0x00–0xFF），沿用协议文档的品类编号
 *   例：0x1001 字母灯  0x1007 幻彩吸顶灯  0x2009 幻彩风扇灯  0x3001 温湿度传感器
 *
 * 兼容性：
 *   旧固件广播/本地存储使用 1 字节品类号，LEGACY_TO_TYPE 维护 品类号 → 2 字节编号 映射，
 *   解析与查询处通过 normalizeTypeId() 统一归一化为 2 字节编号。
 */

// 属性族
const FAMILY = {
  LIGHT: 'light', // 光
  MOTION: 'motion', // 动（风）
  SENSOR: 'sensor', // 感
  POWER: 'power', // 能
};

// 属性族 -> 对应面板组件名（device 页按此动态渲染）
const FAMILY_PANEL = {
  light: 'light-panel',
  motion: 'fan-panel',
  sensor: 'sensor-panel',
  power: 'power-panel',
};

// 设备大类（仅四个）
const SERIES = {
  LIGHT: { id: 0x1000, name: '光类' },
  MOTION: { id: 0x2000, name: '动类' },
  SENSOR: { id: 0x3000, name: '感类' },
  POWER: { id: 0x4000, name: '能类' },
};

// 状态回包布局（protocol.js parseStatusPayload 按此分支）
//   strip: 灯带/字母灯/灯条类（亮度 u16、颜色 HSV）  panel: 吸顶/平板类  fan: 风扇灯类
const LAYOUT = {
  STRIP: 'strip',
  PANEL: 'panel',
  FAN: 'fan',
};

// 白名单常用组合
const WL_STRIP_FULL = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0e, 0x0f];
const WL_STRIP_BASIC = [0x00, 0x01, 0x02, 0x03, 0x05, 0x06, 0x0a, 0x0c, 0x0e, 0x0f, 0x10, 0x11];
const WL_STRIP_RGB = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0e, 0x0f, 0x10, 0x11, 0x12];
const WL_PANEL_FULL = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0e, 0x0f, 0x10, 0x11, 0x12];
const WL_FAN = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57];
const WL_SENSOR = [0x60, 0x61, 0x62, 0x63, 0x64];
const WL_POWER = [0x70, 0x71, 0x72, 0x73, 0x74];

/**
 * 具体设备类型表
 * 键 = 大类(0x1000/0x2000/0x3000/0x4000) | 小类(协议文档品类号)
 * legacy:  旧 1 字节品类号（广播/存储兼容），无对应则省略
 * layout:  状态回包字节布局
 * attrs:   属性族（决定 device 页渲染哪些面板）
 */
const DEVICE_TYPES = {
  // ===== 光类 0x1000 =====
  0x1001: { name: '字母灯', legacy: 0x01, layout: LAYOUT.STRIP, hsv: true, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_FULL },
  0x1002: { name: '拼接灯', legacy: 0x02, layout: LAYOUT.STRIP, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_FULL },
  0x1003: { name: '串连RGB灯泡', legacy: 0x03, layout: LAYOUT.STRIP, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_BASIC },
  0x1004: { name: 'RGB幻彩灯条', legacy: 0x04, layout: LAYOUT.STRIP, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_FULL },
  0x1005: { name: 'RGB七彩灯条', legacy: 0x05, layout: LAYOUT.STRIP, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_BASIC },
  0x1006: { name: 'RGB电竞灯', legacy: 0x06, layout: LAYOUT.STRIP, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_RGB },
  // hsv: true = 指令走长格式（颜色 HSV 4B、亮度/模式 u16）；实测 qh-bt-light(0x1007) 回包亮度为 u16，故按长格式处理
  0x1007: { name: '幻彩吸顶灯', legacy: 0x07, layout: LAYOUT.STRIP, hsv: true, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_PANEL_FULL },
  0x1008: { name: '七彩吸顶灯', legacy: 0x08, layout: LAYOUT.PANEL, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_PANEL_FULL },
  0x1009: { name: '幻彩灯条', legacy: 0x09, layout: LAYOUT.STRIP, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_FULL },
  0x100a: { name: '七彩灯条', legacy: 0x10, layout: LAYOUT.STRIP, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_BASIC },
  0x1011: { name: '球泡灯', legacy: 0x11, layout: LAYOUT.PANEL, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_BASIC },
  0x1012: { name: '西顿前台灯', legacy: 0x12, layout: LAYOUT.PANEL, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_PANEL_FULL },
  0x1013: { name: '天镜灯（点阵）', legacy: 0x13, layout: LAYOUT.PANEL, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_PANEL_FULL },
  0x1050: { name: '电视墙氛围灯', legacy: 0x50, layout: LAYOUT.PANEL, series: SERIES.LIGHT, attrs: ['light', 'sensor'], whitelist: WL_PANEL_FULL.concat(WL_SENSOR) },
  0x1051: { name: '落地灯/桌面灯', legacy: 0x51, layout: LAYOUT.PANEL, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_BASIC },
  0x1052: { name: '触控小夜灯', legacy: 0x52, layout: LAYOUT.PANEL, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_FULL },
  0x1053: { name: '烟花灯', legacy: 0x53, layout: LAYOUT.PANEL, series: SERIES.LIGHT, attrs: ['light'], whitelist: WL_STRIP_BASIC },

  // ===== 动类 0x2000（风扇灯，仅新固件 2 字节编号可识别）=====
  0x2009: { name: '幻彩风扇灯', layout: LAYOUT.FAN, series: SERIES.MOTION, attrs: ['light', 'motion'], whitelist: WL_FAN },
  0x2010: { name: '平板幻彩风扇灯', layout: LAYOUT.FAN, series: SERIES.MOTION, attrs: ['light', 'motion'], whitelist: WL_FAN },

  // ===== 感类 0x3000（传感器，小类沿用传感器类型 ID）=====
  0x3001: { name: '温湿度传感器', layout: null, series: SERIES.SENSOR, attrs: ['sensor'], whitelist: WL_SENSOR },
  0x3002: { name: '光照传感器', layout: null, series: SERIES.SENSOR, attrs: ['sensor'], whitelist: WL_SENSOR },
  0x3003: { name: '红外传感器', layout: null, series: SERIES.SENSOR, attrs: ['sensor'], whitelist: WL_SENSOR },
  0x3004: { name: '雷达传感器', layout: null, series: SERIES.SENSOR, attrs: ['sensor'], whitelist: WL_SENSOR },
  0x3005: { name: '视觉传感器', layout: null, series: SERIES.SENSOR, attrs: ['sensor'], whitelist: WL_SENSOR },

  // ===== 能类 0x4000（电源/电池）=====
  0x4010: { name: '电源类设备', layout: null, series: SERIES.POWER, attrs: ['power'], whitelist: WL_POWER },
  0x4011: { name: '电池类设备', layout: null, series: SERIES.POWER, attrs: ['power'], whitelist: WL_POWER },
};

// 旧 1 字节品类号 → 2 字节编号（广播/本地存储兼容）
const LEGACY_TO_TYPE = {};
Object.keys(DEVICE_TYPES).forEach((k) => {
  const t = DEVICE_TYPES[k];
  if (t.legacy != null) LEGACY_TO_TYPE[t.legacy] = Number(k);
});

// 归一化：旧 1 字节品类号 → 2 字节编号；已是 2 字节则原样返回
function normalizeTypeId(typeId) {
  if (typeId == null) return null;
  return LEGACY_TO_TYPE[typeId] || typeId;
}

// 2 字节编号 → 旧 1 字节品类号，无对应返回 null
function toLegacyTypeId(typeId) {
  const t = DEVICE_TYPES[typeId];
  return t && t.legacy != null ? t.legacy : null;
}

// 取大类：2 字节取高 8 位；旧 1 字节按映射推导
function getSeriesId(typeId) {
  if (typeId == null) return null;
  const id = Number(typeId);
  if (id < 0x1000) {
    const mapped = LEGACY_TO_TYPE[id];
    return mapped != null ? (mapped & 0xff00) : null;
  }
  return id & 0xff00;
}

// 状态回包是否为灯带/字母灯/灯条类布局
function isStripLayout(typeId) {
  const t = DEVICE_TYPES[normalizeTypeId(typeId)];
  return !!t && t.layout === LAYOUT.STRIP;
}

// 指令是否走长格式（颜色 HSV + 亮度/模式 u16）：由类型表 hsv 字段决定，未知类型按短格式
function isHsvType(typeId) {
  const t = DEVICE_TYPES[normalizeTypeId(typeId)];
  return !!t && t.hsv === true;
}

// 由白名单推导面板可见的"功能开关"
function deriveCaps(typeId) {
  const t = DEVICE_TYPES[normalizeTypeId(typeId)];
  if (!t) return null;
  const w = t.whitelist;
  const has = (c) => w.indexOf(c) >= 0;
  return {
    power: has(0x01),
    firmware: has(0x02),
    color: has(0x03), // RGB/幻彩
    segment: has(0x04), // 分段颜色
    brightness: has(0x05),
    mode: has(0x06), // 预设动态
    music: has(0x07),
    mic: has(0x08),
    diy: has(0x09),
    timer: has(0x0a),
    ledCount: has(0x0b),
    syncTime: has(0x0c),
    bind: has(0x0e),
    speed: has(0x0f),
    warmCool: has(0x10) || has(0x11) || has(0x12) || has(0x13) || has(0x14), // 冷暖白光
    fan: has(0x50),
    sensor: t.attrs.indexOf('sensor') >= 0,
  };
}

function getDeviceMeta(typeId) {
  const id = normalizeTypeId(typeId);
  const t = DEVICE_TYPES[id];
  if (!t) return { name: '未知设备', typeId: id, series: null, attrs: [], whitelist: [], caps: null };
  return {
    typeId: id,
    name: t.name,
    series: t.series,
    layout: t.layout,
    attrs: t.attrs,
    whitelist: t.whitelist,
    caps: deriveCaps(id),
  };
}

// 设备是否支持某功能码（下发前校验，规避 0xE2 指令无效）
function supports(typeId, func) {
  const t = DEVICE_TYPES[normalizeTypeId(typeId)];
  return !!t && t.whitelist.indexOf(func) >= 0;
}

const __api = {
  FAMILY,
  FAMILY_PANEL,
  SERIES,
  LAYOUT,
  DEVICE_TYPES,
  LEGACY_TO_TYPE,
  normalizeTypeId,
  toLegacyTypeId,
  getSeriesId,
  isStripLayout,
  isHsvType,
  getDeviceMeta,
  deriveCaps,
  supports,
};

export { FAMILY, FAMILY_PANEL, SERIES, LAYOUT, DEVICE_TYPES, LEGACY_TO_TYPE, normalizeTypeId, toLegacyTypeId, getSeriesId, isStripLayout, isHsvType, getDeviceMeta, deriveCaps, supports }
export default __api;
