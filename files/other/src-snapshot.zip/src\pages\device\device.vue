<template>
<view class="page-wrap">
  <!-- 顶栏：返回 + 设备名(可编辑) + 菜单 + 电源 -->
  <view class="top-bar">
    <view class="top-left">
      <text class="back-icon" @tap="goBack">‹</text>
      <text class="dev-name">{{deviceName}}</text>
      <text class="edit-icon" @tap="editName">✎</text>
    </view>
    <view class="top-right">
      <text class="menu-icon" @tap.stop="onMenu">···</text>
      <view :class="'power-switch ' + (lightStatus.power ? 'on' : '')" @tap="togglePower">
        <view class="ps-knob"></view>
      </view>
    </view>
  </view>

  <!-- Tab 栏：按设备类型动态显示（光 / 能 / 感 / 动） -->
  <view class="tab-bar" v-if="tabs.length">
    <view v-for="(item, index) in tabs" :class="'tab-item ' + (currentTab === index ? 'active' : '')" :data-index="(index)" @tap="switchTab" :key="item.key">{{item.name}}</view>
  </view>

  <!-- 内容区：按当前 Tab 渲染对应面板 -->
  <scroll-view scroll-y class="tab-content" enhanced :show-scrollbar="(false)">
    <!-- 光（10xx） -->
    <light-panel v-if="showLight" id="lightPanel" :hidden="currentKey !== 'light'" :typeId="(typeId)" :caps="(caps)" :status="(lightStatus)" :deviceName="(deviceName)" :firmware="(fwVersion)" :lineOrder="(deviceLineOrder)" :driverScheme="(deviceDriverScheme)" @cmd="onCmd" @saverequest="onSaveRequest" @editname="editName" ref="lightPanel" />

    <!-- 能（40xx） -->
    <power-panel v-if="showPower" id="powerPanel" :hidden="currentKey !== 'power'" :typeId="(typeId)" :caps="(caps)" @cmd="onCmd" ref="powerPanel" />

    <!-- 感（30xx） -->
    <sensor-panel v-if="showSensor" id="sensorPanel" :hidden="currentKey !== 'sensor'" :typeId="(typeId)" :caps="(caps)" @cmd="onCmd" ref="sensorPanel" />

    <!-- 动（20xx） -->
    <fan-panel v-if="showMotion" id="fanPanel" :hidden="currentKey !== 'motion'" :typeId="(typeId)" :caps="(caps)" :status="(fanStatus)" @cmd="onCmd" @saverequest="onSaveRequest" ref="fanPanel" />

    <!-- 空态：未知/未定义类型的设备 -->
    <view v-if="!tabs.length" class="empty-hint">
      未知设备类型（0x{{typeHex}}），无可用控制窗口
    </view>
  </scroll-view>
</view>
</template>

<script>
import { ble } from '@/utils/ble'

import { getDeviceMeta, isHsvType, normalizeTypeId } from '@/utils/deviceType';
import protocol from '@/utils/protocol';
import deviceStore from '@/utils/deviceStore';

// 兜底能力集：类型表未定义 caps 时（未知类型但带光属性）保证面板功能可用
const FALLBACK_LIGHT_CAPS = {
  power: true, firmware: true, color: true, segment: true, brightness: true,
  mode: true, music: true, mic: true, diy: true, timer: true,
  ledCount: true, syncTime: true, bind: true, speed: true, warmCool: true,
  fan: false, sensor: false,
};

export default {
data() {
    return {
    deviceId: '',
    typeId: 0x1001,
    typeHex: '1001',
    deviceName: '设备',
    series: '',
    attrs: [],
    showLight: false,
    showMotion: false,
    showSensor: false,
    showPower: false,
    caps: {},
    connected: false,

    // Tab 系统（按设备类型动态生成，顺序：光 / 能 / 感 / 动）
    tabs: [
      { key: 'light', name: '光' },
      { key: 'power', name: '能' },
      { key: 'sensor', name: '感' },
      { key: 'motion', name: '动' },
    ],
    currentTab: 0,
    currentKey: '', // 当前 Tab 的 key（面板显隐用，避免过滤后索引错位）

    lightStatus: { power: false, speed: 1, timerOn: { on: false }, timerOff: { on: false } },
    fanStatus: { fan: { power: false } },
    fwVersion: '',      // 软件版本（0x02 读取结果）
    // 面板回读值：-1 表示未知（0xF4 线序 / 驱动方案查询后回填）
    deviceLineOrder: -1,
    deviceDriverScheme: -1,
  }
  },
onLoad(options) {
    // 统一归一化为 2 字节编号（兼容旧 1 字节品类号）
    const typeId = normalizeTypeId(parseInt(options.typeId, 10) || 1);
    const meta = getDeviceMeta(typeId);
    const saved = deviceStore.getByDeviceId(options.deviceId);
    const customName = saved ? saved.name : '';

    // 按设备类型（大类）生成可用 Tab：10xx 光 / 40xx 能 / 30xx 感 / 20xx 动
    const tabs = this._buildTabs(meta.attrs);
    const currentKey = tabs.length ? tabs[0].key : '';

    this.setData({
      deviceId: options.deviceId,
      typeId,
      typeHex: ('000' + typeId.toString(16)).slice(-4).toUpperCase(),
      deviceName: customName || meta.name,
      series: meta.series ? meta.series.name : '',
      attrs: meta.attrs,
      caps: meta.caps || (meta.attrs.indexOf('light') >= 0 ? FALLBACK_LIGHT_CAPS : {}),
      // 面板窗口按类型显隐（仅渲染该设备具备的属性族）
      showLight: meta.attrs.indexOf('light') >= 0,
      showPower: meta.attrs.indexOf('power') >= 0,
      showSensor: meta.attrs.indexOf('sensor') >= 0,
      showMotion: meta.attrs.indexOf('motion') >= 0,
      tabs,
      currentTab: 0,
      currentKey,
    });

    this.ble = ble;
    this._bindPush();   // 监听设备主动上报（遥控/按键操作后回传 0x00 状态帧）
    this._bindConnectionEvents();
    if (this.ble && this.ble.isConnected(options.deviceId)) {
      this.setData({ connected: true });
      this.syncStatus();
      this.syncSpeed();
    }
  },
onShow() {
  this._pageVisible = true;
  this._bindConnectionEvents();
  this._startPoll();
  // 每次进入/回到页面都校验一次链路：设备断电重启后系统可能仍显示"已连接"
  this.verifyLink();
    // 转发页面生命周期给需要重绘/资源管理的面板（替代小程序的 pageLifetimes）
    const panel = this.$refs.lightPanel;
    if (panel && panel.onPageShow) panel.onPageShow();
  },
onHide() {
    this._pageVisible = false;
    this._stopPoll();
    const panel = this.$refs.lightPanel;
    if (panel && panel.onPageHide) panel.onPageHide();
  },
onUnload() {
    this._pageVisible = false;
    // 取消事件订阅，避免页面销毁后回调仍在刷新已卸载页面
    if (this._offPush) { this._offPush(); this._offPush = null; }
    if (this._offConnection) { this._offConnection(); this._offConnection = null; }
    this._stopPoll();
  },

  methods: {
_bindConnectionEvents() {
    if (this._offConnection || !this.ble || !this.ble.subscribeConnectionChange) return;
    this._offConnection = this.ble.subscribeConnectionChange((res) => {
      if (!this._sameDevice(res.deviceId)) return;
      this.setData({ connected: !!res.connected });
      if (!res.connected) {
        this._stopPoll();
        if (!res.intentional) uni.showToast({ title: '设备连接已断开，正在尝试恢复', icon: 'none' });
      } else {
        this._startPoll();
        if (res.reconnect) {
          this.syncStatus();
          if (this.caps.speed) this.syncSpeed();
        }
      }
    });
  },
_bindPush() {
    if (!this.ble || !this.ble.onNotify) return;
    this._offPush = this.ble.onNotify((deviceId, packet) => {
      if (!this._sameDevice(deviceId) || !packet) return;
      if (packet[1] === protocol.CMD.SPEED) {
        const speed = protocol.parseSpeedPacket(packet);
        if (speed != null) this._applySpeed(speed);
        return;
      }
      if (packet[1] !== protocol.CMD.STATUS) return;
      const st = protocol.parseStatusPacket(packet, this.typeId);
      if (!st) return;
      this._logPush(packet, st);
      this._applyStatus(st);
    });
  },
_sameDevice(id) {
    return String(id || '').toLowerCase() === String(this.deviceId || '').toLowerCase();
  },
_logPush(packet, st) {
    try {
      if (!this.ble || !this.ble._log) return;
      const hex = packet.map((b) => ('0' + (b & 0xff).toString(16)).slice(-2).toUpperCase()).join(' ');
      this.ble._log('[PUSH] 状态上报 dev=' + this.deviceId
        + '\n  raw : ' + hex
        + '\n  解析: power=' + (st.power ? 'ON' : 'OFF')
        + ' bright=' + st.brightness
        + ' cw=' + (st.coldPct == null ? '-' : st.coldPct) + '/' + (st.warmPct == null ? '-' : st.warmPct));
    } catch (e) { /* ignore */ }
  },
_startPoll() {
    this._stopPoll();
    if (!this.ble || !this.deviceId) return;
    this._pollTimer = setInterval(() => {
      if (!this.connected || this._polling || !this._pageVisible) return; // 页面隐藏时停止轮询
      if (!this.ble.isConnected(this.deviceId)) return;
      // 音乐律动期间不下发查询，避免抢占高频律动帧的带宽
      const panel = this.$refs.lightPanel;
      if (panel && panel.micRunning) return;
      this._polling = true;
      const done = () => { this._polling = false; };
      this.syncStatus().then(done, done);
    }, 3000);
  },
_stopPoll() {
    if (this._pollTimer) { clearInterval(this._pollTimer); this._pollTimer = null; }
    this._polling = false;
  },
goBack() {
    uni.navigateBack({ delta: 1, fail: () => uni.reLaunch({ url: '/pages/index/index' }) });
  },
editName() {
    const that = this;
    uni.showModal({
      title: '修改设备名',
      editable: true,
      placeholderText: '输入新名称',
      confirmColor: '#a855f7',
      content: that.deviceName,
      success(res) {
        if (!res.confirm || !res.content || !res.content.trim()) return;
          const name = res.content.trim();
          // 更新本地存储（save 按 deviceId 去重，需传单对象 {deviceId, name}）
          deviceStore.save({ deviceId: that.deviceId, name });
          that.setData({ deviceName: name });
          uni.showToast({ title: '已更新', icon: 'none' });
        },
    });
  },
onMenu() {
    // 「BLE 诊断信息」属调试入口，正式版隐藏（showBleDiag 方法保留，需要时把该项加回 itemList 即可）
    uni.showActionSheet({
      itemList: ['删除设备', '设备信息'],
      success: (res) => {
        if (res.tapIndex === 0) this.deleteDevice();
        if (res.tapIndex === 1) this.showDeviceInfo();
      },
    });
  },
// BLE 诊断：把连接/服务/特征/属性/写入通道完整展示，可一键复制反馈
showBleDiag() {
    let text = '';
    try {
      text = this.ble && this.ble.getDiagText ? this.ble.getDiagText(this.deviceId) : '诊断不可用';
    } catch (e) {
      text = '诊断异常：' + (e && e.message);
    }
    uni.showModal({
      title: 'BLE 诊断信息',
      content: text || '(空)',
      showCancel: true,
      cancelText: '关闭',
      confirmText: '复制',
      confirmColor: '#a855f7',
      success: (r) => {
        if (r.confirm) uni.setClipboardData({ data: text });
      },
    });
  },
showDeviceInfo() {
    uni.showModal({
      title: '设备信息',
      content: `名称：${this.deviceName}\n类型：0x${this.typeHex}\n系列：${this.series || '-'}\n属性：${this.attrs.join('/')}`,
      showCancel: false,
      confirmText: '知道了',
      confirmColor: '#a855f7',
    });
  },
async togglePower() {
    if (!this.connected) { uni.showToast({ title: '未连接', icon: 'none' }); return; }
    try {
      const on = !this.lightStatus.power;
      await this.ble.write(this.deviceId, protocol.CMD.POWER, protocol.light.power(on));
      this.setData({ 'lightStatus.power': on });
      uni.showToast({ title: on ? '已开启' : '已关闭', icon: 'none' });
    } catch (e) {
      const raw = this._fmtErrText(e);
      if (e && e.kind === 'timeout') {
        uni.showToast({ title: '设备无回包（超时）', icon: 'none' });
      } else {
        uni.showModal({
          title: '电源指令发送失败',
          content: raw,
          showCancel: true,
          cancelText: '关闭',
          confirmText: '复制',
          confirmColor: '#a855f7',
          success: (r) => { if (r.confirm) uni.setClipboardData({ data: raw }); },
        });
      }
    }
  },
switchTab(e) {
    const idx = Number(e.currentTarget.dataset.index);
    const t = this.tabs[idx];
    this.setData({ currentTab: idx, currentKey: t ? t.key : '' });
  },
_buildTabs(attrs) {
    const all = [
      { key: 'light', name: '光' },
      { key: 'power', name: '能' },
      { key: 'sensor', name: '感' },
      { key: 'motion', name: '动' },
    ];
    return all.filter((t) => attrs.indexOf(t.key) >= 0);
  },
async reconnect() {
    uni.showLoading({ title: '连接中…' });
    try {
      await this.ble.connect(this.deviceId);
      this.setData({ connected: true });
      uni.hideLoading();
      this.syncStatus();
      this.syncSpeed();
    } catch (e) {
      uni.hideLoading();
      uni.showToast({ title: '连接失败', icon: 'none' });
    }
  },
async syncStatus() {
  if (!this._pageVisible || !this.ble || !this.ble.isConnected(this.deviceId)) return;
  try {
      const packet = await this.ble.write(this.deviceId, protocol.CMD.STATUS, []);
      this._statusFail = 0;
      // STATUS 回包不含 result code，packet[4] 是 Byte1（开关状态），无需 parseResult
      this._applyStatus(protocol.parseStatusPacket(packet, this.typeId) || {});
    } catch (e) {
      if (e && e.kind === 'timeout') {
        // 连续无回包说明链路已经"假连接"（常见于设备断电重启、APP 重开），重建连接
        this._statusFail = (this._statusFail || 0) + 1;
        uni.showToast({ title: '设备状态查询无回包，正在恢复连接', icon: 'none' });
        if (this.ble && this.ble._log) this.ble._log('[DEVICE] STATUS 查询失败(' + this._statusFail + ')：' + (e.message || e), 'warn');
        if (this._statusFail >= 2) {
          this._statusFail = 0;
          const ok = await this.ble.forceReconnect(this.deviceId);
          this.setData({ connected: !!ok });
          if (ok) await this.syncStatus();
        }
      } else if (e && e.kind === 'connection') {
        this._statusFail = 0;
        this.setData({ connected: false });
      }
    }
  },
// 进入页面/切回前台时校验链路真实性（系统可能仍报"已连接"但 GATT 已失效）
async verifyLink() {
  if (!this.ble || !this.deviceId) return;
  if (!this.ble.isConnected(this.deviceId)) {
    this.setData({ connected: false });
    return;
  }
  const ok = await this.ble.verifyLink(this.deviceId);
  if (!ok) {
    const stillUp = this.ble.isConnected(this.deviceId);
    this.setData({ connected: !!stillUp });
  }
  return ok;
},
async syncSpeed() {
  if (!this._pageVisible || !this.ble || !this.ble.isConnected(this.deviceId) || !this.caps.speed) return;
    try {
      const packet = await this.ble.write(this.deviceId, protocol.CMD.SPEED, protocol.light.speedQuery());
      const speed = protocol.parseSpeedPacket(packet);
      if (speed != null) this._applySpeed(speed);
    } catch (e) {
      /* silent */
    }
  },
_applySpeed(speed) {
    const value = Math.max(1, Math.min(100, Math.round(Number(speed) || 1)));
    this.setData({ 'lightStatus.speed': value });
  },
_applyStatus(st) {
    const isStrip = isHsvType(this.typeId);
    // 通用状态结构：RGB 亮度统一为 u16（Byte2~3）。灯带类量程 0~1000，其余类默认 0~100；
    // 若上报值超过 100 则按 1000 量程换算，兼容不同固件量程
    const rawB = st.brightness != null ? st.brightness : st.colorBrightness;
    const brightness = rawB != null ? rawB : (isStrip ? 500 : 100);
    const maxB = isStrip || brightness > 100 ? 1000 : 100;
    const lightStatus = {
      power: !!st.power,
      brightness,
      brightnessPct: Math.max(0, Math.min(100, Math.round((brightness / maxB) * 100))),
      // 状态帧未携带灯珠数（0/缺省）时沿用上一次的值，避免面板灯珠数被清零
      ledCount: st.ledCount || (this.lightStatus && this.lightStatus.ledCount) || 0,
      mic: st.mic || 0,
      timerOn: st.timerOn || { on: false },
      timerOff: st.timerOff || { on: false },
      speed: st.speed != null ? st.speed : (this.lightStatus.speed == null ? 1 : this.lightStatus.speed),
    };
    // 冷暖状态（通用结构 Byte15~18）：C 色温即色温滑块值（0 最暖 → 100 最冷），C 色亮度即冷暖亮度；
    // 缺 C 色温时用 W 色温反推（下发语义为 coldT = t、warmT = 100 - t）
    if (st.coldPct != null) lightStatus.warmCool = st.coldPct;
    else if (st.warmPct != null) lightStatus.warmCool = 100 - st.warmPct;
    if (st.coldBrightness != null) lightStatus.warmBrightness = st.coldBrightness;
    else if (st.warmBrightness != null) lightStatus.warmBrightness = st.warmBrightness;

    const fanStatus = { fan: st.fan || { power: false } };
    // 状态无变化则不重复 setData（轮询 3s 一次，避免无谓渲染打断正在拖动的滑块）
    const sig = JSON.stringify(lightStatus) + '|' + JSON.stringify(fanStatus);
    if (sig === this._statusSig) return;
    this._statusSig = sig;

    this.setData({ lightStatus, fanStatus });
  },
async onCmd(payload) {
    const { func, data, silent } = payload || {};
    // 批量帧（DIY 分批/分段数据）：必须逐帧按序发送，不能走可合并的 silent 通道
    if (payload && payload.frames) {
      this.ble.writeBurst(this.deviceId, payload.frames);
      return;
    }
    if (silent) {
      this.ble.writeNoWait(this.deviceId, func, data);
      return;
    }
    // 线序/驱动方案"查询"（无数据段）只是回读显示, 老固件不支持时静默, 不要弹错误打扰用户
    const isQuery = (!data || data.length === 0)
      && (func === protocol.CMD.LINE_ORDER || func === protocol.CMD.DRIVER_SCHEME);
    try {
      const packet = await this.ble.write(this.deviceId, func, data);
      const r = protocol.parseResult(packet[4]);
      if (!r.ok) {
        if (!isQuery) uni.showToast({ title: r.msg, icon: 'none' });
        return;
      }
      this._handleReply(func, packet);
    } catch (err) {
      if (isQuery) return;
      const raw = this._fmtErrText(err);
      if (err && err.kind === 'timeout') {
        uni.showToast({ title: '设备无回包（超时）', icon: 'none' });
      } else {
        // 写失败：直接弹完整错误（可复制），避免被 16 字截断后无法定位
        uni.showModal({
          title: '指令发送失败',
          content: raw,
          showCancel: true,
          cancelText: '关闭',
          confirmText: '复制',
          confirmColor: '#a855f7',
          success: (r) => {
            if (r.confirm) uni.setClipboardData({ data: raw });
          },
        });
      }
      try {
        if (this.ble && this.ble._log) {
          this.ble._log('[CMD] 失败 func=0x' + Number(func).toString(16) + ' ' + raw, 'warn');
        }
      } catch (e) { /* ignore */ }
    }
  },
// 错误对象转可读文本（uni 的 fail 回调 errCode/errMsg 形态不统一）
_fmtErrText(err) {
    if (!err) return '未知错误';
    if (typeof err === 'string') return err;
    const parts = [];
    if (err.errCode != null) parts.push('errCode=' + err.errCode);
    if (err.errMsg) parts.push(err.errMsg);
    if (err.message) parts.push(err.message);
    if (!parts.length) {
      try { parts.push(JSON.stringify(err)); } catch (e) { parts.push(String(err)); }
    }
    return parts.join(' | ');
  },
onSaveRequest(payload) {
    const panelData = payload || {};
    console.log('[save-request]', JSON.stringify(panelData));
  },
_handleReply(func, packet) {
    if (func === protocol.CMD.STATUS) {
      this._applyStatus(protocol.parseStatusPacket(packet, this.typeId) || {});
    } else if (func === protocol.CMD.SENSOR_GET) {
      const s = protocol.parseSensorPacket(packet);
      const panel = this.$refs.sensorPanel;
      if (s && panel) panel.setRealtime(s.sensorId, this._sensorVal(s));
    } else if (func === protocol.CMD.SPEED) {
      const speed = protocol.parseSpeedPacket(packet);
      if (speed != null) this._applySpeed(speed);
    } else if (func === protocol.CMD.FIRMWARE) {
      // 固件版本回包：数据段 3 字节，按 Vx.y.z 展示
      const d = packet.slice(5, packet.length > 5 ? packet.length - 1 : 5);
      const ver = d.length >= 3 ? ('V' + d[0] + '.' + d[1] + '.' + d[2]) : (d.length ? 'V' + d.join('.') : '未知');
      this.setData({ fwVersion: ver });
    } else if (func === protocol.CMD.LINE_ORDER) {
      // 线序查询应答：56 F4 FF 02 00 [order] chk（packet[3]=2）。
      //   设置成功应答是单字节状态帧(packet[3]=1)，不带线序，忽略以免误读校验字节。
      if (packet[3] === 2) {
        const order = packet[5];
        if (order != null && order >= 0 && order <= 5) this.setData({ deviceLineOrder: order });
      }
    } else if (func === protocol.CMD.DRIVER_SCHEME) {
      // 驱动方案查询应答：56 F9 FF 02 00 [scheme] chk（packet[3]=2）
      if (packet[3] === 2) {
        const s = packet[5];
        if (s != null && s >= 0 && s <= 1) this.setData({ deviceDriverScheme: s });
      }
    } else if (func === protocol.CMD.ENERGY_GET) {
      const panel = this.$refs.powerPanel;
      if (panel) panel.setInfo({ voltage: '3.7', current: '0.5', power: '1.85', temp: '32' });
    }
  },
_sensorVal(s) {
    if (!s) return '—';
    const v = s.val || [];
    if (s.sensorId === 0x03 || s.sensorId === 0x04) return v[0] === 0xff ? '有人' : '无人';
    if (s.sensorId === 0x01) return (v[0] || 0) + '.' + (v[1] || 0) + '℃ / ' + (v[2] || 0) + '.' + (v[3] || 0) + '%';
    if (s.sensorId === 0x02) return ((v[0] << 8) | v[1]) + ' lx';
    return 'OK';
  },
deleteDevice() {
    const that = this;
    uni.showModal({
      title: '删除设备',
      content: '确定移除「' + that.deviceName + '」？此操作不可恢复。',
      confirmText: '删除',
      confirmColor: '#e5484d',
      success(res) {
        if (!res.confirm) return;
        if (ble) ble.disconnect(that.deviceId);
        deviceStore.remove(that.deviceId);
        uni.showToast({ title: '已删除', icon: 'none' });
        setTimeout(() => {
          uni.navigateBack({ delta: 1, fail: () => uni.reLaunch({ url: '/pages/index/index' }) });
        }, 400);
      },
    });
  },
  },
}
</script>

<style>
.page-wrap {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: #0a0a14;
}

/* ========== 顶栏 ========== */
.top-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16rpx 28rpx;
  background: #0d0d1a;
}
.top-left {
  display: flex;
  align-items: center;
  gap: 12rpx;
}
.back-icon {
  font-size: 44rpx;
  color: rgba(255,255,255,.7);
  line-height: 1;
  margin-right: 4rpx;
}
.dev-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #e8e8f0;
  max-width: 380rpx;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.edit-icon {
  font-size: 28rpx;
  color: rgba(255,255,255,.35);
}
.top-right {
  display: flex;
  align-items: center;
  gap: 24rpx;
}
.menu-icon {
  font-size: 36rpx;
  color: rgba(255,255,255,.6);
  letter-spacing: 2rpx;
  padding: 4rpx 8rpx;
}
.power-switch {
  width: 72rpx;
  height: 40rpx;
  border-radius: 20rpx;
  background: rgba(255,255,255,.12);
  position: relative;
  transition: background .25s;
}
.ps-knob {
  position: absolute;
  top: 4rpx;
  left: 4rpx;
  width: 32rpx;
  height: 32rpx;
  border-radius: 50%;
  background: #fff;
  transition: transform .25s;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,.3);
}
.power-switch.on {
  background: #a855f7;
  box-shadow: 0 0 12rpx rgba(168,85,247,.4);
}
.power-switch.on .ps-knob {
  transform: translateX(32rpx);
}

/* ========== Tab 栏 ========== */
.tab-bar {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 56rpx;
  padding: 20rpx 0 4rpx;
  background: #0d0d1a;
}
.tab-item {
  font-size: 34rpx;
  font-weight: 500;
  color: rgba(255,255,255,.38);
  position: relative;
  padding-bottom: 14rpx;
  transition: all .25s ease;
}
.tab-item.active {
  color: #fff;
  font-weight: 700;
  text-shadow: 0 0 16rpx rgba(168,85,247,.5);
  transform: scale(1.08);
}
.tab-item.active::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  width: 56rpx;
  height: 5rpx;
  border-radius: 3rpx;
  background: linear-gradient(90deg, #a855f7, #c084fc);
  box-shadow: 0 0 10rpx rgba(168,85,247,.6);
  transform: translateX(-50%) scaleX(0);
  animation: tabSlideIn .3s ease forwards;
}
@keyframes tabSlideIn {
  0%   { transform: translateX(-50%) scaleX(0);   opacity: 0; }
  60%  { transform: translateX(-50%) scaleX(1.2); opacity: 1; }
  100% { transform: translateX(-50%) scaleX(1);   opacity: 1; }
}

/* ========== 内容区 ========== */
.tab-content {
  flex: 1;
  overflow-y: auto;
}

/* 空态 */
.empty-hint {
  text-align: center;
  color: rgba(255,255,255,.3);
  font-size: 28rpx;
  padding: 120rpx 0;
}
</style>
