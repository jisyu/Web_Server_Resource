<template>
<view class="page-wrap">
  <!-- 自定义导航栏 -->
  <view class="custom-nav" :style="'padding-top: ' + (statusBarHeight) + 'px;'">
    <view class="nav-title">智慧世界</view>
  </view>

  <!-- 顶部 Tab -->
  <view class="top-tabs">
    <view :class="'top-tab ' + (currentTopTab === 0 ? 'active' : '')" data-i="0" @tap="switchTopTab">设备</view>
    <view :class="'top-tab ' + (currentTopTab === 1 ? 'active' : '')" data-i="1" @tap="switchTopTab">群组</view>
    <view :class="'top-tab ' + (currentTopTab === 2 ? 'active' : '')" data-i="2" @tap="switchTopTab">联动</view>
    <view :class="'top-tab ' + (currentTopTab === 3 ? 'active' : '')" data-i="3" @tap="switchTopTab">分享</view>
  </view>

  <!-- 设备列表 -->
  <scroll-view scroll-y class="device-list">
    <block v-if="currentTopTab === 0">
      <block v-for="(item, index) in devices" :key="item.deviceId">
        <view class="device-card" @tap="onCardTap" :data-i="(index)">
          <view class="card-icon-box">
            <view class="bt-icon">
              <view class="bt-stem"></view>
              <view class="bt-tri bt-tri-top"></view>
              <view class="bt-tri bt-tri-bottom"></view>
            </view>
          </view>
          <view class="card-body">
            <view class="device-name">{{item.name}}</view>
            <view :class="'device-tag ' + (item.connected ? 'on' : (item.connecting ? 'ing' : 'off'))">
              <view class="tag-dot"></view>
              <text>{{item.connected ? '已连接' : (item.connecting ? '连接中' : '未连接')}}</text>
            </view>
          </view>
          <view class="card-actions" @tap.stop="onDeleteTap" :data-i="(index)">
            <view class="del-btn">
              <text class="del-text">删除</text>
            </view>
          </view>
        </view>
      </block>

      <view v-if="devices.length === 0" class="empty-state">
        <view class="empty-icon">
          <view class="bt-icon big">
            <view class="bt-stem"></view>
            <view class="bt-tri bt-tri-top"></view>
            <view class="bt-tri bt-tri-bottom"></view>
          </view>
        </view>
        <view class="empty-text">暂无设备</view>
        <view class="empty-hint">点击下方添加你的第一台设备</view>
      </view>
    </block>

    <!-- 群组 Tab -->
    <block v-else-if="currentTopTab === 1">
      <block v-for="(item, index) in groupViews" :key="item.id">
        <view class="group-card">
          <view class="group-head">
            <view class="group-info">
              <view class="group-name">{{item.name}}</view>
              <view class="group-count">{{item.memberCount}} 台设备</view>
            </view>
            <view class="card-actions" @tap.stop="deleteGroup" :data-id="(item.id)">
              <view class="del-btn"><text class="del-text">删除</text></view>
            </view>
          </view>
          <view class="member-chips">
            <view v-for="(m, index) in item.members" class="member-chip" :data-id="(m.deviceId)" @tap.stop="openGroupMember" :key="m.deviceId">{{m.name}}</view>
            <view v-if="item.members.length === 0" class="member-empty">暂无成员</view>
          </view>
          <view class="group-foot">
            <view class="group-ctrl-btn" @tap.stop="openGroupControl" :data-id="(item.id)">一键群控</view>
          </view>
        </view>
      </block>
      <view v-if="groupViews.length === 0" class="empty-state">
        <view class="placeholder-icon">⛓</view>
        <view class="empty-text">暂无群组</view>
        <view class="empty-hint">点击下方「添加群组」，对设备分组</view>
      </view>
    </block>

    <!-- 联动 Tab：已添加的联动直接显示在本页，不再跳转子页面 -->
    <block v-else-if="currentTopTab === 2">
      <view v-if="rules.length === 0" class="lk-empty">
        <view class="placeholder-icon">🔗</view>
        <view class="empty-text">还没有联动</view>
        <view class="empty-hint">点击下方「添加联动」创建</view>
      </view>

      <view v-for="(item, index) in rules" class="lk-rule" :key="item.id">
        <view class="lk-rule-head">
          <view class="lk-rule-name">{{item.name}}</view>
          <switch :checked="(item.enabled)" color="#a855f7" @change="toggleEnabled" :data-id="(item.id)" />
        </view>
        <view class="lk-rule-meta">
          <text class="lk-tag lk-tag-trigger">{{item.triggerText}}</text>
          <text class="lk-tag lk-tag-target">{{item.targetText}}</text>
        </view>
        <view class="lk-rule-actions">{{item.actionText}}</view>
        <view class="lk-rule-btns">
          <view class="lk-rbtn lk-rbtn-run" @tap="runRule" :data-id="(item.id)">执行</view>
          <view class="lk-rbtn lk-rbtn-edit" @tap="openEdit" :data-id="(item.id)">编辑</view>
          <view class="lk-rbtn lk-rbtn-del" @tap="deleteRule" :data-id="(item.id)">删除</view>
        </view>
      </view>
    </block>

    <!-- 分享 Tab -->
    <block v-else-if="currentTopTab === 3">
      <view class="share-card">
        <view class="share-summary">
          <view class="share-stat"><text class="share-num">{{shareDevN}}</text><text class="share-label">设备</text></view>
          <view class="share-stat"><text class="share-num">{{shareGrpN}}</text><text class="share-label">群组</text></view>
        </view>
        <view class="share-desc">把本机的设备与群组配置分享给好友，或在另一台设备导入。</view>
        <button class="share-btn primary" @tap="exportConfig">导出配置（复制到剪贴板）</button>
        <button class="share-btn" @tap="shareViaSystem">分享配置给好友</button>
      </view>
    </block>
  </scroll-view>

  <!-- 联动编辑弹层（页面级 fixed，不放在 scroll-view 内，避免被裁剪） -->
  <view v-if="showEditor" class="lk-mask" @tap="closeEditor">
    <view class="lk-sheet" @tap.stop="noop">
      <view class="lk-title">{{isEdit ? '编辑联动' : '添加联动'}}</view>
      <scroll-view scroll-y class="lk-body">
        <!-- 名称 -->
        <view class="fld">
          <text class="fld-label">名称</text>
          <input class="fld-input" placeholder="如：回家自动开灯" :value="(edName)" @input="onNameInput" />
        </view>

        <!-- 触发条件 -->
        <view class="sec-title">触发条件</view>
        <view class="seg">
          <view :class="'seg-item ' + (triggerType === 'manual' ? 'active' : '')" data-t="manual" @tap="switchTrigger">手动执行</view>
          <view :class="'seg-item ' + (triggerType === 'time' ? 'active' : '')" data-t="time" @tap="switchTrigger">定时执行</view>
        </view>
        <view v-if="triggerType === 'time'">
          <view class="sub-label">定时方式</view>
          <view class="seg small">
            <view :class="'seg-item ' + (timeMode === 'absolute' ? 'active' : '')" data-m="absolute" @tap="switchTimeMode">绝对时间</view>
            <view :class="'seg-item ' + (timeMode === 'relative' ? 'active' : '')" data-m="relative" @tap="switchTimeMode">相对时间</view>
          </view>
          <view v-if="timeMode === 'absolute'" class="time-row">
            <picker mode="time" :value="(triggerTimeStr)" @change="onTimePick">
              <view class="time-pick">{{triggerTimeStr}}</view>
            </picker>
            <text class="muted" style="display:block;margin-top:12rpx;">每天到该时刻自动执行</text>
          </view>
          <view v-else class="rel-row">
            <text class="muted" style="display:block;margin-bottom:14rpx;">启用后经过以下时长执行一次</text>
            <view class="rel-input-row">
              <input class="rel-input" type="number" placeholder="如 30" :value="(relValue)" @input="onRelValue" />
              <view class="seg rel-seg">
                <view :class="'seg-item ' + (relUnit === 'min' ? 'active' : '')" data-u="min" @tap="switchRelUnit">分钟</view>
                <view :class="'seg-item ' + (relUnit === 'hour' ? 'active' : '')" data-u="hour" @tap="switchRelUnit">小时</view>
              </view>
            </view>
          </view>
        </view>

        <!-- 作用目标 -->
        <view class="sec-title">作用目标（设备 / 群组）</view>
        <view class="sub-label">设备</view>
        <view v-for="(item, index) in targetDevices" class="pick-row" :data-i="(index)" @tap="toggleTargetDev" :key="item.deviceId">
          <view :class="'pick-check ' + (item.selected ? 'on' : '')"></view>
          <text class="pick-name">{{item.name}}</text>
        </view>
        <view v-if="targetDevices.length === 0" class="muted">暂无设备，请先在「设备」中添加</view>
        <view class="sub-label">群组</view>
        <view v-for="(item, index) in targetGroups" class="pick-row" :data-i="(index)" @tap="toggleTargetGrp" :key="item.id">
          <view :class="'pick-check ' + (item.selected ? 'on' : '')"></view>
          <text class="pick-name">{{item.name}}</text>
        </view>
        <view v-if="targetGroups.length === 0" class="muted">暂无群组，请先在「群组」中创建</view>

        <!-- 灯光动作 -->
        <view class="sec-title">灯光动作</view>

        <view class="act-block">
          <view class="act-head"><text>开关</text><switch :checked="(enPower)" color="#a855f7" @change="toggleEn" data-k="enPower" /></view>
          <view v-if="enPower" class="seg small">
            <view :class="'seg-item ' + (actions.powerOn === 1 ? 'active' : '')" data-v="1" @tap="setPower">开</view>
            <view :class="'seg-item ' + (actions.powerOn === 0 ? 'active' : '')" data-v="0" @tap="setPower">关</view>
          </view>
        </view>

        <view class="act-block">
          <view class="act-head"><text>亮度</text><switch :checked="(enBright)" color="#a855f7" @change="toggleEn" data-k="enBright" /></view>
          <view v-if="enBright" class="slider-row">
            <slider min="0" max="100" :value="(editBright)" @changing="onEditBright" @change="onEditBright" activeColor="#a855f7" backgroundColor="#2a2a40" block-size="20" />
            <text class="slider-val">{{editBright}}%</text>
          </view>
        </view>

        <view class="act-block">
          <view class="act-head"><text>颜色</text><switch :checked="(enColor)" color="#a855f7" @change="toggleEn" data-k="enColor" /></view>
          <view v-if="enColor" class="rgb-rows">
            <view class="rgb-r"><text class="rgb-l">R</text><slider min="0" max="255" :value="(editR)" @changing="onEditR" @change="onEditR" activeColor="#ff5a5a" backgroundColor="#2a2a40" block-size="16" /><text class="rgb-v">{{editR}}</text></view>
            <view class="rgb-r"><text class="rgb-l">G</text><slider min="0" max="255" :value="(editG)" @changing="onEditG" @change="onEditG" activeColor="#4ade80" backgroundColor="#2a2a40" block-size="16" /><text class="rgb-v">{{editG}}</text></view>
            <view class="rgb-r"><text class="rgb-l">B</text><slider min="0" max="255" :value="(editB)" @changing="onEditB" @change="onEditB" activeColor="#5a8bff" backgroundColor="#2a2a40" block-size="16" /><text class="rgb-v">{{editB}}</text></view>
          </view>
        </view>

        <view class="act-block">
          <view class="act-head"><text>色温</text><switch :checked="(enWarm)" color="#a855f7" @change="toggleEn" data-k="enWarm" /></view>
          <view v-if="enWarm" class="slider-row">
            <slider min="0" max="100" :value="(editWarm)" @changing="onEditWarm" @change="onEditWarm" activeColor="#f0a868" backgroundColor="#2a2a40" block-size="20" />
            <text class="slider-val">{{editWarm}}</text>
          </view>
        </view>

        <view class="act-block">
          <view class="act-head"><text>场景</text><switch :checked="(enMode)" color="#a855f7" @change="toggleEn" data-k="enMode" /></view>
          <view v-if="enMode">
            <view v-for="(cat, index) in sceneCats" class="scene-cat" :key="cat.name">
              <view class="sub-label">{{cat.name}}</view>
              <view class="scene-row">
                <view v-for="(s, index) in cat.scenes" :class="'scene-btn ' + (actions.mode === s.id ? 'active' : '')" :data-id="(s.id)" @tap="pickScene" :key="s.id">
                  <text class="scene-icon">{{s.id}}</text>
                  <text class="scene-name">{{s.name}}</text>
                </view>
              </view>
            </view>
          </view>
        </view>

        <view class="act-block">
          <view class="act-head"><text>音乐律动</text><switch :checked="(enMusic)" color="#a855f7" @change="toggleEn" data-k="enMusic" /></view>
          <view v-if="enMusic" class="music-grid">
            <view v-for="(item, index) in musicList" :class="'music-btn ' + (actions.music === item.id ? 'active' : '')" :data-id="(item.id)" @tap="pickMusic" :key="item.id">
              <text class="music-icon">{{item.icon}}</text>
              <text class="music-name">{{item.name}}</text>
            </view>
          </view>
        </view>

        <view class="act-block">
          <view class="act-head"><text>拾音灵敏度</text><switch :checked="(enMic)" color="#a855f7" @change="toggleEn" data-k="enMic" /></view>
          <view v-if="enMic" class="slider-row">
            <slider min="0" max="100" :value="(editMic)" @changing="onEditMic" @change="onEditMic" activeColor="#a855f7" backgroundColor="#2a2a40" block-size="20" />
            <text class="slider-val">{{editMic}}</text>
          </view>
        </view>
      </scroll-view>

      <view class="lk-actions">
        <view class="lk-btn lk-btn-cancel" @tap="closeEditor">取消</view>
        <view class="lk-btn lk-btn-confirm" @tap="saveRule">{{isEdit ? '保存' : '添加'}}</view>
      </view>
    </view>
  </view>

  <!-- 底部按钮（随 Tab 切换文案与动作） -->
  <view class="bottom-area" style="padding-bottom: calc(env(safe-area-inset-bottom) + 24rpx);">
    <view class="add-btn" @tap="onBottomAction">
      <view class="add-icon">+</view>
      <text v-if="currentTopTab === 0">添加新的设备</text>
      <text v-else-if="currentTopTab === 1">添加群组</text>
      <text v-else-if="currentTopTab === 3">导出配置</text>
      <text v-else>添加联动</text>
    </view>
  </view>

  <!-- 群组创建 / 编辑 底部弹层 -->
  <view v-if="showGroupEditor" class="editor-mask" @tap="cancelGroupEditor">
    <view class="editor-sheet" @tap.stop="noop">
      <view class="editor-title">添加群组</view>
      <input class="editor-input" placeholder="输入群组名称" placeholder-class="editor-ph" :value="(groupName)" @input="onGroupNameInput" maxlength="20" />
      <view class="editor-subtitle">选择设备（{{groupCandidates.length}}）</view>
      <scroll-view scroll-y class="candidate-list">
        <checkbox-group class="candidate-group" @change="onGroupCandidatesChange">
          <label v-for="item in groupCandidates" :class="'candidate ' + (item.selected ? 'sel' : '')" :key="item.deviceId">
            <checkbox :value="item.deviceId" :checked="item.selected" color="#a78bfa" style="transform:scale(.9)" />
            <text class="c-name">{{item.name}}</text>
          </label>
        </checkbox-group>
        <view v-if="groupCandidates.length === 0" class="candidate-empty">暂无设备可选，请先添加设备</view>
      </scroll-view>
      <view class="editor-actions">
        <view class="editor-btn cancel" @tap="cancelGroupEditor">取消</view>
        <view class="editor-btn confirm" @tap="confirmGroup">确定</view>
      </view>
    </view>
  </view>

  <!-- 群组群控 底部弹层 -->
  <view v-if="showGroupControl" class="editor-mask" @tap="closeGroupControl">
    <view class="editor-sheet" @tap.stop="noop">
      <view class="editor-title">{{controlGroupName}} · 群控</view>

      <!-- 成员在线概览 -->
      <scroll-view scroll-y class="ctrl-members ctrl-members-sm">
        <view v-for="(item, index) in controlMembers" class="ctrl-member" :key="item.deviceId">
          <view :class="'ctrl-dot ' + (item.connected ? 'on' : 'off')"></view>
          <text class="ctrl-m-name">{{item.name}}</text>
          <text :class="'ctrl-m-state ' + (item.connected ? 'on' : 'off')">{{item.connected ? '在线' : '离线'}}</text>
        </view>
        <view v-if="controlMembers.length === 0" class="candidate-empty">暂无成员</view>
      </scroll-view>

      <!-- 全局常显：一键开关（亮度由下方设备面板统一控制，不重复） -->
      <view class="ctrl-global">
        <view class="ctrl-power-row">
          <view class="ctrl-power-btn off" @tap="controlAllPower" data-on="0">全部关闭</view>
          <view class="ctrl-power-btn on" @tap="controlAllPower" data-on="1">全部开启</view>
        </view>
      </view>

      <!-- 内容区：与单设备控制页 1:1（light-panel，指令群发） -->
      <scroll-view scroll-y class="ctrl-body">
        <light-panel :typeId="(controlPanelTypeId)" :caps="(controlCaps)" :deviceName="(controlGroupName)" @cmd="onGroupPanelCmd" />
      </scroll-view>

      <view class="editor-actions">
        <view class="editor-btn cancel" @tap="closeGroupControl">关闭</view>
      </view>
    </view>
  </view>
</view>
</template>

<script>
import protocol from '@/utils/protocol'
import { getDeviceMeta, isHsvType } from '@/utils/deviceType';
import deviceStore from '@/utils/deviceStore';
import { ble, AUTO_CONNECT_TIMEOUT } from '@/utils/ble';
import linkageStore from '@/utils/linkageStore';

// 场景预设：统一来自 utils/sceneModes.js（与 light-panel 共用同一份 61 模式库）
import sceneModes from '@/utils/sceneModes';
import { ensureBluetoothPermission } from '@/utils/permission';
const SCENE_CATS = sceneModes.buildSceneCats();

// 音乐律动选项（与协议 0x07 律动1~6 对应；群控 controlMusicList 与联动 musicList 共用）
const MUSIC_LIST = [
  { id: 1, name: '律动1', icon: '🎵' },
  { id: 2, name: '律动2', icon: '🎶' },
  { id: 3, name: '律动3', icon: '🥁' },
  { id: 4, name: '律动4', icon: '🎸' },
  { id: 5, name: '律动5', icon: '🎹' },
  { id: 6, name: '律动6', icon: '🎺' },
];

export default {
data() {
    return {
    devices: [],       // 已绑定设备列表（含 connecting/connected 态）
    _offBleConnection: null,
    bleReady: false,   // BLE 是否已初始化
    currentTopTab: 0,  // 0 设备 / 1 群组 / 2 联动 / 3 分享
    shareDevN: 0,      // 分享页：已绑定设备数
    shareGrpN: 0,      // 分享页：群组数
    statusBarHeight: 44,

    // 群组
    groupViews: [],    // 渲染用：群组 + 已解析成员名 [{id,name,memberCount,members:[{deviceId,name}]}]
    showGroupEditor: false, // 群组创建/编辑底部弹层
    groupName: '',     // 弹层中输入的名称
    groupCandidates: [],   // 候选设备（含 selected 标记）

    // 群组群控
    showGroupControl: false,    // 群控底部弹层
    controlGroupId: '',
    controlGroupName: '',
    // 群控面板（light-panel）所需的设备能力与类型：设备 members 聚合后得到
    controlPanelTypeId: 0x1001,
    controlCaps: {},
    controlMembers: [],         // [{deviceId,name,typeId,connected}]
    controlBrightness: 100,     // 亮度百分比 0~100

    // 群控子 Tab：0 颜色 / 1 场景 / 2 音乐（开头/亮度已提到全局常显，不占 Tab）
    controlSub: 0,
    controlColors: [],          // 常用颜色 hex（从 storage 读）
    controlR: 126, controlG: 97, controlB: 255, // 当前自定义 RGB
    controlWarmCool: 50,        // 色温 0~100
    controlSceneCats: [],       // 场景分类（SCENE_CATS）
    controlMusic: 0,            // 当前律动（0=关闭，1~6=律动模式）
    controlMic: 50,             // 拾音器灵敏度 0~100
    controlMusicList: MUSIC_LIST,  // 群控音乐律动选项（与协议 0x07 律动1~6 对应）

    // ===== 联动（直接显示在首页联动 Tab，不再跳转子页面）=====
    rules: [],            // 渲染列表 [{id,name,enabled,triggerText,targetText,actionText}]
    showEditor: false,
    isEdit: false,
    editId: '',
    edName: '',
    triggerType: 'manual',  // manual / time
    triggerHour: 20,
    triggerMin: 0,
    triggerTimeStr: '20:00',
    timeMode: 'absolute',   // absolute / relative
    relValue: 30,           // 相对时间数值（分钟/小时）
    relUnit: 'min',         // min / hour
    targetDevices: [],    // [{deviceId,name,selected}]
    targetGroups: [],     // [{id,name,selected}]
    actions: { powerOn: 1, mode: null, music: null },
    enPower: true, enBright: true, enColor: false, enWarm: false, enMode: false, enMusic: false, enMic: false,
    editR: 126, editG: 97, editB: 255,
    editBright: 100, editWarm: 50, editMic: 50,
    sceneCats: SCENE_CATS,
    musicList: MUSIC_LIST,
  }
  },
onLoad() {
    const sys = uni.getWindowInfo ? uni.getWindowInfo() : uni.getSystemInfoSync();
    this.setData({ statusBarHeight: sys.statusBarHeight || 44 });
  },
onShow() {
    // 小程序打开 / 从子页返回时：确保 BLE 就绪，并自动连接已保存设备
    this._bindBleConnectionEvents();
    this._ensureBLE().then(() => this.refreshAndAutoConnect());
    this._loadRules();
    this._startTimerChecker();
  },
onHide() {
    this._stopTimerChecker();
  },
onUnload() {
    this._stopTimerChecker();
    if (this._offBleConnection) { this._offBleConnection(); this._offBleConnection = null; }
  },
onShareAppMessage() {
    this.shareViaSystem();
  },

  methods: {
_bindBleConnectionEvents() {
    if (this._offBleConnection || !ble || !ble.subscribeConnectionChange) return;
    this._offBleConnection = ble.subscribeConnectionChange((res) => {
      const device = this.devices.find((item) => item.deviceId.toLowerCase() === String(res.deviceId || '').toLowerCase());
      if (!device) return;
      this._patchDevice(device.deviceId, { connected: !!res.connected, connecting: false });
      if (this.currentTopTab === 1) this._loadGroups();
    });
  },
async _ensureBLE() {
    if (this.bleReady) return;

    if (!ble) return;
    try {
      // App 端：自行申请蓝牙/定位运行时权限（小程序里由 wx.authorize 代理）
      await ensureBluetoothPermission();
      await ble.init();
      this.setData({ bleReady: true });
    } catch (e) {
      uni.showToast({ title: 'BLE 初始化失败', icon: 'none' });
    }
  },
async refreshAndAutoConnect() {
    this.refresh();

    if (!ble || !this.bleReady) return;
    const saved = deviceStore.getSaved();
    const tasks = saved.map((d) => this._autoConnectOne(d.deviceId));
    await Promise.allSettled(tasks);
    this.refresh(); // 用最终连接态刷新
    if (this.currentTopTab === 1) this._loadGroups(); // 群组 Tab 同步成员连接态/名称
  },
async _autoConnectOne(deviceId) {

    if (ble.isConnected(deviceId)) return true;
    this._patchDevice(deviceId, { connecting: true, connected: false });
    try {
      await ble.connect(deviceId, AUTO_CONNECT_TIMEOUT);
      this._patchDevice(deviceId, { connecting: false, connected: true });
      return true;
    } catch (e) {
      this._patchDevice(deviceId, { connecting: false, connected: false });
      ble._log('[BLE][AUTO-CONNECT] dev=' + deviceId + ' err=' + (e && (e.errMsg || e.message || e)), 'warn');
      return false;
    }
  },
_patchDevice(deviceId, patch) {
    const devices = this.devices.map((d) =>
      d.deviceId === deviceId ? Object.assign({}, d, patch) : d
    );
    this.setData({ devices });
  },
refresh() {

    const saved = deviceStore.sanitize(); // 先剔除无 deviceId 的垃圾条目
    const devices = saved.map((d) => {
      const meta = getDeviceMeta(d.typeId);
      return {
        deviceId: d.deviceId,
        name: d.name || '未命名设备',
        model: d.model || (meta ? meta.name : ''),
        typeId: d.typeId,
        typeName: meta ? meta.name : '未知',
        shortId: d.shortId || '',
        connected: !!(ble && ble.isConnected(d.deviceId)),
        connecting: false,
      };
    });
    this.setData({ devices });
  },
switchTopTab(e) {
    const i = Number(e.currentTarget.dataset.i);
    this.setData({ currentTopTab: i, showEditor: false }); // 切 Tab 时收起联动编辑弹层，避免残影
    if (i === 1) this._loadGroups(); // 切到群组 Tab 时加载群组
    else if (i === 3) this._loadShareStats(); // 切到分享 Tab 时刷新统计
  },
onBottomAction() {
    if (this.currentTopTab === 0) this.goAdd();
    else if (this.currentTopTab === 1) this.openGroupEditor();
    else if (this.currentTopTab === 3) this.exportConfig(); // 分享 Tab → 导出配置
    else this.openAdd(); // 联动 Tab → 直接在当前页打开添加弹层（不跳转子页面）
  },
goAdd() {
    uni.navigateTo({ url: '/pages/add-device/add-device' });
  },
_loadShareStats() {
    this.setData({
      shareDevN: deviceStore.getSaved().length,
      shareGrpN: deviceStore.getGroups().length,
    });
  },
exportConfig() {
    const payload = {
      app: 'Light_RGBYW',
      version: 1,
      exportedAt: Date.now(),
      devices: deviceStore.getSaved(),
      groups: deviceStore.getGroups(),
    };
    const text = JSON.stringify(payload);
    uni.setClipboardData({
      data: text,
      success: () => uni.showToast({ title: '配置已复制，可发给好友导入', icon: 'none' }),
      fail: () => uni.showToast({ title: '复制失败', icon: 'none' }),
    });
  },
async shareViaSystem() {
    const text = JSON.stringify({
      app: 'Light_RGBYW',
      version: 1,
      exportedAt: Date.now(),
      devices: deviceStore.getSaved(),
      groups: deviceStore.getGroups(),
    });
    // #ifdef APP-PLUS
    if (plus.share && plus.share.sendWithSystem) {
      plus.share.sendWithSystem(
        { content: text, title: 'Light_RGBYW 设备与群组配置' },
        () => {},
        (err) => {
          console.warn('[share] 系统分享失败，降级为复制', err);
          this.exportConfig();
        }
      );
      return;
    }
    // #endif
    this.exportConfig();
  },
noop() {},
_loadGroups() {
    const groups = deviceStore.getGroups();
    const byId = {};
    this.devices.forEach((d) => { byId[d.deviceId] = d; });
    const groupViews = groups.map((g) => {
      const members = (g.deviceIds || []).map((id) => ({
        deviceId: id,
        name: byId[id] ? byId[id].name : '未知设备',
        typeId: byId[id] ? byId[id].typeId : 1,
      }));
      return Object.assign({}, g, { memberCount: members.length, members });
    });
    this.setData({ groupViews });
  },
openGroupEditor() {
    if (!this.devices.length) {
      uni.showToast({ title: '请先添加设备', icon: 'none' });
      return;
    }
    const candidates = this.devices.map((d) => ({
      deviceId: d.deviceId,
      name: d.name || '未命名设备',
      selected: false,
    }));
    this.setData({ showGroupEditor: true, groupName: '', groupCandidates: candidates });
  },
onGroupNameInput(e) {
    this.setData({ groupName: e.detail.value });
  },
onGroupCandidatesChange(e) {
    const selectedIds = new Set((e.detail && e.detail.value) || []);
    const groupCandidates = this.groupCandidates.map((candidate) =>
      Object.assign({}, candidate, { selected: selectedIds.has(candidate.deviceId) })
    );
    this.setData({ groupCandidates });
  },
cancelGroupEditor() {
    this.setData({ showGroupEditor: false, groupName: '', groupCandidates: [] });
  },
confirmGroup() {
    const name = (this.groupName || '').trim();
    if (!name) {
      uni.showToast({ title: '请输入群组名称', icon: 'none' });
      return;
    }
    const deviceIds = this.groupCandidates
      .filter((c) => c.selected)
      .map((c) => c.deviceId);
    if (deviceIds.length === 0) {
      uni.showToast({ title: '请至少选择一个设备', icon: 'none' });
      return;
    }
    deviceStore.saveGroup({ name, deviceIds });
    this.setData({ showGroupEditor: false, groupName: '', groupCandidates: [] });
    this._loadGroups();
    uni.showToast({ title: '已创建群组', icon: 'success' });
  },
deleteGroup(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    const that = this;
    uni.showModal({
      title: '删除群组',
      content: '确定删除该群组？',
      confirmText: '删除',
      confirmColor: '#ef4444',
      success(res) {
        if (!res.confirm) return;
        deviceStore.removeGroup(id);
        that._loadGroups();
      },
    });
  },
openGroupMember(e) {
    const deviceId = e.currentTarget.dataset.id;
    const d = this.devices.find((x) => x.deviceId === deviceId);
    if (!d) return;
    uni.navigateTo({ url: `/pages/device/device?deviceId=${deviceId}&typeId=${d.typeId != null ? d.typeId : 1}` });
  },
openGroupControl(e) {
    const id = e.currentTarget.dataset.id;
    const g = this.groupViews.find((x) => x.id === id);
    if (!g) return;

    const members = g.members.map((m) => Object.assign({}, m, {
      connected: !!(ble && ble.isConnected(m.deviceId)),
    }));
    this.setData({
      showGroupControl: true,
      controlGroupId: id,
      controlGroupName: g.name,
      controlMembers: members,
      controlBrightness: 100,
      controlSub: 0,
      controlColors: (uni.getStorageSync('recentLightColors') || []).filter((c) => c),
      controlR: 126, controlG: 97, controlB: 255,
      controlWarmCool: 50,
      controlSceneCats: SCENE_CATS,
      controlMusic: 0,
      controlMic: 50,
      // 设备面板（复用 light-panel）：取首个成员的类型作为面板类型
      controlPanelTypeId: this._panelTypeIdOf(members),
      controlCaps: this._panelCapsOf(members),
    });
  },
_panelTypeIdOf(members) {
    const first = (members || [])[0];
    return first && first.typeId != null ? first.typeId : 0x1001;
  },
_panelCapsOf(members) {
    return getDeviceMeta(this._panelTypeIdOf(members)).caps || {};
  },
async onGroupPanelCmd(payload) {
    const { func, data, silent } = payload || {};
    if (!ble) return;
    const members = (this.controlMembers || []).filter((m) => ble.isConnected(m.deviceId));
    if (!members.length) {
      if (!silent) uni.showToast({ title: '群组成员未连接，请先返回设备页连接', icon: 'none' });
      return;
    }
    let ok = 0;
    let fail = 0;
    for (const member of members) {
      try {
        await ble.write(member.deviceId, func, data);
        ok++;
      } catch (error) {
        fail++;
        if (!silent) console.warn('[GROUP] cmd failed', member.name, error && (error.message || error));
      }
    }
    if (!silent) {
      const title = fail === 0 ? ('已控制 ' + ok + ' 台设备') : (ok + ' 台成功，' + fail + ' 台失败');
      uni.showToast({ title, icon: 'none' });
    }
  },
closeGroupControl() {
    this.setData({ showGroupControl: false, controlMembers: [] });
  },
onControlBrightness(e) {
    this.setData({ controlBrightness: e.detail.value });
  },
_memberBrightness(typeId, pct) {
    const max = isHsvType(typeId) ? 1000 : 100;
    const v = Math.max(0, Math.min(max, Math.round((pct / 100) * max)));
    return protocol.light.brightness(typeId, v);
  },
async _broadcast(func, buildData) {

    const connected = (ble ? this.controlMembers.filter((m) => ble.isConnected(m.deviceId)) : []);
    if (connected.length === 0) {
      return { ok: 0, fail: this.controlMembers.length, fails: this.controlMembers.map((m) => m.name) };
    }
    let ok = 0, fail = 0;
    const fails = [];
    for (const m of connected) {
      try {
        await ble.write(m.deviceId, func, buildData(m));
        ok++;
      } catch (err) {
        fail++;
        fails.push(m.name);
      }
    }
    return { ok, fail, fails };
  },
_toastGroupResult(res, okMsg) {
    if (res.ok > 0 && res.fail === 0) {
      uni.showToast({ title: okMsg, icon: 'success' });
    } else if (res.ok === 0) {
      uni.showToast({ title: '请先连接设备', icon: 'none' });
    } else {
      uni.showToast({ title: `成功 ${res.ok} 台，失败 ${res.fail} 台`, icon: 'none' });
    }
  },
async controlAllPower(e) {
    const on = e.currentTarget.dataset.on === '1';
    uni.showLoading({ title: '下发中…' });
    const res = await this._broadcast(protocol.CMD.POWER, (m) => protocol.light.power(on));
    uni.hideLoading();
    this._toastGroupResult(res, on ? '已全开' : '已全关');
    this._loadGroups(); // 同步成员连接态
  },
async applyControlBrightness() {
    const pct = this.controlBrightness;
    uni.showLoading({ title: '下发中…' });
    const res = await this._broadcast(protocol.CMD.BRIGHTNESS, (m) => this._memberBrightness(m.typeId, pct));
    uni.hideLoading();
    this._toastGroupResult(res, '亮度已同步');
    this._loadGroups();
  },
switchControlSub(e) {
    this.setData({ controlSub: Number(e.currentTarget.dataset.i) });
  },
_buildColorData(m) {
    const { controlR: r, controlG: g, controlB: b } = this.data;
    if (isHsvType(m.typeId)) {
      const [hf, sf] = this._rgb2hsv(r, g, b);
      return protocol.light.color(m.typeId, { h: Math.round(hf * 360), s: Math.round(sf * 1000), r, g, b });
    }
    return protocol.light.color(m.typeId, { r, g, b });
  },
async controlColorByHex(e) {
    const hex = e.currentTarget.dataset.hex;
    if (!hex) return;
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    this.setData({ controlR: r, controlG: g, controlB: b });
    await this.applyControlColor();
  },
onControlRgb(e) {
    const key = e.currentTarget.dataset.c; // 'r' | 'g' | 'b'
    this.setData({ ['control' + key.toUpperCase()]: e.detail.value });
  },
async applyControlColor() {
    uni.showLoading({ title: '下发中…' });
    const res = await this._broadcast(protocol.CMD.COLOR, (m) => this._buildColorData(m));
    uni.hideLoading();
    this._toastGroupResult(res, '颜色已同步');
    this._loadGroups();
  },
onControlWarmCool(e) {
    this.setData({ controlWarmCool: e.detail.value });
  },
async applyControlWarmCool() {
    const v = this.controlWarmCool;

    const members = ble ? this.controlMembers.filter((m) => ble.isConnected(m.deviceId)) : [];
    if (!members.length) {
      this._toastGroupResult({ ok: 0, fail: this.controlMembers.length, fails: [] }, '色温已同步');
      return;
    }
    uni.showLoading({ title: '下发中…' });
    let ok = 0;
    const fails = [];
    for (const m of members) {
      const frames = protocol.cwFrames(m.typeId, v, this.controlBrightness);
      if (!frames.length) { fails.push(m.name); continue; }
      try {
        for (const f of frames) await ble.write(m.deviceId, f[0], f[1]);
        ok++;
      } catch (err) {
        fails.push(m.name);
      }
    }
    uni.hideLoading();
    this._toastGroupResult({ ok, fail: fails.length, fails }, '色温已同步');
    this._loadGroups();
  },
async applyControlScene(e) {
    const id = Number(e.currentTarget.dataset.id);
    uni.showLoading({ title: '下发中…' });
    const res = await this._broadcast(protocol.CMD.MODE, (m) => protocol.light.mode(m.typeId, id));
    uni.hideLoading();
    this._toastGroupResult(res, '场景已应用');
    this._loadGroups();
  },
async applyControlMusic(e) {
    const id = Number(e.currentTarget.dataset.id);
    this.setData({ controlMusic: id });
    uni.showLoading({ title: '下发中…' });
    const res = await this._broadcast(protocol.CMD.MUSIC, () => protocol.light.music(id));
    uni.hideLoading();
    this._toastGroupResult(res, id === 0 ? '已关闭律动' : '律动已开启');
    this._loadGroups();
  },
onControlMic(e) {
    this.setData({ controlMic: e.detail.value });
  },
async applyControlMic() {
    const v = this.controlMic;
    uni.showLoading({ title: '下发中…' });
    const res = await this._broadcast(protocol.CMD.MIC, () => protocol.light.mic(v));
    uni.hideLoading();
    this._toastGroupResult(res, '灵敏度已同步');
    this._loadGroups();
  },
_rgb2hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const d = max - min;
    let h = 0;
    if (d !== 0) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h /= 6;
      if (h < 0) h += 1;
    }
    const s = max === 0 ? 0 : d / max;
    return [h, s];
  },
onCardTap(e) {
    const d = this.devices[e.currentTarget.dataset.i];
    if (!d) return;
    if (d.connected) {
      this.openDevice(e);
    } else {
      this.manualConnect(e);
    }
  },
openDevice(e) {
    const d = this.devices[e.currentTarget.dataset.i];
    uni.navigateTo({ url: `/pages/device/device?deviceId=${d.deviceId}&typeId=${d.typeId != null ? d.typeId : 1}` });
  },
async manualConnect(e) {
    const d = this.devices[e.currentTarget.dataset.i];
    if (!d) return;
    this._patchDevice(d.deviceId, { connecting: true });
    try {
      await ble.connect(d.deviceId, 10000);
      this._patchDevice(d.deviceId, { connecting: false, connected: true });
      // 仅标记已连接，进入哪台由用户点卡片决定
    } catch (err) {
      this._patchDevice(d.deviceId, { connecting: false, connected: false });
      uni.showToast({ title: '连接失败，请重试', icon: 'none' });
    }
  },
onDeleteTap(e) {
    const i = e.currentTarget.dataset.i;
    const d = this.devices[i];
    if (!d) return;
    const that = this;
    uni.showModal({
      title: '删除设备',
      content: `确定移除「${d.name}」？`,
      confirmText: '删除',
      confirmColor: '#ef4444',
      success(res) {
        if (!res.confirm) return;

        if (ble) { try { ble.disconnect(d.deviceId); } catch (_) {} }
        deviceStore.remove(d.deviceId);
        deviceStore.pruneDeviceFromGroups(d.deviceId); // 同步从群组移除该设备
        const devices = that.devices.filter((x) => x.deviceId !== d.deviceId);
        that.setData({ devices });
        if (that.currentTopTab === 1) that._loadGroups();
      },
    });
  },
async   togglePower(e) {
    e.stopPropagation();
    const idx = e.currentTarget.dataset.i;
    const d = this.devices[idx];

    if (!ble || !ble.isConnected(d.deviceId)) {
      uni.showToast({ title: '请先连接设备', icon: 'none' });
      return;
    }
    try {
      const packet = await ble.write(d.deviceId, 0, [d.powerState ? 0 : 1]);
      const r = protocol.parseResult(packet[4]);
      if (!r.ok) uni.showToast({ title: r.msg, icon: 'none' });
    } catch (err) {
      uni.showToast({ title: '操作失败', icon: 'none' });
    }
  },
_pad(n) { return (n < 10 ? '0' : '') + n; },
_loadRules() {
    const devices = deviceStore.getSaved();
    const groups = deviceStore.getGroups();
    const rules = linkageStore.getRules().map((r) => {
      const devN = (r.targets || []).filter((t) => t.type === 'device').length;
      const grpN = (r.targets || []).filter((t) => t.type === 'group').length;
      const targetParts = [];
      if (devN) targetParts.push(devN + '台设备');
      if (grpN) targetParts.push(grpN + '个群组');
      let triggerText = '手动执行';
      if (r.trigger && r.trigger.type === 'time') {
        if (r.trigger.timeMode === 'relative') {
          triggerText = '相对 ' + (r.trigger.relValue || 0) + (r.trigger.relUnit === 'hour' ? '小时后' : '分钟后');
        } else {
          triggerText = '定时 ' + this._pad(r.trigger.hour) + ':' + this._pad(r.trigger.min);
        }
      }
      return Object.assign({}, r, {
        targetText: targetParts.join(' + ') || '未选目标',
        triggerText,
        actionText: this._actionSummary(r.actions),
      });
    });
    this.setData({ rules });
  },
_modeName(id) {
    return sceneModes.modeName(id);
  },
_actionSummary(a) {
    if (!a) return '无动作';
    const p = [];
    if (a.power != null) p.push(a.power ? '开灯' : '关灯');
    if (a.brightness != null) p.push('亮度' + a.brightness + '%');
    if (a.color) p.push('颜色');
    if (a.warmCool != null) p.push('色温' + a.warmCool);
    const mn = this._modeName(a.mode);
    if (mn) p.push('场景:' + mn);
    if (a.music != null) p.push(a.music ? ('律动' + a.music) : '关律动');
    if (a.mic != null) p.push('拾音' + a.mic);
    return p.length ? p.join(' · ') : '无动作';
  },
openAdd() {
    if (!deviceStore.getSaved().length) {
      uni.showToast({ title: '请先添加设备', icon: 'none' });
      return;
    }
    this._initEditor({});
  },
openEdit(e) {
    const id = e.currentTarget.dataset.id;
    const r = linkageStore.getRules().find((x) => x.id === id);
    if (!r) return;
    this._initEditor(r);
  },
_initEditor(r) {
    const devices = deviceStore.getSaved().map((d) => ({ deviceId: d.deviceId, name: d.name || '未命名', selected: false }));
    const groups = deviceStore.getGroups().map((g) => ({ id: g.id, name: g.name || '群组', selected: false }));
    const tset = {};
    (r.targets || []).forEach((t) => { tset[(t.type === 'group' ? 'g' : 'd') + t.id] = true; });
    devices.forEach((d) => { if (tset['d' + d.deviceId]) d.selected = true; });
    groups.forEach((g) => { if (tset['g' + g.id]) g.selected = true; });

    const a = r.actions || {};
    const trig = r.trigger || { type: 'manual' };
    const h = trig.hour != null ? trig.hour : 20;
    const m = trig.min != null ? trig.min : 0;
    const timeMode = trig.type === 'time' && trig.timeMode === 'relative' ? 'relative' : 'absolute';
    const relValue = trig.relValue != null ? trig.relValue : 30;
    const relUnit = trig.relUnit === 'hour' ? 'hour' : 'min';
    this.setData({
      showEditor: true,
      isEdit: !!r.id,
      editId: r.id || '',
      edName: r.name || '',
      triggerType: trig.type === 'time' ? 'time' : 'manual',
      triggerHour: h,
      triggerMin: m,
      triggerTimeStr: this._pad(h) + ':' + this._pad(m),
      timeMode,
      relValue,
      relUnit,
      targetDevices: devices,
      targetGroups: groups,
      actions: { powerOn: a.power != null ? a.power : 1, mode: a.mode != null ? a.mode : null, music: a.music != null ? a.music : null },
      enPower: a.power != null,
      enBright: a.brightness != null,
      enColor: !!a.color,
      enWarm: a.warmCool != null,
      enMode: a.mode != null,
      enMusic: a.music != null,
      enMic: a.mic != null,
      editR: a.color ? a.color.r : 126,
      editG: a.color ? a.color.g : 97,
      editB: a.color ? a.color.b : 255,
      editBright: a.brightness != null ? a.brightness : 100,
      editWarm: a.warmCool != null ? a.warmCool : 50,
      editMic: a.mic != null ? a.mic : 50,
      sceneCats: SCENE_CATS,
      musicList: MUSIC_LIST,
    });
  },
closeEditor() { this.setData({ showEditor: false }); },
onNameInput(e) { this.setData({ edName: e.detail.value }); },
switchTrigger(e) { this.setData({ triggerType: e.currentTarget.dataset.t }); },
onTimePick(e) {
    const parts = e.detail.value.split(':');
    const h = Number(parts[0]);
    const m = Number(parts[1]);
    this.setData({ triggerHour: h, triggerMin: m, triggerTimeStr: this._pad(h) + ':' + this._pad(m) });
  },
switchTimeMode(e) { this.setData({ timeMode: e.currentTarget.dataset.m }); },
onRelValue(e) {
    const v = Number(e.detail.value);
    this.setData({ relValue: v > 0 ? v : 0 });
  },
switchRelUnit(e) { this.setData({ relUnit: e.currentTarget.dataset.u }); },
toggleTargetDev(e) {
    const i = Number(e.currentTarget.dataset.i);
    const key = 'targetDevices[' + i + '].selected';
    this.setData({ [key]: !this.targetDevices[i].selected });
  },
toggleTargetGrp(e) {
    const i = Number(e.currentTarget.dataset.i);
    const key = 'targetGroups[' + i + '].selected';
    this.setData({ [key]: !this.targetGroups[i].selected });
  },
toggleEn(e) {
    const k = e.currentTarget.dataset.k;
    this.setData({ [k]: !this.data[k] });
  },
setPower(e) { this.setData({ 'actions.powerOn': Number(e.currentTarget.dataset.v) }); },
onEditBright(e) { this.setData({ editBright: e.detail.value }); },
onEditR(e) { this.setData({ editR: e.detail.value }); },
onEditG(e) { this.setData({ editG: e.detail.value }); },
onEditB(e) { this.setData({ editB: e.detail.value }); },
onEditWarm(e) { this.setData({ editWarm: e.detail.value }); },
onEditMic(e) { this.setData({ editMic: e.detail.value }); },
pickScene(e) { this.setData({ 'actions.mode': Number(e.currentTarget.dataset.id) }); },
pickMusic(e) { this.setData({ 'actions.music': Number(e.currentTarget.dataset.id) }); },
saveRule() {
    const name = (this.edName || '').trim();
    if (!name) { uni.showToast({ title: '请输入名称', icon: 'none' }); return; }
    const targets = [];
    this.targetDevices.forEach((d) => { if (d.selected) targets.push({ type: 'device', id: d.deviceId }); });
    this.targetGroups.forEach((g) => { if (g.selected) targets.push({ type: 'group', id: g.id }); });
    if (targets.length === 0) { uni.showToast({ title: '请选择至少一个目标', icon: 'none' }); return; }
    if (this.triggerType === 'time' && this.timeMode === 'relative' && !(this.relValue > 0)) {
      uni.showToast({ title: '请输入相对时长', icon: 'none' });
      return;
    }

    const a = this.actions;
    const actions = {};
    if (this.enPower) actions.power = a.powerOn;
    if (this.enBright) actions.brightness = Math.round(this.editBright);
    if (this.enColor) actions.color = { r: this.editR, g: this.editG, b: this.editB };
    if (this.enWarm) actions.warmCool = Math.round(this.editWarm);
    if (this.enMode && a.mode != null) actions.mode = a.mode;
    if (this.enMusic && a.music != null) actions.music = a.music;
    if (this.enMic) actions.mic = Math.round(this.editMic);

    const rule = {
      id: this.isEdit ? this.editId : undefined,
      name,
      enabled: true,
      trigger: this.triggerType === 'time'
        ? (this.timeMode === 'relative'
            ? { type: 'time', timeMode: 'relative', relValue: Math.round(this.relValue), relUnit: this.relUnit }
            : { type: 'time', timeMode: 'absolute', hour: this.triggerHour, min: this.triggerMin })
        : { type: 'manual' },
      actions,
      targets,
    };
    linkageStore.saveRule(rule);
    this.setData({ showEditor: false });
    this._loadRules();
    uni.showToast({ title: this.isEdit ? '已更新' : '已创建', icon: 'success' });
  },
async runRule(e) {
    const id = e.currentTarget.dataset.id;
    const r = linkageStore.getRules().find((x) => x.id === id);
    if (!r) return;
    await this._applyRule(r);
  },
async _applyRule(r) {
    const deviceIds = this._resolveTargets(r.targets);
    if (!deviceIds.length) { uni.showToast({ title: '未选择目标设备', icon: 'none' }); return; }
    uni.showLoading({ title: '下发中…' });
    const res = await this._sendActions(deviceIds, r.actions || {});
    uni.hideLoading();
    if (res.ok > 0 && res.fail === 0) uni.showToast({ title: '已执行', icon: 'success' });
    else if (res.ok === 0) uni.showToast({ title: '请先连接设备', icon: 'none' });
    else uni.showToast({ title: `成功 ${res.ok} 台，失败 ${res.fail} 台`, icon: 'none' });
  },
_resolveTargets(targets) {
    const groups = deviceStore.getGroups();
    const set = new Set();
    (targets || []).forEach((t) => {
      if (t.type === 'group') {
        const g = groups.find((x) => x.id === t.id);
        if (g) (g.deviceIds || []).forEach((id) => set.add(id));
      } else {
        set.add(t.id);
      }
    });
    return [...set];
  },
async _sendActions(deviceIds, actions) {

    const connected = deviceIds.filter((id) => ble && ble.isConnected(id));
    if (connected.length === 0) return { ok: 0, fail: deviceIds.length, fails: deviceIds };
    let ok = 0, fail = 0;
    const fails = [];
    for (const id of connected) {
      const d = deviceStore.getByDeviceId(id);
      const typeId = d ? d.typeId : 1;
      const frames = this._buildFrames(typeId, actions);
      let allOk = true;
      for (const item of frames) {
        try {
          await ble.write(id, item[0], item[1]);
        } catch (err) {
          allOk = false;
          break;
        }
      }
      if (allOk) ok++;
      else { fail++; fails.push(d ? d.name : id); }
    }
    return { ok, fail, fails };
  },
_buildFrames(typeId, actions) {
    const frames = [];
    const meta = getDeviceMeta(typeId);
    const caps = meta.caps || {};
    if (actions.power != null && caps.power) {
      frames.push([protocol.CMD.POWER, protocol.light.power(actions.power === 1)]);
    }
    if (actions.brightness != null && caps.brightness) {
      const max = isHsvType(typeId) ? 1000 : 100;
      const v = Math.max(0, Math.min(max, Math.round((actions.brightness / 100) * max)));
      frames.push([protocol.CMD.BRIGHTNESS, protocol.light.brightness(typeId, v)]);
    }
    if (actions.color && caps.color) {
      if (isHsvType(typeId)) {
        const hsv = this._rgb2hsv(actions.color.r, actions.color.g, actions.color.b);
        frames.push([protocol.CMD.COLOR, protocol.light.color(typeId, { h: Math.round(hsv[0] * 360), s: Math.round(hsv[1] * 1000) })]);
      } else {
        frames.push([protocol.CMD.COLOR, protocol.light.color(typeId, actions.color)]);
      }
    }
    if (actions.warmCool != null && caps.warmCool) {
      // 色温 + 冷暖亮度：CW 统一 0x12 单帧
      protocol.cwFrames(typeId, actions.warmCool, actions.brightness).forEach((f) => frames.push(f));
    }
    if (actions.mode != null && caps.mode) {
      frames.push([protocol.CMD.MODE, protocol.light.mode(typeId, actions.mode)]);
    }
    if (actions.music != null && caps.music) {
      frames.push([protocol.CMD.MUSIC, protocol.light.music(actions.music)]);
    }
    if (actions.mic != null && caps.mic) {
      frames.push([protocol.CMD.MIC, protocol.light.mic(actions.mic)]);
    }
    return frames;
  },
toggleEnabled(e) {
    const id = e.currentTarget.dataset.id;
    linkageStore.setEnabled(id, e.detail.value);
    this._loadRules();
  },
deleteRule(e) {
    const id = e.currentTarget.dataset.id;
    const that = this;
    uni.showModal({
      title: '删除联动',
      content: '确定删除该联动？',
      confirmText: '删除',
      confirmColor: '#ef4444',
      success(res) {
        if (!res.confirm) return;
        linkageStore.removeRule(id);
        that._loadRules();
      },
    });
  },
_startTimerChecker() {
    this._stopTimerChecker();
    this._lastRun = {};
    this._timer = setInterval(() => this._checkTimers(), 30000);
    this._checkTimers();
  },
_stopTimerChecker() {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
  },
_checkTimers() {
    const now = new Date();
    const hh = now.getHours();
    const mm = now.getMinutes();
    const today = now.toISOString().slice(0, 10);
    linkageStore.getRules().forEach((r) => {
      if (!r.enabled || !r.trigger || r.trigger.type !== 'time') return;
      if (r.trigger.timeMode === 'relative') {
        const at = r.trigger.activatedAt;
        if (!at) return;
        const unit = r.trigger.relUnit === 'hour' ? 3600 : 60;
        const ms = (r.trigger.relValue || 0) * unit * 1000;
        if (Date.now() - at >= ms) {
          const key = r.id + ':' + at;
          if (this._lastRun[key] !== true) {
            this._lastRun[key] = true;
            this._applyRule(r);
          }
        }
      } else {
        if (r.trigger.hour === hh && r.trigger.min === mm && this._lastRun[r.id] !== today) {
          this._lastRun[r.id] = today;
          this._applyRule(r);
        }
      }
    });
  },
  },
}
</script>

<style>
/* ===== 智慧世界首页（参考图风格） ===== */
page {
  background: #0a0a14;
  color: #e4e4ed;
}

.page-wrap {
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
}

/* 自定义导航栏 */
.custom-nav {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 88rpx;
  position: relative;
  padding: 0 32rpx;
  background: transparent;
}
.nav-title {
  font-size: 36rpx;
  font-weight: 600;
  color: #ffffff;
  letter-spacing: 2rpx;
}
/* 顶部 Tab */
.top-tabs {
  display: flex;
  justify-content: center;
  gap: 48rpx;
  padding: 24rpx 0 32rpx;
}
.top-tab {
  font-size: 30rpx;
  color: #6e6e8a;
  padding: 10rpx 0;
  position: relative;
  font-weight: 500;
}
.top-tab.active {
  color: #a78bfa;
  font-weight: 600;
}
.top-tab.active::after {
  content: '';
  position: absolute;
  left: 50%;
  bottom: 0;
  transform: translateX(-50%);
  width: 40rpx;
  height: 4rpx;
  border-radius: 2rpx;
  background: linear-gradient(90deg, #7c3aed, #a78bfa);
  box-shadow: 0 0 12rpx rgba(167,139,250,.6);
}

/* 设备列表 */
.device-list {
  flex: 1;
  padding: 0 32rpx;
}

/* 设备卡片 */
.device-card {
  display: flex;
  align-items: center;
  background: linear-gradient(135deg, #141426, #111121);
  border-radius: 28rpx;
  padding: 32rpx 28rpx;
  margin-bottom: 24rpx;
  box-shadow: 0 8rpx 32rpx rgba(0,0,0,.35), inset 0 1rpx 0 rgba(255,255,255,.04);
  border: 1rpx solid rgba(255,255,255,.06);
}
.device-card:active {
  transform: scale(.985);
  transition: transform .1s;
}

/* 左侧蓝牙图标 */
.card-icon-box {
  flex-shrink: 0;
  width: 96rpx;
  height: 96rpx;
  border-radius: 24rpx;
  background: linear-gradient(135deg, #1a1a30, #151526);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 28rpx;
  box-shadow: inset 0 0 16rpx rgba(0,0,0,.25);
  border: 1rpx solid rgba(255,255,255,.05);
}

/* CSS 蓝牙图标 */
.bt-icon {
  position: relative;
  width: 36rpx;
  height: 52rpx;
}
.bt-icon.big {
  width: 60rpx;
  height: 88rpx;
}
.bt-stem {
  position: absolute;
  left: 50%;
  top: 0;
  transform: translateX(-50%);
  width: 4rpx;
  height: 100%;
  background: #a78bfa;
  border-radius: 2rpx;
}
.big .bt-stem { width: 6rpx; }
.bt-tri {
  position: absolute;
  width: 0;
  height: 0;
  border-style: solid;
  left: 50%;
}
.bt-tri-top {
  top: 6rpx;
  border-width: 12rpx 0 12rpx 18rpx;
  border-color: transparent transparent transparent #a78bfa;
  transform: translateX(-50%) rotate(-45deg);
  transform-origin: left center;
}
.big .bt-tri-top {
  top: 10rpx;
  border-width: 20rpx 0 20rpx 30rpx;
}
.bt-tri-bottom {
  bottom: 6rpx;
  border-width: 12rpx 18rpx 12rpx 0;
  border-color: transparent #a78bfa transparent transparent;
  transform: translateX(-50%) rotate(-45deg);
  transform-origin: right center;
}
.big .bt-tri-bottom {
  bottom: 10rpx;
  border-width: 20rpx 30rpx 20rpx 0;
}

/* 卡片中部 */
.card-body {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 14rpx;
}
.device-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #ffffff;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.device-tag {
  display: inline-flex;
  align-items: center;
  gap: 8rpx;
  align-self: flex-start;
  padding: 6rpx 16rpx 6rpx 12rpx;
  border-radius: 20rpx;
  font-size: 22rpx;
  font-weight: 500;
  background: rgba(255,255,255,.08);
  color: #9a9ab0;
  border: 1rpx solid rgba(255,255,255,.08);
}
.device-tag.on {
  background: rgba(34,197,94,.12);
  color: #4ade80;
  border-color: rgba(74,222,128,.25);
}
.device-tag.ing {
  background: rgba(168,139,250,.12);
  color: #a78bfa;
  border-color: rgba(167,139,250,.25);
}
.tag-dot {
  width: 12rpx;
  height: 12rpx;
  border-radius: 50%;
  background: currentColor;
  box-shadow: 0 0 8rpx currentColor;
}

/* 删除按钮 */
.card-actions {
  flex-shrink: 0;
  margin-left: 16rpx;
}
.del-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10rpx 22rpx;
  border-radius: 24rpx;
  background: rgba(239,68,68,.12);
  border: 1rpx solid rgba(239,68,68,.35);
}
.del-btn:active {
  background: rgba(239,68,68,.22);
}
.del-text {
  font-size: 24rpx;
  font-weight: 500;
  color: #ef4444;
}

/* 空状态 / 占位 */
.empty-state,
.placeholder-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 180rpx;
}
.empty-icon {
  width: 160rpx;
  height: 160rpx;
  border-radius: 40rpx;
  background: linear-gradient(135deg, #1a1a30, #151526);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 32rpx;
  box-shadow: inset 0 0 24rpx rgba(0,0,0,.3);
  border: 1rpx solid rgba(255,255,255,.05);
}
.empty-text {
  font-size: 32rpx;
  font-weight: 500;
  color: #b4b4c8;
  margin-bottom: 12rpx;
}
.empty-hint {
  font-size: 26rpx;
  color: #66667a;
}
.placeholder-icon {
  width: 120rpx;
  height: 120rpx;
  border-radius: 50%;
  background: linear-gradient(135deg, #1a1a30, #151526);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 60rpx;
  color: #6e6e8a;
  margin-bottom: 32rpx;
  border: 1rpx solid rgba(255,255,255,.05);
}

/* 底部添加按钮 */
.bottom-area {
  flex-shrink: 0;
  padding: 24rpx 48rpx 32rpx;
  background: linear-gradient(to top, rgba(10,10,20,.95), transparent);
}
.add-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16rpx;
  height: 96rpx;
  border-radius: 48rpx;
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.12);
  box-shadow: 0 8rpx 32rpx rgba(0,0,0,.25);
}
.add-btn:active {
  background: rgba(255,255,255,.1);
  transform: scale(.99);
}
.add-icon {
  width: 40rpx;
  height: 40rpx;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32rpx;
  font-weight: 300;
  color: #a78bfa;
  background: rgba(167,139,250,.12);
}
.add-btn text {
  font-size: 30rpx;
  font-weight: 500;
  color: #e4e4ed;
}

/* ===== 群组卡片 ===== */
.group-card {
  background: linear-gradient(135deg, #141426, #111121);
  border-radius: 28rpx;
  padding: 28rpx;
  margin-bottom: 24rpx;
  box-shadow: 0 8rpx 32rpx rgba(0,0,0,.35), inset 0 1rpx 0 rgba(255,255,255,.04);
  border: 1rpx solid rgba(255,255,255,.06);
}
.group-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20rpx;
}
.group-info {
  display: flex;
  flex-direction: column;
  gap: 8rpx;
  min-width: 0;
}
.group-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #ffffff;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.group-count {
  font-size: 22rpx;
  color: #8a8aa0;
}
.member-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 14rpx;
}
.member-chip {
  font-size: 24rpx;
  color: #c9c9da;
  padding: 10rpx 20rpx;
  border-radius: 20rpx;
  background: rgba(167,139,250,.10);
  border: 1rpx solid rgba(167,139,250,.22);
}
.member-chip:active {
  background: rgba(167,139,250,.2);
}
.member-empty {
  font-size: 24rpx;
  color: #66667a;
}

/* ===== 群组创建弹层 ===== */
.editor-mask {
  position: fixed;
  left: 0; right: 0; top: 0; bottom: 0;
  background: rgba(0,0,0,.55);
  z-index: 100;
  display: flex;
  align-items: flex-end;
}
.editor-sheet {
  width: 100%;
  background: linear-gradient(180deg, #161628, #111120);
  border-radius: 32rpx 32rpx 0 0;
  padding: 40rpx 32rpx calc(env(safe-area-inset-bottom) + 32rpx);
  box-shadow: 0 -8rpx 40rpx rgba(0,0,0,.5);
  border-top: 1rpx solid rgba(255,255,255,.08);
}
.editor-title {
  font-size: 34rpx;
  font-weight: 600;
  color: #ffffff;
  text-align: center;
  margin-bottom: 28rpx;
}
.editor-input {
  height: 88rpx;
  background: rgba(255,255,255,.06);
  border: 1rpx solid rgba(255,255,255,.1);
  border-radius: 20rpx;
  padding: 0 24rpx;
  font-size: 30rpx;
  color: #e4e4ed;
}
.editor-ph {
  color: #66667a;
}
.editor-subtitle {
  font-size: 26rpx;
  color: #8a8aa0;
  margin: 28rpx 0 16rpx;
}
.candidate-list {
  height: 480rpx;
  max-height: 480rpx;
}
.candidate-group {
  width: 100%;
}
.candidate {
  display: flex;
  align-items: center;
  min-height: 88rpx;
  padding: 12rpx 16rpx;
  border-radius: 18rpx;
  box-sizing: border-box;
}
.candidate:active {
  background: rgba(255,255,255,.04);
}
.candidate.sel {
  background: rgba(167,139,250,.08);
}
.c-radio {
  flex-shrink: 0;
  width: 40rpx;
  height: 40rpx;
  border-radius: 50%;
  border: 2rpx solid #6e6e8a;
  margin-right: 24rpx;
  display: flex;
  align-items: center;
  justify-content: center;
}
.candidate.sel .c-radio {
  border-color: #a78bfa;
  background: rgba(167,139,250,.18);
}
.c-dot {
  width: 20rpx;
  height: 20rpx;
  border-radius: 50%;
  background: #a78bfa;
  box-shadow: 0 0 10rpx rgba(167,139,250,.7);
}
.c-name {
  font-size: 30rpx;
  color: #e4e4ed;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.candidate-empty {
  font-size: 26rpx;
  color: #66667a;
  text-align: center;
  padding: 40rpx 0;
}
.editor-actions {
  display: flex;
  gap: 24rpx;
  margin-top: 32rpx;
}
.editor-btn {
  flex: 1;
  height: 92rpx;
  border-radius: 46rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30rpx;
  font-weight: 500;
}
.editor-btn.cancel {
  background: rgba(255,255,255,.06);
  color: #b4b4c8;
  border: 1rpx solid rgba(255,255,255,.12);
}
.editor-btn.confirm {
  background: linear-gradient(90deg, #7c3aed, #a78bfa);
  color: #ffffff;
  box-shadow: 0 8rpx 24rpx rgba(124,58,237,.4);
}
.editor-btn.confirm:active {
  opacity: .9;
}

/* ===== 群组群控弹层 ===== */
.group-foot {
  margin-top: 24rpx;
  display: flex;
  justify-content: flex-end;
}
.group-ctrl-btn {
  font-size: 26rpx;
  font-weight: 500;
  color: #a78bfa;
  padding: 14rpx 36rpx;
  border-radius: 28rpx;
  background: rgba(167,139,250,.12);
  border: 1rpx solid rgba(167,139,250,.3);
}
.group-ctrl-btn:active {
  background: rgba(167,139,250,.22);
}
.ctrl-members {
  max-height: 360rpx;
  margin-bottom: 8rpx;
}
.ctrl-member {
  display: flex;
  align-items: center;
  padding: 22rpx 16rpx;
  border-radius: 18rpx;
}
.ctrl-member:active {
  background: rgba(255,255,255,.04);
}
.ctrl-dot {
  flex-shrink: 0;
  width: 16rpx;
  height: 16rpx;
  border-radius: 50%;
  margin-right: 20rpx;
}
.ctrl-dot.on {
  background: #4ade80;
  box-shadow: 0 0 10rpx rgba(74,222,128,.7);
}
.ctrl-dot.off {
  background: #55556a;
}
.ctrl-m-name {
  flex: 1;
  font-size: 30rpx;
  color: #e4e4ed;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ctrl-m-state {
  font-size: 24rpx;
  margin-left: 16rpx;
}
.ctrl-m-state.on { color: #4ade80; }
.ctrl-m-state.off { color: #66667a; }
.ctrl-power-row {
  display: flex;
  gap: 24rpx;
  margin: 16rpx 0 24rpx;
}
.ctrl-power-btn {
  flex: 1;
  height: 88rpx;
  border-radius: 44rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30rpx;
  font-weight: 500;
}
.ctrl-power-btn.off {
  background: rgba(255,255,255,.06);
  color: #b4b4c8;
  border: 1rpx solid rgba(255,255,255,.12);
}
.ctrl-power-btn.on {
  background: linear-gradient(90deg, #7c3aed, #a78bfa);
  color: #ffffff;
  box-shadow: 0 8rpx 24rpx rgba(124,58,237,.4);
}
.ctrl-power-btn:active { opacity: .9; }
.ctrl-bright-row {
  padding: 8rpx 0 4rpx;
}
.ctrl-bright-label {
  font-size: 28rpx;
  color: #b4b4c8;
  margin-bottom: 8rpx;
}
.ctrl-bright-val {
  color: #a78bfa;
  font-weight: 600;
}
.ctrl-slider {
  margin: 4rpx 8rpx;
}
.ctrl-apply {
  height: 88rpx;
  border-radius: 44rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30rpx;
  font-weight: 500;
  color: #ffffff;
  background: linear-gradient(90deg, #7c3aed, #a78bfa);
  box-shadow: 0 8rpx 24rpx rgba(124,58,237,.4);
  margin-top: 20rpx;
}
.ctrl-apply:active { opacity: .9; }

/* 群控子 Tab */
.ctrl-tabs {
  display: flex;
  gap: 12rpx;
  margin: 8rpx 0 16rpx;
}
.ctrl-tab {
  flex: 1;
  text-align: center;
  font-size: 26rpx;
  font-weight: 500;
  color: #8a8aa0;
  padding: 16rpx 0;
  border-radius: 18rpx;
  background: rgba(255,255,255,.04);
  border: 1rpx solid rgba(255,255,255,.06);
}
.ctrl-tab.active {
  color: #ffffff;
  background: rgba(167,139,250,.16);
  border-color: rgba(167,139,250,.35);
}
.ctrl-members-sm {
  max-height: 180rpx;
  margin-bottom: 8rpx;
}
.ctrl-body {
  max-height: 52vh;
  padding: 4rpx 4rpx 8rpx;
}
.ctrl-subtitle {
  font-size: 26rpx;
  color: #8a8aa0;
  margin: 16rpx 0 12rpx;
}
.ctrl-color-row {
  display: flex;
  flex-wrap: wrap;
  gap: 18rpx;
}
.ctrl-color-dot {
  width: 64rpx;
  height: 64rpx;
  border-radius: 50%;
  border: 2rpx solid rgba(255,255,255,.2);
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,.3);
}
.ctrl-color-dot:active {
  transform: scale(.92);
}
.ctrl-rgb-row {
  display: flex;
  align-items: center;
  margin-bottom: 12rpx;
}
.ctrl-rgb-label {
  flex-shrink: 0;
  width: 36rpx;
  font-size: 28rpx;
  font-weight: 600;
  color: #c9c9da;
}
.ctrl-slider-flex {
  flex: 1;
  margin: 0 8rpx;
}
.ctrl-scene-cat {
  margin-bottom: 8rpx;
}
.ctrl-scene-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
}
.ctrl-scene-btn {
  width: calc((100% - 48rpx) / 4);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 18rpx 0;
  border-radius: 18rpx;
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.08);
}
.ctrl-scene-btn:active {
  background: rgba(167,139,250,.14);
  border-color: rgba(167,139,250,.3);
}
.ctrl-scene-icon {
  font-size: 40rpx;
  margin-bottom: 8rpx;
}
.ctrl-scene-name {
  font-size: 22rpx;
  color: #c9c9da;
}

/* 群控全局区（开关+亮度，常显于 Tab 之上） */
.ctrl-global {
  padding: 4rpx 0 8rpx;
  border-bottom: 1rpx solid rgba(255,255,255,.06);
  margin-bottom: 4rpx;
}

/* 群控 · 音乐律动面板 */
.ctrl-music-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
}
.ctrl-music-btn {
  width: calc((100% - 48rpx) / 4);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 18rpx 0;
  border-radius: 18rpx;
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.08);
}
.ctrl-music-btn:active {
  background: rgba(167,139,250,.14);
  border-color: rgba(167,139,250,.3);
}
.ctrl-music-btn.active {
  background: rgba(167,139,250,.18);
  border-color: rgba(167,139,250,.5);
  box-shadow: 0 4rpx 16rpx rgba(124,58,237,.3);
}
.ctrl-music-icon {
  font-size: 40rpx;
  margin-bottom: 8rpx;
}
.ctrl-music-name {
  font-size: 22rpx;
  color: #c9c9da;
}

/* 分享页 */
.share-card {
  margin: 32rpx 24rpx;
  padding: 36rpx 32rpx;
  border-radius: 28rpx;
  background: linear-gradient(135deg, #16162a, #111121);
  border: 1rpx solid rgba(255,255,255,.06);
  box-shadow: 0 8rpx 30rpx rgba(0,0,0,.3);
}
.share-summary {
  display: flex;
  gap: 24rpx;
  margin-bottom: 24rpx;
}
.share-stat {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20rpx 0;
  border-radius: 18rpx;
  background: rgba(255,255,255,.04);
}
.share-num {
  font-size: 48rpx;
  font-weight: 700;
  color: #c4b5fd;
}
.share-label {
  font-size: 24rpx;
  color: #9a9ab0;
  margin-top: 4rpx;
}
.share-desc {
  font-size: 26rpx;
  color: #9a9ab0;
  line-height: 1.6;
  margin-bottom: 28rpx;
}
.share-btn {
  margin: 0 0 18rpx;
  height: 88rpx;
  line-height: 88rpx;
  border-radius: 44rpx;
  font-size: 30rpx;
  font-weight: 500;
  color: #e4e4ed;
  background: rgba(255,255,255,.06);
  border: 1rpx solid rgba(255,255,255,.1);
}
.share-btn::after { border: none; }
.share-btn.primary {
  color: #fff;
  background: linear-gradient(135deg, #a855f7, #7c3aed);
  border: none;
}
.share-btn:active { opacity: .9; }

/* ===== 联动 Tab / 编辑弹层 ===== */
.lk-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 180rpx;
}

.lk-rule {
  background: linear-gradient(135deg, #141426, #111121);
  border-radius: 28rpx;
  padding: 28rpx;
  margin-bottom: 24rpx;
  border: 1rpx solid rgba(255,255,255,.06);
  box-shadow: 0 8rpx 32rpx rgba(0,0,0,.35);
}
.lk-rule-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16rpx;
}
.lk-rule-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #ffffff;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin-right: 16rpx;
}
.lk-rule-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 12rpx;
  margin-bottom: 16rpx;
}
.lk-tag {
  font-size: 22rpx;
  padding: 6rpx 14rpx;
  border-radius: 20rpx;
  border: 1rpx solid rgba(255,255,255,.08);
}
.lk-tag-trigger {
  color: #a78bfa;
  background: rgba(167,139,250,.12);
  border-color: rgba(167,139,250,.25);
}
.lk-tag-target {
  color: #4ade80;
  background: rgba(74,222,128,.12);
  border-color: rgba(74,222,128,.25);
}
.lk-rule-actions {
  font-size: 24rpx;
  color: #9a9ab0;
  line-height: 1.4;
  margin-bottom: 20rpx;
}
.lk-rule-btns {
  display: flex;
  gap: 16rpx;
}
.lk-rbtn {
  flex: 1;
  height: 72rpx;
  border-radius: 36rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26rpx;
  font-weight: 500;
}
.lk-rbtn-run {
  color: #ffffff;
  background: linear-gradient(90deg, #7c3aed, #a78bfa);
  box-shadow: 0 6rpx 20rpx rgba(124,58,237,.4);
}
.lk-rbtn-edit {
  color: #b4b4c8;
  background: rgba(255,255,255,.06);
  border: 1rpx solid rgba(255,255,255,.12);
}
.lk-rbtn-del {
  color: #ef4444;
  background: rgba(239,68,68,.12);
  border: 1rpx solid rgba(239,68,68,.35);
}
.lk-rbtn:active { opacity: .9; }

/* 联动编辑弹层 */
.lk-mask {
  position: fixed;
  left: 0; right: 0; top: 0; bottom: 0;
  background: rgba(0,0,0,.55);
  z-index: 200;
  display: flex;
  align-items: flex-end;
}
.lk-sheet {
  width: 100%;
  height: 92vh;
  background: linear-gradient(180deg, #161628, #111120);
  border-radius: 32rpx 32rpx 0 0;
  padding: 40rpx 32rpx calc(env(safe-area-inset-bottom) + 24rpx);
  display: flex;
  flex-direction: column;
  box-shadow: 0 -8rpx 40rpx rgba(0,0,0,.5);
  border-top: 1rpx solid rgba(255,255,255,.08);
}
.lk-title {
  font-size: 34rpx;
  font-weight: 600;
  color: #ffffff;
  text-align: center;
  margin-bottom: 28rpx;
  flex-shrink: 0;
}
.lk-body {
  flex: 1;
  min-height: 0;
  height: 0;
  padding-bottom: 12rpx;
}
.lk-actions {
  display: flex;
  gap: 24rpx;
  flex-shrink: 0;
  padding-top: 12rpx;
}
.lk-btn {
  flex: 1;
  height: 92rpx;
  border-radius: 46rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30rpx;
  font-weight: 500;
}
.lk-btn-cancel {
  color: #b4b4c8;
  background: rgba(255,255,255,.06);
  border: 1rpx solid rgba(255,255,255,.12);
}
.lk-btn-confirm {
  color: #ffffff;
  background: linear-gradient(90deg, #7c3aed, #a78bfa);
  box-shadow: 0 8rpx 24rpx rgba(124,58,237,.4);
}
.lk-btn:active { opacity: .9; }

/* 弹层内部表单 */
.lk-sheet .fld {
  display: flex;
  flex-direction: column;
  gap: 12rpx;
  margin-bottom: 24rpx;
}
.lk-sheet .fld-label {
  font-size: 26rpx;
  color: #b4b4c8;
}
.lk-sheet .fld-input {
  height: 88rpx;
  background: rgba(255,255,255,.06);
  border: 1rpx solid rgba(255,255,255,.1);
  border-radius: 20rpx;
  padding: 0 24rpx;
  font-size: 30rpx;
  color: #e4e4ed;
}

.lk-sheet .sec-title {
  font-size: 28rpx;
  font-weight: 600;
  color: #ffffff;
  margin: 28rpx 0 16rpx;
}
.lk-sheet .sub-label {
  font-size: 24rpx;
  color: #8a8aa0;
  margin: 16rpx 0 12rpx;
}
.lk-sheet .muted {
  font-size: 24rpx;
  color: #66667a;
  line-height: 1.5;
}

.lk-sheet .seg {
  display: flex;
  gap: 16rpx;
  flex-wrap: wrap;
}
.lk-sheet .seg-item {
  flex: 1;
  min-width: 120rpx;
  text-align: center;
  font-size: 26rpx;
  color: #b4b4c8;
  padding: 16rpx 0;
  border-radius: 18rpx;
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.08);
  box-sizing: border-box;
}
.lk-sheet .seg-item:active {
  background: rgba(255,255,255,.08);
}
.lk-sheet .seg-item.active {
  color: #ffffff;
  background: rgba(167,139,250,.16);
  border-color: rgba(167,139,250,.4);
  box-shadow: 0 4rpx 16rpx rgba(124,58,237,.25);
}
.lk-sheet .seg.small .seg-item {
  padding: 12rpx 0;
  font-size: 24rpx;
}

.lk-sheet .time-row {
  margin-top: 16rpx;
}
.lk-sheet .time-pick {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 18rpx 36rpx;
  border-radius: 18rpx;
  background: rgba(255,255,255,.06);
  border: 1rpx solid rgba(255,255,255,.1);
  font-size: 30rpx;
  color: #e4e4ed;
  font-weight: 500;
}

.lk-sheet .rel-row {
  margin-top: 16rpx;
}
.lk-sheet .rel-input-row {
  display: flex;
  align-items: center;
  gap: 20rpx;
}
.lk-sheet .rel-input {
  flex: 0 0 180rpx;
  height: 80rpx;
  background: rgba(255,255,255,.06);
  border: 1rpx solid rgba(255,255,255,.1);
  border-radius: 16rpx;
  padding: 0 20rpx;
  font-size: 30rpx;
  color: #e4e4ed;
  text-align: center;
}
.lk-sheet .rel-seg {
  flex: 1;
}

.lk-sheet .pick-row {
  display: flex;
  align-items: center;
  padding: 20rpx 16rpx;
  border-radius: 16rpx;
}
.lk-sheet .pick-row:active {
  background: rgba(255,255,255,.04);
}
.lk-sheet .pick-check {
  flex-shrink: 0;
  width: 40rpx;
  height: 40rpx;
  border-radius: 50%;
  border: 2rpx solid #6e6e8a;
  margin-right: 20rpx;
  display: flex;
  align-items: center;
  justify-content: center;
}
.lk-sheet .pick-check.on {
  border-color: #a78bfa;
  background: rgba(167,139,250,.18);
}
.lk-sheet .pick-check.on::after {
  content: '';
  width: 20rpx;
  height: 20rpx;
  border-radius: 50%;
  background: #a78bfa;
  box-shadow: 0 0 10rpx rgba(167,139,250,.7);
}
.lk-sheet .pick-name {
  font-size: 30rpx;
  color: #e4e4ed;
}

.lk-sheet .act-block {
  background: rgba(255,255,255,.03);
  border-radius: 20rpx;
  padding: 20rpx 24rpx;
  margin-bottom: 20rpx;
  border: 1rpx solid rgba(255,255,255,.06);
}
.lk-sheet .act-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 28rpx;
  color: #e4e4ed;
  margin-bottom: 12rpx;
}

.lk-sheet .slider-row {
  display: flex;
  align-items: center;
  gap: 16rpx;
}
.lk-sheet .slider-row slider {
  flex: 1;
}
.lk-sheet .slider-val {
  flex-shrink: 0;
  width: 100rpx;
  text-align: right;
  font-size: 26rpx;
  color: #a78bfa;
  font-weight: 500;
}

.lk-sheet .rgb-rows {
  display: flex;
  flex-direction: column;
  gap: 12rpx;
}
.lk-sheet .rgb-r {
  display: flex;
  align-items: center;
  gap: 12rpx;
}
.lk-sheet .rgb-r slider {
  flex: 1;
}
.lk-sheet .rgb-l {
  width: 32rpx;
  font-size: 26rpx;
  font-weight: 600;
  color: #c9c9da;
}
.lk-sheet .rgb-v {
  width: 60rpx;
  text-align: right;
  font-size: 24rpx;
  color: #a78bfa;
}

.lk-sheet .scene-cat {
  margin-bottom: 8rpx;
}
.lk-sheet .scene-row {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
}
.lk-sheet .scene-btn {
  width: calc((100% - 48rpx) / 4);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 18rpx 0;
  border-radius: 18rpx;
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.08);
  box-sizing: border-box;
}
.lk-sheet .scene-btn:active {
  background: rgba(167,139,250,.14);
  border-color: rgba(167,139,250,.3);
}
.lk-sheet .scene-btn.active {
  background: rgba(167,139,250,.18);
  border-color: rgba(167,139,250,.5);
  box-shadow: 0 4rpx 16rpx rgba(124,58,237,.3);
}
.lk-sheet .scene-icon {
  font-size: 40rpx;
  margin-bottom: 8rpx;
}
.lk-sheet .scene-name {
  font-size: 22rpx;
  color: #c9c9da;
}

.lk-sheet .music-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
}
.lk-sheet .music-btn {
  width: calc((100% - 32rpx) / 3);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 18rpx 0;
  border-radius: 18rpx;
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.08);
  box-sizing: border-box;
}
.lk-sheet .music-btn:active {
  background: rgba(167,139,250,.14);
  border-color: rgba(167,139,250,.3);
}
.lk-sheet .music-btn.active {
  background: rgba(167,139,250,.18);
  border-color: rgba(167,139,250,.5);
  box-shadow: 0 4rpx 16rpx rgba(124,58,237,.3);
}
.lk-sheet .music-icon {
  font-size: 40rpx;
  margin-bottom: 8rpx;
}
.lk-sheet .music-name {
  font-size: 22rpx;
  color: #c9c9da;
}
</style>
