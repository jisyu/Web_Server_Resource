/**
 * 启动页（Splash）客户定制配置
 *
 * 目标：文案 / 图标 / 动效 / 时长 / 跳转 全部集中在本文件，
 *       页面 src/pages/splash/splash.vue 里不再写死任何品牌相关内容。
 *
 * 使用方式：
 *   1. 新增客户：在 presets 里加一份配置，键名即客户标识（如 'rewardwin'）；
 *   2. 切换客户：改下方 ACTIVE_PROFILE 的值；
 *   3. 关闭启动页：enabled: false —— 启动后直接跳 target 页面，不显示加载动画。
 *
 * 注意：
 *   - logo.type = 'image' 时，image 必须指向打包进包内的静态资源（如 /static/splash/logo.png）；
 *   - target.url 若是 tabBar 页面用 switchTab，普通页面用 navigateTo / reLaunch，
 *     方法选错会自动降级（switchTab 失败 → reLaunch），不影响启动；
 *   - 所有尺寸单位为 rpx。
 */

// 脚本生成的覆盖项（客户视频等），由 _tools/apply-splash-video.ps1 全量重写
import generated from './splash.generated'

// 公共默认值：各客户配置会与它做深合并，只需写需要覆盖的字段
const DEFAULT_CONFIG = {
  enabled: true,

  // 客户定制启动视频（由 _tools/apply-splash-video.ps1 自动写入 splash.generated.js）
  // 播放失败会自动回退到下面的内置动画
  video: {
    enabled: false,
    src: '',              // 如 '/static/splash/splash-video.mp4'
    loop: false,
    muted: true,          // 启动视频建议静音，避免强制出声
    objectFit: 'cover',   // cover | contain | fill
    poster: '',           // 首帧占位图（可选）
    // 视频前的静态画面：深色底 + Logo，停留 duration 毫秒后再挂视频。
    // 作用是把系统启动窗口 / WebView 首帧 / 原生 video 控件挂载这几帧全部挡住，
    // 让用户看到的是「一整块深色 + Logo」→「视频」，中间不出现别的画面。
    still: {
      enabled: true,
      image: '/static/splash/splash-still.jpg', // 整屏「深色底 + Logo」图，留空则用内置六边形
      duration: 1500,     // 停留时长（ms），0 = 不要静态阶段，直接播视频
    },
    overlay: 0.2,         // 视频上的黑色蒙版透明度，保证进度条/文字可读
    hideBrand: false,     // 视频自带品牌时不叠加文字
    syncProgress: true,   // 进度条跟随视频播放进度（false 则按 duration 计时）
  },

  // 品牌文案
  brand: {
    title: '智慧世界',
    subtitle: 'SMART WORLD',
    showSubtitle: true,
  },

  // 中心图标
  logo: {
    type: 'hex',      // 'hex' = 内置六边形能量核；'image' = 客户自有图片
    image: '',        // type='image' 时必填，如 '/static/splash/logo.png'
    size: 100,        // 中心图形边长（rpx）
  },

  // 配色
  theme: {
    background: '#050510',
    primary: '#a855f7',
    secondary: '#6366f1',
  },

  // 背景动效
  effects: {
    particles: 30,          // 背景粒子数量，0 = 关闭
    scanline: true,         // 扫描线
    rings: 3,               // 脉冲光环数量 0~3
  },

  // 进度与时长
  progress: {
    show: true,             // 是否显示底部进度条
    duration: 2000,         // 0 → 100% 的总时长（ms）
    interval: 50,           // 刷新间隔（ms），越小越顺滑
    holdAfterFull: 400,     // 到达 100% 后停留多久再跳转（ms）
  },

  // 跳转目标
  target: {
    method: 'switchTab',           // switchTab | reLaunch | navigateTo
    url: '/pages/index/index',
  },
};

// ===== 客户配置表 =====
const presets = {
  // 默认（现有品牌「智慧世界」）
  default: {},

  // 示例：另一个客户的定制（切换 ACTIVE_PROFILE 即可生效）
  rewardwin: {
    brand: {
      title: 'Rewardwin',
      subtitle: 'SMART LIGHTING',
      showSubtitle: true,
    },
    logo: {
      type: 'image',
      image: '/static/logo.png',
      size: 120,
    },
    theme: {
      background: '#0a0a14',
      primary: '#22d3ee',
      secondary: '#6366f1',
    },
    effects: {
      particles: 20,
      scanline: false,
      rings: 2,
    },
    progress: {
      show: true,
      duration: 1500,
      interval: 50,
      holdAfterFull: 200,
    },
    target: {
      method: 'switchTab',
      url: '/pages/index/index',
    },
  },
};

// 当前生效的客户配置（打包前改这一行即可）
const ACTIVE_PROFILE = 'default';

// 深合并：对象合并，其它类型（数组/字符串/数字/布尔）直接覆盖
function merge(base, patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) return patch === undefined ? base : patch;
  const out = Array.isArray(base) ? base.slice() : Object.assign({}, base);
  Object.keys(patch).forEach((key) => {
    const b = base ? base[key] : undefined;
    const p = patch[key];
    out[key] = (p && typeof p === 'object' && !Array.isArray(p)) ? merge(b, p) : p;
  });
  return out;
}

/**
 * 取指定客户的完整配置（含默认值兜底）
 * @param {string} [name] 客户标识，缺省用 ACTIVE_PROFILE
 */
export function resolveSplashConfig(name) {
  const key = name || ACTIVE_PROFILE;
  const preset = presets[key] || {};
  // 优先级：DEFAULT < 客户预设 < 脚本生成的覆盖项（视频等）
  const base = merge(DEFAULT_CONFIG, preset);
  return merge(base, (generated && generated.overrides) || {});
}

export { presets, DEFAULT_CONFIG, ACTIVE_PROFILE };

export default resolveSplashConfig();
