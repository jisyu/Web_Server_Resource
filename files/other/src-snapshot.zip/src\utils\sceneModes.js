/**
 * sceneModes.js
 * 场景（动态模式）库：共 61 个模式，id 即下发给设备的模式值（CMD.MODE 0x06）
 *
 * 分类展示规则：
 *   精典 → id 1~10（设备端主打 1~6 + 四季 7~10，封面网格风格）
 *   常规 → id 11~61（拖尾/堆叠/流水/过渡/开合，列表风格）
 *   所有 → 全部 61 个模式（列表风格）
 *
 * 由 light-panel 与首页群控/联动共用，避免两处数据不同步。
 */

// 61 个模式名称（顺序即模式值 1~61）
const MODE_NAMES = [
  // id 1~6：主打动态（固件 rgb_function.c 模式1~6）
  '烈日晴空(蓝天)', '黎明时分(日出)', '时空穿梭(穿越)', '雨过天晴(彩虹)', '夕阳余晖(晚霞)',
  '晴空万里(烈日)',
  // id 7~10：四季时空穿梭（固件 rgb_function.c 模式7~10）
  '春(樱风)', '夏(骄阳)', '秋(金叶)', '冬(冰晶)',
  // id 11~19：拖尾系列（固件 rgb_function.c 模式11~19）
  '七色拖尾', '红色拖尾', '绿色拖尾', '蓝色拖尾', '红黄拖尾',
  '橙绿拖尾', '青蓝拖尾', '紫红拖尾', '红绿蓝拖尾',
  // id 20~30：堆叠系列（固件 rgb_function.c 模式20~30）
  '正向七彩堆叠', '逆向七彩堆叠', '正向红堆叠', '正向绿堆叠', '正向蓝堆叠',
  '正向红黄堆叠', '正向橙绿堆叠', '正向绿青堆叠', '正向绿紫堆叠', '正向青蓝堆叠',
  '正向紫红堆叠',
  // id 31~39：流水系列（按产品命名表：七彩 / 红绿蓝 / 青黄紫 / 红绿 / 绿蓝 / 黄蓝 / 黄青 / 青紫 / 黑白）
  //   ⚠️ 当前固件 31~39 的动态映射为 流水/呼吸/跑马/闪烁/渐变/跳变/彗星/对冲/脉动，
  //      与"配色流水"命名尚未完全一致，待固件按表调整后此处无需再改。
  '七彩流水', '红绿蓝流水', '青黄紫流水', '红绿流水', '绿蓝流水',
  '黄蓝流水', '黄青流水', '青紫流水', '黑白流水',
  // id 40~49：过渡系列（设备端已实现，见固件 rgb_function.c 模式40~49）
  '七彩明暗过渡', '红绿蓝明暗过渡', '紫青黄明暗过渡',
  '六色暗过渡红色', '六色暗过渡绿色', '六色暗过渡蓝色',
  '六色暗过渡青色', '六色暗过渡黄色', '六色暗过渡紫色', '六色暗过渡白色',
  // id 50~61：开合系列（设备端已实现，见固件 rgb_function.c 模式50~61）
  '七彩开合', '红橙黄开合', '黄绿青开合', '青蓝紫开合',
  '红绿色开合', '绿蓝色开合', '蓝青色开合', '青紫色开合', '紫红色开合',
  '橙绿开合', '橙蓝开合', '橙紫开合',
];

// 封面渐变配色（按索引循环使用；img 字段填入真实封面图后优先显示图片）
const COVER_COLORS = [
  ['#ec4899', '#8b5cf6'],
  ['#2563eb', '#06b6d4'],
  ['#f59e0b', '#ec4899'],
  ['#f43f5e', '#facc15'],
  ['#10b981', '#3b82f6'],
  ['#8b5cf6', '#06b6d4'],
  ['#f97316', '#facc15'],
  ['#06b6d4', '#10b981'],
  ['#a855f7', '#ec4899'],
  ['#3b82f6', '#a855f7'],
  ['#22c55e', '#eab308'],
  ['#ef4444', '#f97316'],
];

// 全部模式：{ id, name, c }（c 为封面渐变两色，img 可选真实封面图）
const MODES = MODE_NAMES.map((name, i) => ({
  id: i + 1,
  name,
  c: COVER_COLORS[i % COVER_COLORS.length],
}));

// 封面图：精典栏（1~10）直接取前 10 张，常规栏（11~61）循环复用；图片缺失时回退为序号/渐变块
// 说明：原图 30 张 PNG 共 42.9MB 超主包限制，已压缩为 240×240 JPG 放入 images/generated_scenes/thumb/（共 242KB）；
//       原图目录 images/generated_scenes/small 已在 project.config.json 中打包排除（仅保留在本地）。
const COVER_IMAGES = [
  '/static/images/generated_scenes/thumb/f01.jpg',
  '/static/images/generated_scenes/thumb/f02.jpg',
  '/static/images/generated_scenes/thumb/f03.jpg',
  '/static/images/generated_scenes/thumb/f04.jpg',
  '/static/images/generated_scenes/thumb/f05.jpg',
  '/static/images/generated_scenes/thumb/f06.jpg',
  '/static/images/generated_scenes/thumb/f07.jpg',
  '/static/images/generated_scenes/thumb/f08.jpg',
  '/static/images/generated_scenes/thumb/f09.jpg',
  '/static/images/generated_scenes/thumb/f10.jpg',
  '/static/images/generated_scenes/thumb/f11.jpg',
  '/static/images/generated_scenes/thumb/f12.jpg',
  '/static/images/generated_scenes/thumb/f13.jpg',
  '/static/images/generated_scenes/thumb/f14.jpg',
  '/static/images/generated_scenes/thumb/f15.jpg',
  '/static/images/generated_scenes/thumb/f16.jpg',
  '/static/images/generated_scenes/thumb/f17.jpg',
  '/static/images/generated_scenes/thumb/f18.jpg',
  '/static/images/generated_scenes/thumb/f19.jpg',
  '/static/images/generated_scenes/thumb/f20.jpg',
  '/static/images/generated_scenes/thumb/f21.jpg',
  '/static/images/generated_scenes/thumb/f22.jpg',
  '/static/images/generated_scenes/thumb/f23.jpg',
  '/static/images/generated_scenes/thumb/f24.jpg',
  '/static/images/generated_scenes/thumb/f25.jpg',
  '/static/images/generated_scenes/thumb/f26.jpg',
  '/static/images/generated_scenes/thumb/f27.jpg',
  '/static/images/generated_scenes/thumb/f28.jpg',
  '/static/images/generated_scenes/thumb/f29.jpg',
  '/static/images/generated_scenes/thumb/f30.jpg',
];

// 构建场景分类（每次返回新副本，避免多实例共享同一数组）
function buildSceneCats() {
  // 精典栏：id 1~10（主打 + 四季），按顺序绑定封面图（网格风格）
  const classic = MODES.slice(0, 10).map((m, i) => Object.assign({}, m, { img: COVER_IMAGES[i] || '' }));
  // 常规栏：id 11~61（拖尾/堆叠/流水/过渡/开合），列表风格，左图右名
  //   封面图数量（30 张）少于条目数，按序循环复用
  const normal = MODES.slice(10).map((m, i) => Object.assign({}, m, { img: COVER_IMAGES[i % COVER_IMAGES.length] || '' }));
  return [
    { name: '精典', grid: true,  scenes: classic },   // id 1~10
    { name: '常规', grid: false, scenes: normal  },   // id 11~61
    { name: '所有', grid: false, scenes: MODES.slice() }, // 全部 61 种
  ];
}

// 按模式值取名称（联动/群控展示用）
function modeName(id) {
  if (id == null) return '';
  const m = MODES[id - 1];
  return m ? m.name : '';
}

// 设备端已实现的模式值（1~61 全部实现，见固件 rgb_function.c）
//   1~6   天镜灯主打动态
//   7~10  四季时空穿梭：7 春 8 夏 9 秋 10 冬
//   11~19 拖尾系列：11 七色 12 红 13 绿 14 蓝 15 红黄 16 橙绿 17 青蓝 18 紫红 19 红绿蓝
//   20~30 堆叠系列：20/21 正逆向七彩 22~24 单色 25~30 两色
//   31~39 七彩流水系列：31 流水 32 呼吸 33 跑马 34 闪烁 35 渐变 36 跳变 37 彗星 38 对冲 39 脉动
//   40~49 过渡系列：40 七彩明暗 41 红绿蓝 42 紫青黄 43~49 六色暗过渡(红/绿/蓝/青/黄/紫/白)
//   50~61 开合系列：50 七彩 51 红橙黄 52 黄绿青 53 青蓝紫 54~61 两色组合
const DEVICE_SUPPORTED_IDS = [
  1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
  11, 12, 13, 14, 15, 16, 17, 18, 19,
  20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
  31, 32, 33, 34, 35, 36, 37, 38, 39,
  40, 41, 42, 43, 44, 45, 46, 47, 48, 49,
  50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61,
];

// 模式是否已由设备端实现（UI 可据此给未实现项加提示，避免用户点了没反应）
function isDeviceSupported(id) {
  return DEVICE_SUPPORTED_IDS.indexOf(Number(id)) >= 0;
}

const __api = {
  MODES,
  COVER_COLORS,
  buildSceneCats,
  modeName,
  DEVICE_SUPPORTED_IDS,
  isDeviceSupported,
};

export { MODES, COVER_COLORS, buildSceneCats, modeName, DEVICE_SUPPORTED_IDS, isDeviceSupported }
export default __api;
