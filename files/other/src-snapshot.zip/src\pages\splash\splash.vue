<template>
<!--
  ⚠️ App 端实际运行的是同目录的 splash.nvue（nvue 原生同层渲染，
     只有它才能用 <image> 真正盖住 <video> 的黑底/加载圈）。
     本文件仅用于 H5 / 小程序等 WebView 端，改启动页请优先改 splash.nvue。
-->
<view class="splash-root" :style="rootStyle">
  <!-- 阶段一：深色底 + Logo 的静态画面
       先用一屏「完全可控」的画面顶住，把系统启动窗口、WebView 首帧、
       原生 video 控件挂载这几帧全部挡掉；still.duration 毫秒后再挂视频 -->
  <view class="splash-still" v-if="stillActive" :class="stillLeaving ? 'is-leaving' : ''">
    <image v-if="stillLogo" class="splash-still-img" :src="stillLogo" mode="aspectFill"></image>
    <view v-else class="hex" :style="'width:' + (logoSize) + 'rpx;height:' + (logoSize) + 'rpx;'">
      <view class="hex-fill" :style="'width:' + Math.round(logoSize * 0.7) + 'rpx;height:' + Math.round(logoSize * 0.7) + 'rpx;'"></view>
    </view>
  </view>

  <!-- 阶段二：客户定制启动视频（脚本写入 splash.generated.js） -->
  <video
    v-if="videoActive"
    :class="'splash-video' + (videoStarted ? ' is-ready' : '')"
    :src="videoPlaySrc"
    :object-fit="cfg.video.objectFit || 'cover'"
    :poster="cfg.video.poster || stillLogo"
    :autoplay="true"
    :loop="!!cfg.video.loop"
    :muted="cfg.video.muted !== false"
    :controls="false"
    :show-center-play-btn="false"
    :show-fullscreen-btn="false"
    :show-play-btn="false"
    :show-progress="false"
    :enable-progress-gesture="false"
    :vslide-gesture="false"
    :page-gesture="false"
    @play="onVideoPlay"
    @timeupdate="onVideoTimeUpdate"
    @ended="onVideoEnded"
    @error="onVideoError"
  >
    <!-- 原生 video 浮在 WebView 之上，起播前的黑底/缓冲圈只能在 video 内部用 cover-view 盖；
         内容与静图完全一样，用户看不出还在等 -->
    <cover-view v-if="videoActive && !videoStarted" class="video-shield">
      <cover-image class="video-shield-img" :src="stillLogo"></cover-image>
    </cover-view>
  </video>
  <view class="video-mask" v-if="videoActive" :style="'background:rgba(0,0,0,' + (cfg.video.overlay || 0) + ');'"></view>

  <!-- 以下为「视频播不了」时的内置动画兜底，视频正常时一律不渲染 -->
  <!-- 背景粒子层 -->
  <view class="particles" v-if="showFallback && cfg.effects.particles > 0">
    <view v-for="(item, index) in particles" class="particle" :style="'left:' + (item.x) + '%;top:' + (item.y) + '%;width:' + (item.size) + 'rpx;height:' + (item.size) + 'rpx;animation-delay:' + (item.delay) + 's;animation-duration:' + (item.dur) + 's;opacity:' + (item.opacity) + ';'" :key="index">
    </view>
  </view>

  <!-- 扫描线 -->
  <view class="scanline" v-if="showFallback && cfg.effects.scanline"></view>

  <!-- 中心能量核心 -->
  <view class="core-wrap" v-if="showFallback">
    <view v-for="(ring, index) in ringStyles" :class="'ring ring-' + (index + 1)" :style="ring.style" :key="index"></view>
    <view class="core-glow"></view>
    <view :class="'core-inner ' + (logoImage ? 'no-spin' : '')">
      <!-- 客户自定义图片 logo -->
      <image v-if="logoImage" class="logo-img" :src="logoImage" mode="aspectFit" :style="'width:' + (logoSize) + 'rpx;height:' + (logoSize) + 'rpx;'" />
      <!-- 默认内置六边形能量核 -->
      <view v-else class="hex" :style="'width:' + (logoSize) + 'rpx;height:' + (logoSize) + 'rpx;'">
        <view class="hex-fill" :style="'width:' + Math.round(logoSize * 0.7) + 'rpx;height:' + Math.round(logoSize * 0.7) + 'rpx;'"></view>
      </view>
    </view>
  </view>

  <!-- 品牌文字（视频自带品牌时可用 video.hideBrand 关闭）
       视频模式下等首帧真正显示出来再叠加，避免"先出现一屏文字加载态"的闪屏 -->
  <view class="brand" v-if="brandVisible">
    <text class="brand-title">{{cfg.brand.title}}</text>
    <view class="brand-line" v-if="cfg.brand.showSubtitle"></view>
    <text class="brand-sub" v-if="cfg.brand.showSubtitle">{{cfg.brand.subtitle}}</text>
  </view>

  <!-- 进度条（同样等视频起播后再显示） -->
  <view class="progress-wrap" v-if="cfg.progress.show && progressVisible">
    <view class="progress-track">
      <view class="progress-bar" :style="'width:' + (progress) + '%'"></view>
    </view>
    <text class="progress-text">{{progress}}%</text>
  </view>
</view>
</template>

<script>
/**
 * 启动页：只负责渲染与计时，品牌文案/图标/配色/时长/跳转全部来自
 * src/config/splash.js —— 换客户时不需要改本文件。
 */
import splashConfig from '@/config/splash'

// #RRGGBB → rgba(r,g,b,a)
function rgba(hex, alpha) {
  let h = String(hex || '#a855f7').replace('#', '');
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  const n = parseInt(h, 16);
  if (Number.isNaN(n)) return 'rgba(168,85,247,' + alpha + ')';
  const r = (n >> 16) & 0xff;
  const g = (n >> 8) & 0xff;
  const b = n & 0xff;
  return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
}

export default {
data() {
    return {
    cfg: splashConfig,
    progress: 0,
    particles: [],
    videoActive: false,     // 是否走客户视频（失败会置 false 回退动画）
    videoMode: !!(splashConfig.video && splashConfig.video.enabled && splashConfig.video.src),
    // 阶段一（深色底 + Logo 静图）是否还在显示：首屏即为 true，
    // 由配置里的 still.duration 决定停多久，之后才挂 video
    stillActive: !!(splashConfig.video && splashConfig.video.enabled && splashConfig.video.src &&
      (!splashConfig.video.still || splashConfig.video.still.enabled !== false) &&
      Number(splashConfig.video.still && splashConfig.video.still.duration) > 0),
    stillLeaving: false,    // 视频出第一帧后，静图层淡出（视频在下面接着）
    videoFailed: false,     // 视频播不了 → 底图一起撤掉，交回内置动画
    videoPlaySrc: '',       // 实际播放地址（App 端首次失败会换成本地绝对路径）
    videoStarted: false,    // 视频是否已起播（起播前不渲染文字/进度，避免闪一屏加载态）
  }
  },
computed: {
    // 主题色以 CSS 变量注入，样式表里不再写死颜色
    rootStyle() {
      const t = this.cfg.theme || {};
      return '--sp-bg:' + (t.background || '#050510') + ';'
        + '--sp-primary:' + (t.primary || '#a855f7') + ';'
        + '--sp-secondary:' + (t.secondary || '#6366f1') + ';'
        + '--sp-primary-50:' + rgba(t.primary, 0.5) + ';'
        + '--sp-primary-35:' + rgba(t.primary, 0.35) + ';'
        + '--sp-primary-20:' + rgba(t.primary, 0.2) + ';'
        + '--sp-primary-10:' + rgba(t.primary, 0.1) + ';';
    },
    logoImage() {
      return (this.cfg.logo && this.cfg.logo.type === 'image') ? (this.cfg.logo.image || '') : '';
    },
    logoSize() {
      return Number(this.cfg.logo && this.cfg.logo.size) || 100;
    },
    // 阶段一显示的 Logo（深色底 + Logo 静图）
    stillLogo() {
      const st = (this.cfg.video && this.cfg.video.still) || {};
      return st.image || '';
    },
    // 内置动画只在「没有视频」或「视频播不了」时出现
    showFallback() {
      return !this.videoActive && (!this.videoMode || this.videoFailed);
    },
    brandVisible() {
      if (this.showFallback) return true;
      return this.videoActive && this.videoStarted && !(this.cfg.video && this.cfg.video.hideBrand);
    },
    progressVisible() {
      if (this.showFallback) return true;
      return this.videoActive && this.videoStarted;
    },
    // 脉冲光环：数量与大小由配置决定
    ringStyles() {
      const n = Math.max(0, Math.min(3, Number(this.cfg.effects && this.cfg.effects.rings) || 0));
      const sizes = [200, 260, 320];
      const delays = [0, 0.4, 0.8];
      const alphas = ['--sp-primary-50', '--sp-primary-35', '--sp-primary-20'];
      const list = [];
      for (let i = 0; i < n; i++) {
        list.push({
          style: 'width:' + sizes[i] + 'rpx;height:' + sizes[i] + 'rpx;'
            + 'border-color:var(' + alphas[i] + ');animation-delay:' + delays[i] + 's;',
        });
      }
      return list;
    },
  },
onLoad() {
    this._t0 = Date.now();
    this._mark('page-onLoad');
    // 关闭启动页：直接进目标页
    if (this.cfg.enabled === false) { this._gotoTarget(); return; }
    this._genParticles();

    // 客户定制视频优先，但计时器始终启动做兜底：
    // 视频不播 / 事件不回调时也会按时跳转，绝不会停在 0%。
    const v = this.cfg.video || {};
    if (v.enabled && v.src) {
      this._videoCandidates = this._buildVideoCandidates(v.src);
      this._videoAttempts = 0;
      const st = v.still || {};
      const stillMs = (st.enabled === false) ? 0 : Math.max(0, Number(st.duration) || 0);
      const mountVideo = () => {
        this._stillTimer = null;
        this._mark('still-done');
        this.setData({ videoActive: true, videoPlaySrc: this._videoCandidates[0] });
        this._armVideoWatchdog();
      };
      // 静态图阶段：先只显示深色底 + Logo，video 根本不在 DOM 里，
      // 原生控件挂载那一帧的黑/白底就不会被看到
      if (stillMs > 0) {
        this._stillTimer = setTimeout(mountVideo, stillMs);
      } else {
        this.setData({ stillActive: false });
        mountVideo();
      }
      this._startCountdown(stillMs + (Number((this.cfg.progress || {}).duration) || 0));
      return;
    }
    this._startCountdown();
  },
onUnload() {
    if (this._timer) clearInterval(this._timer);
    if (this._navTimer) clearTimeout(this._navTimer);
    if (this._videoWatchdog) clearTimeout(this._videoWatchdog);
    if (this._stillTimer) clearTimeout(this._stillTimer);
    if (this._stillFadeTimer) clearTimeout(this._stillFadeTimer);
  },

  methods: {
// 启动时序打点：adb logcat -s splash 可看各阶段耗时，用来定位多余画面出现在哪一层
_mark(name) {
    console.log('[splash] ' + name + ' +' + (Date.now() - (this._t0 || Date.now())) + 'ms');
    this._lastMark = name;
  },
// ====== 客户视频 ======
// App 端优先用 _www 下的绝对文件路径（本地 video 组件最稳），失败再退回 /static 路径
_buildVideoCandidates(src) {
    const list = [];
    // #ifdef APP-PLUS
    try {
      const local = plus.io.convertLocalFileSystemURL('_www' + src);
      if (local && local !== src) list.push(local);
    } catch (err) { /* ignore */ }
    // #endif
    list.push(src);
    return list;
  },
// 看门狗：1.2s 内没有任何播放回调 → 换下一个地址；候选都失败 → 回退内置动画
_armVideoWatchdog() {
    if (this._videoWatchdog) clearTimeout(this._videoWatchdog);
    this._videoWatchdog = setTimeout(() => {
      this._videoWatchdog = null;
      if (!this.videoActive || this._videoStarted) return;
      const next = (this._videoCandidates || [])[this._videoAttempts + 1];
      if (next) {
        this._videoAttempts += 1;
        this.setData({ videoPlaySrc: next });
        this._armVideoWatchdog();
        return;
      }
      // 视频播不了：切回内置动画，用短时长重新计时，避免用户等太久
      this.setData({ videoActive: false, videoFailed: true, stillActive: false });
      this._startCountdown(2000);
    }, 1200);
  },
_markVideoStarted() {
    if (!this._videoStarted) this._mark('video-first-frame');
    this._videoStarted = true;
    if (this._videoWatchdog) { clearTimeout(this._videoWatchdog); this._videoWatchdog = null; }
    // 拿到第一帧：视频开始淡入，静图层 300ms 淡出
    const patch = {};
    if (!this.videoStarted) patch.videoStarted = true;
    if (Object.keys(patch).length) this.setData(patch);
    if (this.stillActive && !this.stillLeaving) {
      this.setData({ stillLeaving: true });
      if (this._stillFadeTimer) clearTimeout(this._stillFadeTimer);
      this._stillFadeTimer = setTimeout(() => {
        this._stillFadeTimer = null;
        if (this.stillActive) this.setData({ stillActive: false, stillLeaving: false });
      }, 320);
    }
  },
onVideoPlay() { this._mark('video-play'); this._markVideoStarted(); },
onVideoTimeUpdate(e) {
    this._markVideoStarted();
    const v = this.cfg.video || {};
    if (!this.videoActive || v.syncProgress === false) return;
    const d = e && e.detail ? e.detail : {};
    const dur = Number(d.duration) || 0;
    const cur = Number(d.currentTime) || 0;
    if (dur <= 0) return;
    // 100% 留给 @ended，避免进度条到顶但页面还没跳
    const pct = Math.min(99, Math.round((cur / dur) * 100));
    if (pct !== this.progress) this.setData({ progress: pct });
  },
onVideoEnded() {
    if (!this.videoActive) return;
    this._markVideoStarted();
    const hold = Math.max(0, Number((this.cfg.progress || {}).holdAfterFull) || 0);
    this.setData({ progress: 100 });
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
    if (this._navTimer) clearTimeout(this._navTimer);
    this._navTimer = setTimeout(() => this._gotoTarget(), hold);
  },
// 视频加载/解码失败：换下一个候选地址，都失败则回退动画
onVideoError(e) {
    console.warn('[splash] video error', e && (e.detail && e.detail.errMsg));
    if (!this.videoActive) return;
    const next = (this._videoCandidates || [])[this._videoAttempts + 1];
    if (next) {
      this._videoAttempts += 1;
      this.setData({ videoPlaySrc: next });
      this._armVideoWatchdog();
      return;
    }
    this.setData({ videoActive: false, videoFailed: true, stillActive: false });
    this._startCountdown(2000);
  },

_genParticles() {
    const count = Math.max(0, Number(this.cfg.effects && this.cfg.effects.particles) || 0);
    const arr = [];
    for (let i = 0; i < count; i++) {
      arr.push({
        x: Math.random() * 100,
        y: Math.random() * 100 + 20,
        size: Math.random() * 6 + 2,
        delay: Math.random() * 4,
        dur: Math.random() * 3 + 3,
        opacity: Math.random() * 0.5 + 0.3,
      });
    }
    this.setData({ particles: arr });
  },
// 按 duration 从 0 走到 100%，到点后停留 holdAfterFull 再跳转
// overrideMs：视频失败回退时用更短的时长重新计时
_startCountdown(overrideMs) {
    // 重入保护：视频失败回退 / 重复调用时不会叠加多个定时器
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
    if (this._navTimer) { clearTimeout(this._navTimer); this._navTimer = null; }
    const p = this.cfg.progress || {};
    const total = Math.max(200, Number(overrideMs) || Number(p.duration) || 2000);
    const hold = Math.max(0, Number(p.holdAfterFull) || 0);
    const tick = Math.max(16, Number(p.interval) || 50);
    const startAt = Date.now();

    // 不显示进度条也按时长跳转，保证启动节奏一致
    if (p.show === false) {
      this._navTimer = setTimeout(() => this._gotoTarget(), total + hold);
      return;
    }
    this._timer = setInterval(() => {
      const pct = Math.min(100, Math.round(((Date.now() - startAt) / total) * 100));
      if (pct >= 100) {
        if (!this.videoActive) this.setData({ progress: 100 });
        clearInterval(this._timer);
        this._timer = null;
        this._navTimer = setTimeout(() => this._gotoTarget(), hold);
        return;
      }
      // 视频在播时由 @timeupdate 驱动进度，这里只做跳转兜底，不覆盖进度条
      if (!this.videoActive) this.setData({ progress: pct });
    }, tick);
  },
_gotoTarget() {
    if (this._navigated) return;   // 计时兜底与 @ended 可能同时到点，只跳一次
    this._navigated = true;
    const t = this.cfg.target || {};
    const url = t.url || '/pages/index/index';
    const method = t.method || 'switchTab';
    // 方法选错时自动降级，避免停在这一页
    const fallback = () => uni.reLaunch({ url });
    if (method === 'navigateTo') uni.navigateTo({ url, fail: fallback });
    else if (method === 'reLaunch') uni.reLaunch({ url, fail: fallback });
    else uni.switchTab({ url, fail: fallback });
  },
  },
}
</script>

<style>
.splash-root {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: var(--sp-bg, #050510);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

/* ====== 阶段一：深色底 + Logo 静图（挡住启动期间的层级切换） ====== */
.splash-still {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  z-index: 4;
  background: var(--sp-bg, #050510);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: opacity .3s linear;
}
.splash-still.is-leaving {
  opacity: 0;
}
/* 整屏静图：底色与窗口底色一致，所以淡入也看不出接缝 */
.splash-still-img {
  width: 100%;
  height: 100%;
  display: block;
  animation: stillIn .4s ease-out both;
}
@keyframes stillIn {
  0% { opacity: 0; transform: scale(1.02); }
  100% { opacity: 1; transform: scale(1); }
}
/* 盖住原生 video 起播前的黑底/缓冲圈（cover-view 才能压住原生控件） */
.video-shield {
  position: absolute;
  top: 0; left: 0;
  width: 100%;
  height: 100%;
  z-index: 9;
}
.video-shield-img {
  position: absolute;
  top: 0; left: 0;
  width: 100%;
  height: 100%;
}

/* ====== 客户定制启动视频 ====== */
/* 未起播前透明：video 是原生控件，一挂载就会盖住底图（黑/白底那一帧就是这么来的），
   等拿到第一帧（timeupdate）再淡入，底图正好还在下面接着 */
.splash-video {
  position: absolute;
  top: 0; left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  opacity: 0;
  transition: opacity .3s linear;
}
.splash-video.is-ready {
  opacity: 1;
}
.video-mask {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  z-index: 2;
  pointer-events: none;
}

/* ====== 背景粒子 ====== */
.particles {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  pointer-events: none;
}
.particle {
  position: absolute;
  border-radius: 50%;
  background: var(--sp-primary, #a855f7);
  animation: floatUp linear infinite;
}
@keyframes floatUp {
  0% { transform: translateY(0) scale(1); opacity: 0; }
  10% { opacity: 1; }
  90% { opacity: 1; }
  100% { transform: translateY(-120rpx) scale(0.3); opacity: 0; }
}

/* ====== 扫描线 ====== */
.scanline {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2rpx;
  background: linear-gradient(90deg, transparent, var(--sp-primary-50, rgba(168,85,247,.6)), transparent);
  animation: scanMove 4s linear infinite;
  pointer-events: none;
}
@keyframes scanMove {
  0% { top: 0; }
  100% { top: 100%; }
}

/* ====== 能量核心 ====== */
.core-wrap {
  position: relative;
  width: 300rpx;
  height: 300rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 80rpx;
}

.ring {
  position: absolute;
  border-radius: 50%;
  border: 2rpx solid var(--sp-primary-20, rgba(168,85,247,.2));
  animation: ringPulse 2.5s ease-out infinite;
}
@keyframes ringPulse {
  0% { transform: scale(0.8); opacity: 1; }
  100% { transform: scale(1.6); opacity: 0; }
}

.core-glow {
  position: absolute;
  width: 160rpx; height: 160rpx;
  border-radius: 50%;
  background: radial-gradient(circle, var(--sp-primary-50, rgba(168,85,247,.4)) 0%, var(--sp-primary-10, rgba(168,85,247,.1)) 50%, transparent 70%);
  animation: glowPulse 2s ease-in-out infinite alternate;
}
@keyframes glowPulse {
  0% { transform: scale(0.85); opacity: 0.6; }
  100% { transform: scale(1.1); opacity: 1; }
}

.core-inner {
  position: relative;
  width: 120rpx; height: 120rpx;
  display: flex; align-items: center; justify-content: center;
  animation: coreSpin 6s linear infinite;
}
@keyframes coreSpin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* 使用客户图片 logo 时中心不旋转，避免商标图形被转倒 */
.core-inner.no-spin { animation: none; }
.logo-img { display: block; }

.hex {
  width: 100rpx; height: 100rpx;
  background: var(--sp-primary-10, rgba(168,85,247,.12));
  clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
  display: flex; align-items: center; justify-content: center;
  position: relative;
}
.hex-fill {
  width: 70rpx; height: 70rpx;
  background: linear-gradient(135deg, var(--sp-primary, #a855f7), var(--sp-secondary, #6366f1));
  clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
  animation: hexGlow 2s ease-in-out infinite alternate;
}
@keyframes hexGlow {
  0% { transform: scale(0.9); opacity: 0.7; }
  100% { transform: scale(1); opacity: 1; }
}

/* ====== 品牌文字 ====== */
.brand {
  position: relative;
  z-index: 3;
  display: flex;
  flex-direction: column;
  align-items: center;
  animation: brandFadeIn 1s ease-out .3s both;
}
@keyframes brandFadeIn {
  0% { opacity: 0; transform: translateY(30rpx); }
  100% { opacity: 1; transform: translateY(0); }
}
.brand-title {
  font-size: 56rpx;
  font-weight: 700;
  color: #ffffff;
  letter-spacing: 12rpx;
  text-shadow: 0 0 40rpx var(--sp-primary-50, rgba(168,85,247,.6));
}
.brand-line {
  width: 0;
  height: 3rpx;
  margin: 20rpx 0;
  background: linear-gradient(90deg, transparent, var(--sp-primary, #a855f7), transparent);
  animation: lineExpand 1s ease-out .8s both;
}
@keyframes lineExpand {
  0% { width: 0; }
  100% { width: 240rpx; }
}
.brand-sub {
  font-size: 24rpx;
  color: var(--sp-primary-50, rgba(168,85,247,.6));
  letter-spacing: 8rpx;
}

/* ====== 进度条 ====== */
.progress-wrap {
  position: absolute;
  z-index: 3;
  bottom: 140rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 400rpx;
}
.progress-track {
  width: 100%;
  height: 4rpx;
  border-radius: 2rpx;
  background: rgba(255,255,255,.08);
  overflow: hidden;
}
.progress-bar {
  height: 100%;
  border-radius: 2rpx;
  background: linear-gradient(90deg, var(--sp-secondary, #6366f1), var(--sp-primary, #a855f7));
  box-shadow: 0 0 12rpx var(--sp-primary-50, rgba(168,85,247,.5));
  transition: width .2s linear;
}
.progress-text {
  margin-top: 20rpx;
  font-size: 22rpx;
  color: rgba(255,255,255,.3);
}
</style>
