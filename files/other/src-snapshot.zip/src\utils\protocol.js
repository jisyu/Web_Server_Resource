import deviceType from './deviceType';

/**
 * protocol.js
 * Light_RGBYW 通信协议层：指令数据构造 + 设备回包解析
 *
 * 数据帧结构（通用）：报头(0x55/0x56) | 功能码 | 序列号 | 报文长度 | 数据 | 校验码
 *  - "报文长度" = 整帧字节数（含自身与校验码）
 *  - 校验码 = 对(报头+功能码+序列号+长度+数据)累加和折叠到 8bit 后取反
 * 本文件只产出"数据"部分；整帧封装(长度/序列号/校验/分包)由 ble.js 负责。
 */

// ===== 功能码常量 =====
const CMD = {
  // 光（通用）
  STATUS: 0x00,
  POWER: 0x01,
  FIRMWARE: 0x02,
  COLOR: 0x03,
  SEGMENT: 0x04,
  BRIGHTNESS: 0x05,
  MODE: 0x06,
  MUSIC: 0x07,
  MIC: 0x08,
  DIY: 0x09,
  TIMER: 0x0a,
  LED_COUNT: 0x0b,
  SYNC_TIME: 0x0c,
  BIND: 0x0e,
  SPEED: 0x0f,
  // 冷暖(CW)统一走 ALL_WARMCOOL(0x12) 单帧；0x10/0x11 已废弃不再下发（仅作为旧固件能力识别位）
  ALL_WARMCOOL: 0x12,
  COLD_BRIGHT: 0x13,
  WARM_BRIGHT: 0x14,
  // 动（风扇）
  FAN_POWER: 0x50,
  FAN_GEAR: 0x51,
  FAN_MODE: 0x52,
  FAN_SPEED: 0x53,
  FAN_DIR: 0x54,
  FAN_LR: 0x55,
  FAN_UD: 0x56,
  FAN_TIMER: 0x57,
  // 感（传感器）
  SENSOR_GET: 0x60,
  SENSOR_SET: 0x61,
  SENSOR_LINK: 0x62,
  SENSOR_DELAY: 0x63,
  SENSOR_SPECIAL: 0x64,
  // 能（电源/电池）
  ENERGY_GET: 0x70,
  ENERGY_CFG1: 0x71,
  ENERGY_CFG2: 0x72,
  ENERGY_CFG3: 0x73,
  ENERGY_CFG4: 0x74,
  // 厂商端
  KEY_MODE: 0xf1,
  REMOTE: 0xf2,
  DEV_INFO: 0xf3,
  LINE_ORDER: 0xf4,
  POWER_LIMIT: 0xf5,
  CONFIG_DONE: 0xf6,
  FACTORY_MODE: 0xf7,
  SAVE: 0xf8,
  // （预留）DRIVER_SCHEME: 0xf9 —— 灯珠驱动方案(WS281x/SM1191)暂不实现, 设置页只做 UI 占位
};

// ===== 功能码 → 名称（日志打印用，由 CMD 反查生成）=====
const CMD_NAME = {};
Object.keys(CMD).forEach((k) => { CMD_NAME[CMD[k]] = k; });

// ===== 返回结果集 =====
function parseResult(code) {
  switch (code) {
    case 0x00: return { ok: true, code, msg: '成功' };
    case 0xe0: return { ok: false, code, msg: '设备忙' };
    case 0xe1: return { ok: false, code, msg: '通讯错误' };
    case 0xe2: return { ok: false, code, msg: '指令无效(设备不支持)' };
    default: return { ok: false, code, msg: '未知结果 0x' + code.toString(16) };
  }
}

// ===== 设备类型集合（2 字节新编号 + 1 字节旧编号均兼容）=====
// 状态回包默认使用「通用设备状态数据结构」（Byte1~Byte18，见 parseStatusPayload）；
// 仅风扇灯类在通用结构之后追加风扇状态字节
const FAN_LAYOUT_TYPES = [0x2009, 0x2010];

// ===== 小工具 =====
const hi = (v) => (v >> 8) & 0xff;
const lo = (v) => v & 0xff;

// ===== 光类指令数据 =====
const light = {
  power: (on) => [on ? 0x01 : 0x00],
  firmware: () => [],
  // hsv 类型（见 deviceType.isHsvType）: HSV(色相0~360, 饱和度0~1000)；其余: RGB(0~255)
  color: (type, p) => {
    if (deviceType.isHsvType(type)) return [hi(p.h || 0), lo(p.h || 0), hi(p.s || 0), lo(p.s || 0)];
    return [p.r & 0xff, p.g & 0xff, p.b & 0xff];
  },
  // 分段颜色：startIndex(本批起始灯珠索引) + N 组 RGB(0~255)
  // ⚠️ 固件单包净荷仅 20 字节（ATT MTU 23 且不支持分包重组），
  //    因此不再固定下发 20 组，改为按批下发（每批 ≤4 颗，数据 13 字节 → 整帧 18 字节）
  segment: (startIndex, colors) => {
    const out = [(startIndex || 0) & 0xff];
    (colors || []).forEach((c) => out.push(c.r & 0xff, c.g & 0xff, c.b & 0xff));
    return out;
  },
  brightness: (type, v) => (deviceType.isHsvType(type) ? [hi(v), lo(v)] : [v & 0xff]),
  mode: (type, m) => (deviceType.isHsvType(type) ? [hi(m), lo(m)] : [m & 0xff]),
  music: (m) => [m & 0xff],
  mic: (v) => [v & 0xff],
  // 用户 DIY（分批下发）：startIndex + N 组 RGB；首批(startIndex=0)固定携带动态参数
  // dyn: { mode 动态方式0~6, dir 方向0/1, interval 间隔(拍), trail 拖尾(点数), trans 过渡(%) }
  //   方式与小程序 dynModeNames 一致: 0 静态 1 跑马 2 流水 3 呼吸 4 彗星 5 波浪 6 闪烁
  //   trans 0~100 = 每拍中用于"新旧画面交叉渐变"的时间占比，0 为硬切（节拍感最硬）、越大越柔和
  // 单包净荷上限 this.maxData(14)：首批最长 1+5+3×2=12 → 2 颗；其余批 1+3×4=13 → 4 颗
  // 首批的 5 个参数必须无条件下发：固件靠「startIndex==0 且数据段≥6 字节」判定有没有这一
  // 段，若缺省会成为第一批颜色数据被解析成 mode/dir/interval/trail/trans。
  diyBatch: (startIndex, colors, dyn) => {
    const out = [(startIndex || 0) & 0xff];
    if (startIndex === 0) {
      const d = dyn || {};
      out.push((d.mode || 0) & 0xff, (d.dir || 0) & 0xff,
        (d.interval || 1) & 0xff, (d.trail || 0) & 0xff, (d.trans || 0) & 0xff);
    }
    (colors || []).forEach((c) => out.push(c.r & 0xff, c.g & 0xff, c.b & 0xff));
    return out;
  },
  timer: (p) => [
    p.onOn ? 0x01 : 0x00,
    p.onHr & 0xff, p.onMin & 0xff, p.onWeek & 0xff,
    p.offOn ? 0x01 : 0x00,
    p.offHr & 0xff, p.offMin & 0xff, p.offWeek & 0xff,
  ],
  ledCount: (n) => [hi(n), lo(n)],
  syncTime: (d) => [
    hi(d.getFullYear()), lo(d.getFullYear()),
    d.getMonth() + 1, d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds(),
    d.getDay() === 0 ? 7 : d.getDay(),
  ],
  bind: (bytes) => bytes.slice(0, 10),
  speed: (v) => [v & 0xff],
  speedQuery: () => [],
  // 0x12 单色冷暖及亮度全部设置（CW 唯一入口）：
  //   冷光亮度 / 暖光亮度 / 冷光色温 / 暖光色温（协议 6.2.18）
  allWarmCool: (p) => [p.coldB & 0xff, p.warmB & 0xff, p.coldT & 0xff, p.warmT & 0xff],
  // 0x13 冷色亮度 / 0x14 暖色亮度：保留定义（能力识别用），实际下发并入 0x12
  coldBright: (v) => [v & 0xff],
  warmBright: (v) => [v & 0xff],
};

// ===== 冷暖(CW)统一入口：色温 + 冷暖亮度合并为 0x12 单帧 =====
// 帧内容（协议 6.2.18）：冷光亮度 / 暖光亮度 / 冷光色温 / 暖光色温
//   temp   0~100：0 = 最暖(#fff4e0) → 100 = 最冷(#a8d4ff)，coldT = temp，warmT = 100 - temp
//   bright 0~100：冷暖亮度，冷/暖两路写同一值；缺省 100（不传/未设置时按满亮度）
// 因此调色温与调冷暖亮度都只发这一帧，另一项用当前值回写，避免被覆盖。
// 能力判定：白名单含 0x12，或含旧色温指令 0x10/0x11、冷暖亮度 0x13/0x14 即视为 CW 设备；
//          未登记类型（whitelist 为空）按支持处理。不支持时返回空数组（调用方提示或跳过）
function cwFrames(typeId, temp, bright) {
  const wl = (deviceType.getDeviceMeta(typeId) || {}).whitelist || [];
  const has = (f) => wl.length === 0 || wl.indexOf(f) >= 0;
  const cw = has(CMD.ALL_WARMCOOL) || has(0x10) || has(0x11) || has(CMD.COLD_BRIGHT) || has(CMD.WARM_BRIGHT);
  if (!cw) return [];

  const t = Math.max(0, Math.min(100, Math.round(Number(temp) || 0)));
  const b = bright == null
    ? 100
    : Math.max(0, Math.min(100, Math.round(Number(bright) || 0)));
  return [[CMD.ALL_WARMCOOL, light.allWarmCool({ coldB: b, warmB: b, coldT: t, warmT: 100 - t })]];
}

// ===== 动类（风扇）指令数据 =====
const motion = {
  power: (on) => [on ? 0x01 : 0x00],
  gear: (g) => [g & 0xff],
  mode: (m) => [m & 0xff], // 1自然 2循环 3自动
  speed: (duty) => [duty & 0xff], // 无极调速占空比
  dir: (d) => [d ? 0xff : 0x00], // 正/反转
  leftRight: (v) => [v ? 0xff : 0x00],
  upDown: (v) => [v ? 0xff : 0x00],
  timer: (p) => [p.range & 0xff, p.state ? 0xff : 0x00],
};

// ===== 感类（传感器）指令数据 =====
const sensor = {
  get: (sensorId) => [sensorId & 0xff],
  // sensorId, 参数类型(0x01~0x06), 数值(2B)
  set: (sensorId, param, val) => [sensorId & 0xff, param & 0xff, hi(val), lo(val)],
  // sensorId, 触发条件(2B), 开灯(0/1), 开风扇(0/1)
  link: (p) => [p.sensorId & 0xff, hi(p.cond), lo(p.cond), p.lightOn ? 0x01 : 0x00, p.fanOn ? 0x01 : 0x00],
  delay: (p) => [p.sensorId & 0xff, hi(p.onDelay), lo(p.onDelay), hi(p.offDelay), lo(p.offDelay)],
};

// ===== 能类（电源/电池）指令数据 =====
const power = {
  get: () => [],
  cfg: (idx, bytes) => [idx & 0xff, ...bytes],
};

// ===== 厂商端指令数据 =====
const factory = {
  keyMode: (modeIds) => [modeIds.length & 0xff, ...modeIds.map((m) => m & 0xff)],
  // 遥控器：每键 7 字节 [keyIdx, code, funcId, ...]
  remote: (keys) => {
    const out = [keys.length & 0xff];
    keys.forEach((k) => {
      out.push(k.idx & 0xff, k.code & 0xff, k.func & 0xff);
      for (let i = 0; i < 4; i++) out.push((k.extra || [0, 0, 0, 0])[i] & 0xff);
    });
    return out;
  },
  devInfo: (p) => [
    hi(p.reserved || 0), lo(p.reserved || 0),
    p.typeId & 0xff,
    ...strToBytes(p.model || '', 10),
    hi(p.ledCount || 32), lo(p.ledCount || 32),
    ...int32ToBytes(p.vendorId || 0),
    hi(p.reserved2 || 0), lo(p.reserved2 || 0),
    (p.bleName || '').length & 0xff,
    ...strToBytes(p.bleName || '', 15),
  ],
  lineOrder: (order) => [order & 0xff], // 0 RGB..5 BGR
  lineOrderQuery: () => [],             // 回读当前线序（固件应答 56 F4 FF 02 00 [order] chk）
  // （预留）灯珠驱动方案 0xF9 暂不下发：driverScheme / driverSchemeQuery 待实现后再补
  powerLimit: (p) => [p.whiteMax & 0xff, p.colorMax & 0xff, p.powerMax & 0xff],
  configDone: () => [],
  factoryMode: () => [],
  // global: 0局部 1全局；func: 当局部时需携带的指令功能码
  save: (global, func) => [global ? 0x01 : 0x00, global ? 0x00 : (func & 0xff)],
};

// ===== 字节辅助 =====
function strToBytes(s, len) {
  const arr = [];
  for (let i = 0; i < len; i++) arr.push(i < s.length ? s.charCodeAt(i) & 0xff : 0);
  return arr;
}
function int32ToBytes(v) {
  return [(v >> 24) & 0xff, (v >> 16) & 0xff, (v >> 8) & 0xff, v & 0xff];
}

// ===== 状态回包解析（0x00 同步设备状态）=====
// packet: 设备回包整帧数组（0x56, func, seq, len, Byte1..Byte18[, speed], cs）
// 注意：STATUS 回包不含 result code，数据直接从 packet[4] 开始
// 数据段提取：设备回包的 len 字段为"数据长度"（不含 4 字节帧头与 1 字节校验码），
// 与发送帧的"整帧长度"语义不同，故统一按帧尾校验码位置截取，兼容两种语义
function _payloadOf(packet, skipResult) {
  const start = skipResult ? 5 : 4;
  const end = packet.length > start ? packet.length - 1 : start;
  return packet.slice(start, end);
}

function parseStatusPacket(packet, typeId) {
  if (!packet || packet[0] !== 0x56 || packet[1] !== CMD.STATUS) return null;
  // STATUS 回包无结果字节
  return parseStatusPayload(typeId, _payloadOf(packet, false));
}

// 状态回包：协议「通用设备状态数据结构」（Byte1~Byte18），未作特别说明的设备默认按此上报
//   Byte1    设备开关状态
//   Byte2~3  RGB 亮度（高8位 + 低8位，大端）
//   Byte4~7  定时开灯闹钟（开关 / 小时 / 分钟 / 星期重复）
//   Byte8~11 定时关灯闹钟（开关 / 小时 / 分钟 / 星期重复）
//   Byte12~13 IC 数（高8位 + 低8位）
//   Byte14    拾音灵敏度
//   Byte15    C 色亮度
//   Byte16    W 色亮度
//   Byte17    C 色色温
//   Byte18    W 色色温
// 风扇灯类：通用结构之后再接风扇状态（Byte19 起），字节不足时该段忽略
function parseStatusPayload(typeId, p) {
  const u8 = (i) => p[i] || 0;
  const u16 = (i) => ((p[i] || 0) << 8) | (p[i + 1] || 0);
  const weekToArr = (v) => {
    const arr = [];
    for (let d = 0; d < 7; d++) if (v & (1 << d)) arr.push(d + 1);
    return arr;
  };
  const timer = (base) => ({
    on: !!u8(base),
    hour: u8(base + 1),
    minute: u8(base + 2),
    week: weekToArr(u8(base + 3)),
  });

  // 亮度：Byte2(高8位)+Byte3(低8位)，大端优先，超出量程(>1000)则按小端重试
  let brightness = u16(1);
  if (brightness > 1000) brightness = ((p[2] || 0) << 8) | (p[1] || 0);

  const st = {
    power: !!u8(0),
    brightness,
    timerOn: timer(3),
    timerOff: timer(7),
    ledCount: u16(11),
    mic: u8(13),
    // 冷暖（CW）状态：C/W 亮度与 C/W 色温百分比，供色温栏与冷暖亮度滑块同步
    coldBrightness: u8(14),
    warmBrightness: u8(15),
    coldPct: u8(16),
    warmPct: u8(17),
  };

  // Light_RGBYW 新固件在标准状态结构后追加 Byte19 动态速度；旧固件无此字段。
  // 风扇灯的 Byte19 起为风扇扩展字段，不能当作动态速度解析。
  if (FAN_LAYOUT_TYPES.indexOf(typeId) < 0 && p.length >= 19) {
    const speed = u8(18);
    if (speed >= 1 && speed <= 100) st.speed = speed;
  }

  // 风扇灯：通用结构之后的追加段（开关 / 档位 / 占空比 / 方向 / 左右摇头 / 模式）
  if (FAN_LAYOUT_TYPES.indexOf(typeId) >= 0 && p.length >= 19) {
    st.fan = {
      power: !!u8(18),
      gear: u8(19),
      duty: u8(20),
      dir: u8(21),
      leftRight: u8(22),
      mode: u8(23),
    };
  }
  return st;
}

// 传感器状态解析（0x60 回包）
function parseSpeedPacket(packet) {
  if (!packet || packet[0] !== 0x56 || packet[1] !== CMD.SPEED || packet[4] !== 0x00) return null;
  const p = _payloadOf(packet, true); // 先跳过成功状态，再取速度值
  if (!p.length) return null;
  return Math.max(1, Math.min(100, p[0]));
}

function parseSensorPacket(packet) {
  if (!packet || packet[0] !== 0x56 || packet[1] !== CMD.SENSOR_GET) return null;
  const p = _payloadOf(packet, true); // 跳过返回结果字节
  const sensorId = p[0];
  const val = p.slice(1);
  return { sensorId, val };
}

const __api = {
  CMD,
  CMD_NAME,
  parseResult,
  parseStatusPacket,
  parseStatusPayload,
  parseSpeedPacket,
  parseSensorPacket,
  cwFrames,
  light,
  motion,
  sensor,
  power,
  factory,
};

export { CMD, CMD_NAME, parseResult, parseStatusPacket, parseStatusPayload, parseSpeedPacket, parseSensorPacket, cwFrames, light, motion, sensor, power, factory }
export default __api;
