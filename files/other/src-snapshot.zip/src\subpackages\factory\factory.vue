<template>
<view class="page-wrap">
  <view class="card">
    <view class="card-title">线序设置</view>
    <view class="chips">
      <view v-for="(item, index) in orders" :class="'chip ' + (orderIndex===index?'on':'')" :data-i="(index)" @tap="pickOrder" :key="index">{{item}}</view>
    </view>
  </view>

  <view class="card">
    <view class="card-title">功率限制</view>
    <view class="row col"><text>混合白光最大值</text><slider min="1" max="100" :value="(whiteMax)" @change="onWhite" activeColor="#ff7a3c" /></view>
    <view class="row col"><text>其它颜色最大值</text><slider min="1" max="100" :value="(colorMax)" @change="onColor" activeColor="#ff7a3c" /></view>
    <view class="row col"><text>最大功率限制(%)</text><slider min="30" max="100" :value="(powerMax)" @change="onPower" activeColor="#ff7a3c" /></view>
  </view>

  <button class="save" @tap="save">保存到设备（全局）</button>
</view>
</template>

<script>
import { ble } from '@/utils/ble'

import protocol from '@/utils/protocol';

export default {
data() {
    return {
    orders: ['RGB', 'RBG', 'GRB', 'GBR', 'BRG', 'BGR'],
    orderIndex: 0,
    whiteMax: 100,
    colorMax: 100,
    powerMax: 100,
  }
  },

  methods: {
pickOrder(e) { this.setData({ orderIndex: e.currentTarget.dataset.i }); },
onWhite(e) { this.setData({ whiteMax: e.detail.value }); },
onColor(e) { this.setData({ colorMax: e.detail.value }); },
onPower(e) { this.setData({ powerMax: e.detail.value }); },
async save() {

    if (!ble) { uni.showToast({ title: '请先连接设备', icon: 'none' }); return; }
    const ids = ble.getConnectedList();
    if (!ids.length) { uni.showToast({ title: '请先连接设备', icon: 'none' }); return; }
    const deviceId = ids[0]; // 厂端配置作用于当前已连接设备
    uni.showLoading({ title: '保存中…' });
    try {
      await ble.write(deviceId, protocol.CMD.LINE_ORDER, protocol.factory.lineOrder(this.orderIndex));
      await ble.write(deviceId, protocol.CMD.POWER_LIMIT, protocol.factory.powerLimit({
        whiteMax: this.whiteMax, colorMax: this.colorMax, powerMax: this.powerMax,
      }));
      await ble.write(deviceId, protocol.CMD.SAVE, protocol.factory.save(1, 0));
      uni.hideLoading();
      uni.showToast({ title: '已保存', icon: 'success' });
    } catch (e) {
      uni.hideLoading();
      uni.showToast({ title: '保存失败', icon: 'none' });
    }
  },
  },
}
</script>

<style>
.page-wrap { padding: 24rpx; }
.card { background:#fff; border-radius:20rpx; padding:28rpx; margin-bottom:24rpx; box-shadow:0 4rpx 24rpx rgba(0,0,0,.04); }
.card-title { font-size:30rpx; font-weight:600; margin-bottom:16rpx; }
.row { display:flex; align-items:center; justify-content:space-between; }
.row.col { flex-direction:column; align-items:stretch; gap:6rpx; }
.chips { display:flex; flex-wrap:wrap; gap:14rpx; }
.chip { padding:12rpx 22rpx; background:#f2f2f5; border-radius:999rpx; font-size:24rpx; color:#555; }
.chip.on { background:#ff7a3c; color:#fff; }
.save { background:#ff7a3c; color:#fff; border-radius:999rpx; font-size:28rpx; margin-top:8rpx; }
</style>
