/**
 * request.js —— 云端统一请求层
 *
 * BLE 直连不依赖云端即可控制；云端用于设备绑定关系、版本、运营等。
 *
 * 移植说明（微信小程序 → uni-app App）：
 *  - wx.request → uni.request（Promise 化）
 *  - wx.login() 换取 code 的流程在 App 端不存在，改为「匿名登录 / 已有 refresh_token 续期」；
 *    未启用云端（config.ENABLE_CLOUD = false）时请求直接本地失败，App 功能不受影响。
 *  - token 存取由 wx.Storage 改为 uni.Storage。
 */
import config, { getBaseUrl } from './config'

function getToken() {
  try {
    return uni.getStorageSync(config.STORAGE_TOKEN) || ''
  } catch (e) {
    return ''
  }
}

function setTokens(token, refreshToken) {
  try {
    if (token) uni.setStorageSync(config.STORAGE_TOKEN, token)
    if (refreshToken) uni.setStorageSync(config.STORAGE_REFRESH_TOKEN, refreshToken)
  } catch (e) {
    console.warn('[request] token 持久化失败', e)
  }
}

function doRequest(options) {
  const base = getBaseUrl()
  const token = getToken()
  const header = Object.assign(
    { 'Content-Type': 'application/json' },
    token ? { Authorization: 'Bearer ' + token } : {},
    options.header || {}
  )

  return new Promise((resolve, reject) => {
    uni.request({
      url: base + options.url,
      method: options.method || 'GET',
      data: options.data || {},
      header,
      timeout: options.timeout || config.HTTP_TIMEOUT,
      success: (res) => {
        if (res.statusCode === 401) {
          refreshAndRetry(options).then(resolve).catch(reject)
          return
        }
        if (res.statusCode >= 200 && res.statusCode < 300) resolve(res.data)
        else reject({ code: res.statusCode, message: (res.data && res.data.message) || '请求失败' })
      },
      fail: (err) => reject({ code: -1, message: '网络错误', detail: err }),
    })
  })
}

/** 统一请求入口：未启用云端时快速失败，避免长时间等待 */
function request(options) {
  if (!config.ENABLE_CLOUD) {
    return Promise.reject({
      code: -2,
      message: '未启用云端服务（config.ENABLE_CLOUD = false），当前为纯本地 BLE 模式',
    })
  }
  return doRequest(options)
}

/**
 * 登录并重试：App 端无微信 code，使用匿名登录；
 * 若后端要求显式登录，由调用方先 setTokens() 写入已有 token 即可。
 */
async function refreshAndRetry(options) {
  const r = await doRequest({
    url: config.AUTH_PATH,
    method: 'POST',
    data: { platform: 'android' },
  })
  setTokens(r && r.data && r.data.access_token, r && r.data && r.data.refresh_token)
  return doRequest(options)
}

/** 手动登录入口：后端提供账号体系时调用此方法换取 token */
export function login(payload) {
  return doRequest({ url: config.AUTH_PATH, method: 'POST', data: payload || {} }).then((r) => {
    setTokens(r && r.data && r.data.access_token, r && r.data && r.data.refresh_token)
    return r
  })
}

// 绑定设备到当前用户（云端记录）
function bindDevice(deviceId, meta) {
  return request({ url: '/devices/bind', method: 'POST', data: { deviceId, meta } })
}

function getMyDevices() {
  return request({ url: '/devices', method: 'GET' })
}

export default { request, login, bindDevice, getMyDevices }
