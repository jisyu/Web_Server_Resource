<template>
<view class="pp-wrap" v-show="!(hidden)">
  <!-- 子 Tab：电源 / 电池 / 设置 -->
  <view class="sub-tabs">
    <view v-for="(item, index) in subTabs" :class="'sub-tab ' + (currentSub === index ? 'active' : '')" :data-index="(index)" @tap="switchSubTab" :key="item.name">{{item.name}}</view>
  </view>

  <!-- ===== 电源子页（主）===== -->
  <block v-if="currentSub === 0">
    <!-- VBUS 数据条 -->
    <view class="data-bar bar-green">
      <text class="bar-label">VBUS</text>
      <text class="bar-val">{{vbusVal}}</text>
      <text class="bar-sub">{{vbusSub}}</text>
      <text class="bar-unit">V</text>
    </view>

    <!-- IBUS 数据条 -->
    <view class="data-bar bar-orange">
      <text class="bar-label">IBUS</text>
      <text class="bar-val">{{ibusVal}}</text>
      <text class="bar-sub">{{ibusSub}}</text>
      <text class="bar-unit">↑A</text>
    </view>

    <!-- PWR 数据条 -->
    <view class="data-bar bar-blue">
      <text class="bar-label">PWR</text>
      <text class="bar-val">{{pwrVal}}</text>
      <text class="bar-sub">{{pwrSub}}</text>
      <text class="bar-unit">W</text>
    </view>

    <!-- PD 协议信息 -->
    <view class="card">
      <view class="pd-header">
        <text class="pd-title">Protocol</text>
        <text class="pd-name">PD3.1</text>
        <text class="pd-na">[N/A]</text>
      </view>
      <view class="pd-lines">
        <text v-for="(item, index) in pd3Lines" class="pd-line" :key="index">{{item}}</text>
      </view>
    </view>

    <!-- PD3.2 规格 -->
    <view class="card">
      <text class="card-title">PD3.2 60W</text>
      <view class="spec-list">
        <view v-for="(item, index) in pd32Specs" class="spec-item" :key="index">
          <text class="spec-label">{{item.label}}:</text>
          <text class="spec-val">{{item.val}}</text>
        </view>
      </view>
    </view>

    <!-- 控制充电 -->
    <view class="card">
      <text class="card-title">控制充电</text>
      <view v-for="(item, index) in chargeRules" class="charge-row" :key="item.idx">
        <text class="charge-text">条件：电量  {{item.pct}}  ，{{item.action}}</text>
      </view>
    </view>

    <!-- 底部操作 -->
    <view class="action-row">
      <button class="act-btn clear" @tap="onClear">↻ 清空</button>
      <button class="act-btn read" @tap="onRead">📖 读取</button>
      <button class="act-btn save" @tap="onSave">💾 保存</button>
    </view>
  </block>

  <!-- ===== 电池子页（占位）===== -->
  <block v-if="currentSub === 1">
    <view class="placeholder-box"><text class="ph-text">电池状态（待实现）</text></view>
  </block>

  <!-- ===== 设置子页（占位）===== -->
  <block v-if="currentSub === 2">
    <view class="placeholder-box"><text class="ph-text">能类设置（待实现）</text></view>
  </block>
</view>
</template>

<script>
import protocol from '@/utils/protocol';

export default {
  props: {
    typeId: { type: Number, default: 1 },
    caps: { type: Object, default: () => ({}) },
    hidden: { type: Boolean, default: false },
  },

  data() {

    return {
    subTabs: [{ name: '电源' }, { name: '电池' }, { name: '设置' }],
    currentSub: 0,

    // 数据条（占位，待协议接入真实值）
    vbusVal: '--', vbusVal2: '', vbusSub: '',
    ibusVal: '--', ibusSub: '',
    pwrVal: '--', pwrSub: '',

    // PD 协议信息
    pd3Lines: ['+ 2.813V', '+ 2.813V', 'CC1 2.813V', 'CC2 2.813V'],

    // PD3.2 规格
    pd32Specs: [
      { label: 'Fixed', val: '5.00V 3.00A' },
      { label: 'Fixed', val: '9.00V 3.00A' },
      { label: 'Fixed', val: '15.00V 3.00A' },
      { label: 'Fixed', val: '20.00V 3.00A' },
      { label: 'AVS', val: '9-20V 3.00A, 3.00A' },
      { label: 'PPS', val: '5.00-16.00V 3.00A' },
    ],

    // 充电控制规则
    chargeRules: [
      { pct: 80, action: '关闭充电。' },
      { pct: 20, action: '开始充电。' },
    ],
  }

  },

  methods: {
    _emit(func, data) { this.$emit('cmd', { func, data }); },

    switchSubTab(e) {
      this.setData({ currentSub: Number(e.currentTarget.dataset.index) });
      if (Number(e.currentTarget.dataset.index) === 0) this.onRead();
    },

    // 读取电源信息
    onRead() {
      this._emit(protocol.CMD.ENERGY_GET, protocol.energy.get());
      uni.showToast({ title: '正在读取…', icon: 'loading' });
    },

    // 外部调用：更新数据（待协议解析完成后接入）
    setInfo(info) {
      if (!info) return;
      this.setData({
        vbusVal: info.voltage || '--',
        vbusVal2: info.voltage2 || '',
        ibusVal: info.current || '--',
        ibusSub: info.currentSub || '',
        pwrVal: info.power || '--',
        pwrSub: info.powerSub || '',
      });
    },

    onClear() {
      this.setData({
        vbusVal: '--', vbusSub: '',
        ibusVal: '--', ibusSub: '',
        pwrVal: '--', pwrSub: '',
      });
      uni.showToast({ title: '已清空', icon: 'none' });
    },

    onSave() {},
  },
}
</script>

<style>
.pp-wrap { padding: 0 28rpx 32rpx; }

/* 子 Tab（下划线风格） */
.sub-tabs {
  display: flex; gap: 40rpx; justify-content: center; padding: 14rpx 0 20rpx;
}
.sub-tab {
  font-size: 28rpx; color: rgba(255,255,255,.35);
  position: relative; padding-bottom: 10rpx;
}
.sub-tab.active { color: #0984e3; font-weight: 500; }
.sub-tab.active::after {
  content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 36rpx; height: 4rpx; border-radius: 2rpx; background: #0984e3;
}

/* ====== 数据条 ====== */
.data-bar {
  display: flex; align-items: baseline; gap: 6rpx;
  padding: 24rpx 28rpx; border-radius: 14rpx; margin-bottom: 16rpx;
}
.bar-label { font-size: 26rpx; font-weight: 700; letter-spacing: 1rpx; }
.bar-val { font-size: 48rpx; font-weight: 700; flex: 1; }
.bar-sub { font-size: 24rpx; opacity: .55; }
.bar-unit { font-size: 28rpx; opacity: .65; }

/* VBUS 绿色 */
.bar-green { background: linear-gradient(135deg, #00b89422, #00b89411); border: 1rpx solid rgba(0,184,148,.18); }
.bar-green .bar-label, .bar-green .bar-val { color: #00cec9; }

/* IBUS 橙红色 */
.bar-orange { background: linear-gradient(135deg, #e1705522, #e1705511); border: 1rpx solid rgba(225,112,85,.18); }
.bar-orange .bar-label, .bar-orange .bar-val { color: #ff7675; }

/* PWR 蓝色 */
.bar-blue { background: linear-gradient(135deg, #0984e322, #0984e311); border: 1rpx solid rgba(9,132,227,.18); }
.bar-blue .bar-label, .bar-blue .bar-val { color: #74c0fc; }

/* ====== 卡片 ====== */
.card {
  background: linear-gradient(135deg, #16162e, #131324);
  border-radius: 18rpx; padding: 28rpx;
  margin-bottom: 20rpx; border: 1rpx solid rgba(9,132,227,.08);
}
.card-title {
  font-size: 28rpx; font-weight: 600; color: rgba(255,255,255,.7);
  display: block; margin-bottom: 18rpx;
}

/* PD 协议 */
.pd-header { display: flex; align-items: baseline; gap: 12rpx; margin-bottom: 12rpx; }
.pd-title { font-size: 24rpx; color: rgba(255,255,255,.45); }
.pd-name { font-size: 32rpx; font-weight: 700; color: #e8e8f0; }
.pd-na { font-size: 24rpx; color: rgba(255,255,255,.3); }
.pd-lines { display: flex; flex-direction: column; gap: 4rpx; }
.pd-line { font-size: 24rpx; color: rgba(116,192,252,.65); font-family: monospace; }

/* PD3.2 规格 */
.spec-list { display: flex; flex-direction: column; gap: 12rpx; }
.spec-item { display: flex; align-items: center; gap: 12rpx; }
.spec-label { font-size: 26rpx; color: rgba(255,255,255,.5); min-width: 72rpx; }
.spec-val { font-size: 26rpx; color: rgba(232,232,240,.75); font-family: monospace; }

/* 充电控制 */
.charge-row { padding: 12rpx 0; }
.charge-text { font-size: 26rpx; color: rgba(255,255,255,.5); line-height: 1.6; }

/* 占位 */
.placeholder-box { padding: 120rpx 0; text-align: center; }
.ph-text { color: rgba(255,255,255,.25); font-size: 28rpx; }

/* 底部按钮 */
.action-row { display: flex; gap: 16rpx; padding: 32rpx 0 8rpx; }
.act-btn {
  height: 80rpx; line-height: 80rpx; border-radius: 18rpx;
  font-size: 26rpx; font-weight: 500; border: none;
}
.act-btn.clear {
  flex: .8; background: transparent; color: rgba(255,255,255,.55);
  border: 1rpx solid rgba(255,255,255,.12);
}
.act-btn.read {
  flex: 1; background: linear-gradient(135deg, rgba(9,132,227,.25), rgba(9,132,227,.15));
  color: #74c0fc; border: 1rpx solid rgba(9,132,227,.2);
}
.act-btn.save {
  flex: 1; background: linear-gradient(135deg, rgba(9,132,227,.25), rgba(9,132,227,.15));
  color: #74c0fc; border: 1rpx solid rgba(9,132,227,.2);
}
</style>
