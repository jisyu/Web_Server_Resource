/**
 * deviceStore.js —— 已绑定设备本地持久化
 *
 * 用途：将用户"添加过并连接成功"的设备保存到本地 Storage，
 *       首页设备列表从此读取，避免每次都要重新扫描。
 *
 * 数据结构（单条）：
 *   { deviceId, name, typeId, model, shortId, addedAt }
 */

const STORAGE_KEY = 'rgbw_saved_devices';

function _read() {
  try {
    return uni.getStorageSync(STORAGE_KEY) || [];
  } catch (e) {
    return [];
  }
}

function _write(list) {
  try {
    uni.setStorageSync(STORAGE_KEY, list);
  } catch (e) {
    // 存储空间满等异常，静默处理
    console.warn('deviceStore save failed', e);
  }
}

/**
 * 获取全部已绑定设备
 */
function getSaved() {
  return _read();
}

/**
 * 添加/更新设备（按 deviceId 去重）
 */
function save(device) {
  const list = _read();
  const idx = list.findIndex((d) => d.deviceId === device.deviceId);
  if (idx >= 0) {
    list[idx] = Object.assign({}, list[idx], device);
  } else {
    list.push(Object.assign({ addedAt: Date.now() }, device));
  }
  _write(list);
  return list;
}

/**
 * 按 deviceId 查找
 */
function getByDeviceId(deviceId) {
  return _read().find((d) => d.deviceId === deviceId) || null;
}

/**
 * 移除设备
 */
function remove(deviceId) {
  const list = _read().filter((d) => d.deviceId !== deviceId);
  _write(list);
  return list;
}

/**
 * 清理无效条目：仅保留含合法字符串 deviceId 的记录。
 * 历史误用（如把 deviceId 当位置参数传入 save）会写入无 deviceId 的垃圾条目，
 * 此处在每次读取列表时静默剔除，避免列表出现"幽灵设备"。
 * @returns {Array} 清理后的设备列表
 */
function sanitize() {
  const list = _read();
  const cleaned = list.filter((d) => d && typeof d.deviceId === 'string' && d.deviceId.length > 0);
  if (cleaned.length !== list.length) _write(cleaned);
  return cleaned;
}

// ============================================================
// 群组（设备分组）
// 数据结构（单条）：{ id, name, deviceIds:[deviceId], createdAt }
// ============================================================
const GROUP_KEY = 'rgbw_groups';

function _readGroups() {
  try {
    return uni.getStorageSync(GROUP_KEY) || [];
  } catch (e) {
    return [];
  }
}

function _writeGroups(list) {
  try {
    uni.setStorageSync(GROUP_KEY, list);
  } catch (e) {
    console.warn('groupStore save failed', e);
  }
}

/**
 * 获取全部群组
 */
function getGroups() {
  return _readGroups();
}

/**
 * 新增/更新群组（按 id 去重；未传 id 则自动生成）
 */
function saveGroup(group) {
  if (!group || typeof group !== 'object') return _readGroups();
  const list = _readGroups();
  const id = group.id || ('g_' + Date.now());
  const idx = list.findIndex((g) => g.id === id);
  const base = idx >= 0 ? list[idx] : { id, createdAt: Date.now() };
  const item = Object.assign({}, base, group, { id });
  if (idx >= 0) list[idx] = item;
  else list.push(item);
  _writeGroups(list);
  return list;
}

/**
 * 按 id 删除群组
 */
function removeGroup(id) {
  const list = _readGroups().filter((g) => g.id !== id);
  _writeGroups(list);
  return list;
}

/**
 * 设备被删除时，从所有群组的 deviceIds 中剔除该 deviceId
 */
function pruneDeviceFromGroups(deviceId) {
  const list = _readGroups().map((g) => {
    if (!g.deviceIds || !g.deviceIds.length) return g;
    const ids = g.deviceIds.filter((x) => x !== deviceId);
    return ids.length === g.deviceIds.length ? g : Object.assign({}, g, { deviceIds: ids });
  });
  _writeGroups(list);
  return list;
}

export default { getSaved, save, getByDeviceId, remove, sanitize, getGroups, saveGroup, removeGroup, pruneDeviceFromGroups };
