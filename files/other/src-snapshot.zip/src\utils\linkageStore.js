/**
 * linkageStore.js —— 联动（场景）规则本地持久化
 *
 * 一条联动规则（动作不与单台设备耦合，目标复用群组）：
 * {
 *   id,
 *   name,
 *   enabled: true,
 *   trigger: { type:'manual' }
 *          | { type:'time', timeMode:'absolute', hour, min }            // 绝对时间：每天到该时刻执行
 *          | { type:'time', timeMode:'relative', relValue, relUnit,     // 相对时间：启用后经过 relValue 分钟/小时执行一次
 *              activatedAt }                                            //   activatedAt 记录开始倒计时的时间戳
 *   actions: {                       // 一组灯光动作（字段为 null 表示该动作不设置）
 *     power: 0|1,                    // 开关
 *     brightness: 0~100,             // 亮度百分比
 *     color: {r,g,b},                // RGB 颜色
 *     warmCool: 0~100,               // 色温
 *     mode: id,                      // 场景 id（1~61，面板内分「精典 1~10 / 常规 11~61 / 所有」）
 *     music: 0~6,                    // 音乐律动（0 关闭）
 *     mic: 0~100,                    // 拾音灵敏度
 *   },
 *   targets: [ {type:'device'|'group', id} ],  // 作用目标（直接复用群组）
 *   createdAt
 * }
 *
 * 设计要点：动作本身不带设备，下发时遍历 targets（group 展开为 deviceId 列表）批量广播，
 * 与首页群控 _broadcast 同构。展开/去重与下发逻辑见 pages/index/index.js 的 _resolveTargets / _sendActions。
 */

const STORAGE_KEY = 'rgbw_linkages';

function _read() {
  try {
    return uni.getStorageSync(STORAGE_KEY) || [];
  } catch (e) {
    return [];
  }
}

function _write(list) {
  try {
    uni.setStorageSync(STORAGE_KEY, list);
  } catch (e) {
    console.warn('linkageStore save failed', e);
  }
}

/**
 * 获取全部联动规则
 */
function getRules() {
  return _read();
}

/**
 * 新增/更新规则（按 id 去重；未传 id 则自动生成）
 */
function saveRule(rule) {
  if (!rule || typeof rule !== 'object') return _read();
  const list = _read();
  const id = rule.id || ('lk_' + Date.now());
  const idx = list.findIndex((r) => r.id === id);
  const base = idx >= 0 ? list[idx] : { id, createdAt: Date.now() };
  const item = Object.assign({}, base, rule, { id });
  // 相对时间定时：新建且启用时记录激活时刻（开始倒计时）；编辑已有规则时保留原倒计时
  const isRel = item.trigger && item.trigger.type === 'time' && item.trigger.timeMode === 'relative';
  if (isRel) {
    if (idx < 0) item.trigger.activatedAt = Date.now();
    else if (base.trigger && base.trigger.activatedAt != null && (!rule.trigger || rule.trigger.activatedAt == null)) {
      item.trigger.activatedAt = base.trigger.activatedAt;
    }
  } else if (item.trigger) {
    item.trigger.activatedAt = null;
  }
  if (idx >= 0) list[idx] = item;
  else list.push(item);
  _write(list);
  return list;
}

/**
 * 按 id 删除规则
 */
function removeRule(id) {
  const list = _read().filter((r) => r.id !== id);
  _write(list);
  return list;
}

/**
 * 切换启用状态（enabled）
 */
function setEnabled(id, enabled) {
  const list = _read();
  const r = list.find((x) => x.id === id);
  if (r) {
    r.enabled = enabled;
    // 相对时间定时：启用即开始倒计时；停用清除激活时刻
    if (r.trigger && r.trigger.type === 'time' && r.trigger.timeMode === 'relative') {
      r.trigger.activatedAt = enabled ? Date.now() : null;
    }
    _write(list);
  }
  return list;
}

export default { getRules, saveRule, removeRule, setEnabled };
