/**
 * permission.js —— Android 运行时权限申请（蓝牙 / 定位 / 麦克风）
 *
 * 移植说明：
 *  小程序侧用 wx.authorize({ scope: 'scope.bluetooth' }) 由微信宿主代理授权；
 *  App 端必须自己在 manifest.json 里声明权限，并在首次使用前动态申请：
 *   - Android 12（API 31）及以上：BLUETOOTH_SCAN / BLUETOOTH_CONNECT
 *   - Android 6 ~ 11：ACCESS_FINE_LOCATION（扫描 BLE 需要定位权限，且系统定位开关要打开）
 *  麦克风：音乐律动需要 RECORD_AUDIO。
 *
 * 注意：
 *  - plus.android.requestPermissions 的回调结果字段是 granted / deniedPresent / deniedAlways，
 *    没有 denied（早期版本这里判断错会导致"以为已授权"）。
 *  - 授权后仍可能被系统限制（定位服务关闭、蓝牙关闭），需由调用方结合适配器状态判断。
 */

const BT_PERMS_NEW = ['android.permission.BLUETOOTH_SCAN', 'android.permission.BLUETOOTH_CONNECT']
// 部分国产 ROM 即便在 Android 12+ 上仍要求定位权限才能拿到扫描结果，故一并申请（无副作用）
const BT_PERMS_NEW_COMPAT = BT_PERMS_NEW.concat(['android.permission.ACCESS_FINE_LOCATION'])
const BT_PERMS_LEGACY = ['android.permission.ACCESS_FINE_LOCATION']
const AUDIO_PERMS = ['android.permission.RECORD_AUDIO']

function isApp() {
  // #ifdef APP-PLUS
  return typeof plus !== 'undefined' && !!plus.android
  // #endif
  // #ifndef APP-PLUS
  return false
  // #endif
}

/** 系统版本号（Android API level），失败返回 0 */
function sdkInt() {
  try {
    const Build = plus.android.importClass('android.os.Build')
    const VERSION = plus.android.importClass('android.os.Build$VERSION')
    void Build
    return Number(VERSION.SDK_INT) || 0
  } catch (e) {
    return 0
  }
}

/** 当前是否已授予某权限（用 ContextCompat.checkSelfPermission 实测） */
export function hasPermission(perm) {
  if (!isApp()) return false
  try {
    const main = plus.android.runtimeMainActivity()
    const ContextCompat = plus.android.importClass('androidx.core.content.ContextCompat')
    return ContextCompat.checkSelfPermission(main, perm) === 0 // 0 = PERMISSION_GRANTED
  } catch (e) {
    console.warn('[permission] checkPermission 异常', perm, e)
    return false
  }
}

/**
 * 申请一组权限
 * @returns {Promise<{ok:boolean, granted:string[], denied:string[]}>}
 */
export function requestPermissions(perms) {
  return new Promise((resolve) => {
    if (!isApp()) {
      resolve({ ok: false, granted: [], denied: perms.slice() })
      return
    }
    const missing = perms.filter((p) => !hasPermission(p))
    if (!missing.length) {
      resolve({ ok: true, granted: perms.slice(), denied: [] })
      return
    }
    try {
      plus.android.requestPermissions(
        missing,
        (res) => {
          const granted = (res && res.granted) || []
          const denied = [].concat(
            (res && res.deniedPresent) || [],
            (res && res.deniedAlways) || []
          )
          // 再实测一次，避免回调字段缺失导致误判
          const stillMissing = missing.filter((p) => !hasPermission(p))
          resolve({
            ok: stillMissing.length === 0,
            granted: granted.concat(missing.filter((p) => stillMissing.indexOf(p) < 0)),
            denied: stillMissing.length ? stillMissing : denied,
          })
        },
        (err) => {
          console.warn('[permission] 申请失败', perms, err)
          resolve({ ok: false, granted: [], denied: missing })
        }
      )
    } catch (e) {
      console.warn('[permission] 申请异常', perms, e)
      resolve({ ok: false, granted: [], denied: missing })
    }
  })
}

/**
 * 蓝牙扫描所需权限（兼容 Android 12 前后）
 * @returns {Promise<{ok:boolean, denied:string[], sdk:number}>}
 */
export async function ensureBluetoothPermission() {
  if (!isApp()) return { ok: false, denied: [], sdk: 0, unsupported: true }
  const sdk = sdkInt()
  const perms = sdk >= 31 ? BT_PERMS_NEW_COMPAT : BT_PERMS_LEGACY
  let r = await requestPermissions(perms)
  // 蓝牙权限已给但扫描仍可能被 ROM 限制：再确保定位权限（Android 12+ 上仅兼容用）
  if (!r.ok && sdk >= 31) {
    r = await requestPermissions(['android.permission.BLUETOOTH_SCAN', 'android.permission.BLUETOOTH_CONNECT', 'android.permission.ACCESS_FINE_LOCATION'])
  }
  return { ok: r.ok, denied: r.denied, sdk }
}

/** 麦克风权限（音乐律动 / 拾音） */
export async function ensureAudioPermission() {
  const r = await requestPermissions(AUDIO_PERMS)
  return r.ok
}

/** 打开系统"应用权限"设置页（App 端） */
export function openAppPermissionSetting() {
  try {
    if (typeof uni !== 'undefined' && uni.openAppAuthorizeSetting) {
      uni.openAppAuthorizeSetting({})
      return
    }
  } catch (e) {
    /* ignore */
  }
  try {
    if (isApp()) {
      const Intent = plus.android.importClass('android.content.Intent')
      const Settings = plus.android.importClass('android.provider.Settings')
      const Uri = plus.android.importClass('android.net.Uri')
      const main = plus.android.runtimeMainActivity()
      const intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
      intent.setData(Uri.fromParts('package', main.getPackageName(), null))
      main.startActivity(intent)
    }
  } catch (e) {
    uni.showToast({ title: '请到 系统设置 → 应用 → 权限 中开启', icon: 'none' })
  }
}

/** 打开系统蓝牙设置页 */
export function openBluetoothSetting() {
  try {
    if (!isApp()) return
    const Intent = plus.android.importClass('android.content.Intent')
    const Settings = plus.android.importClass('android.provider.Settings')
    const main = plus.android.runtimeMainActivity()
    const intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
    main.startActivity(intent)
  } catch (e) {
    uni.showToast({ title: '请手动打开手机蓝牙', icon: 'none' })
  }
}

/**
 * 系统「位置信息 / 定位服务」总开关是否打开。
 * Android 扫描 BLE 需要定位服务处于开启状态（即使权限已授予），
 * 否则 startBluetoothDevicesDiscovery 会直接失败：Location services are turned off。
 */
export function isLocationServiceEnabled() {
  if (!isApp()) return true
  try {
    const main = plus.android.runtimeMainActivity()
    const Context = plus.android.importClass('android.content.Context')
    const lm = main.getSystemService(Context.LOCATION_SERVICE)
    if (!lm) return false
    plus.android.importClass(lm)
    return !!(lm.isProviderEnabled('gps') || lm.isProviderEnabled('network'))
  } catch (e) {
    // 兜底：Settings.Secure.location_mode（0=关闭，>0=开启）
    try {
      const main2 = plus.android.runtimeMainActivity()
      const Settings = plus.android.importClass('android.provider.Settings')
      plus.android.importClass('android.provider.Settings$Secure')
      const mode = Settings.Secure.getInt(main2.getContentResolver(), 'location_mode', 1)
      return Number(mode) > 0
    } catch (err) {
      return true // 查不到就不拦，交给系统返回真实错误
    }
  }
}

/** 打开系统「位置信息 / 定位服务」设置页（不是应用权限页） */
export function openLocationSetting() {
  try {
    if (!isApp()) return false
    const Intent = plus.android.importClass('android.content.Intent')
    const Settings = plus.android.importClass('android.provider.Settings')
    const main = plus.android.runtimeMainActivity()
    const intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
    main.startActivity(intent)
    return true
  } catch (e) {
    uni.showToast({ title: '请手动打开 设置 → 位置信息', icon: 'none' })
    return false
  }
}

/**
 * 把扫描失败的英文原始错误翻译成可执行的中文提示
 * @returns {{text:string, action:'location'|'bluetooth'|'app'|''}}
 */
export function describeScanError(msg) {
  const s = String(msg || '')
  if (/location\s*services?\s*(are\s*)?(turned\s*off|disabled)|定位服务|位置信息/i.test(s)) {
    return {
      // 实测：定位开关本来是开着的，但系统侧状态没刷新，扫描仍报这个错。
      // 关闭再打开一次定位开关即可恢复，因此提示里直接给出这个操作。
      text: '系统定位服务状态异常。若定位开关本来就是打开的，请把它关闭再打开一次（刷新系统状态），然后点「重新搜索」；若定位未开，请先打开定位',
      action: 'location',
    }
  }
  if (/bluetooth.*(off|disabled|powered)|not\s*available|10001|适配器/i.test(s)) {
    return { text: '手机蓝牙未开启，请打开蓝牙后重试', action: 'bluetooth' }
  }
  if (/permission|denied|auth|未授权|not\s*authorized/i.test(s)) {
    return { text: '缺少蓝牙/定位权限，请在系统设置中允许后重试', action: 'app' }
  }
  return { text: s || '蓝牙扫描启动失败', action: '' }
}
