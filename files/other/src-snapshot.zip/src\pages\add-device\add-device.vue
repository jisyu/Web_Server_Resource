<template>
<view class="page-wrap">
  <!-- 顶部状态栏 -->
  <view class="card header-card">
    <view class="row">
      <text style="font-size:30rpx;font-weight:600;color:#e4e4ed">{{scanning ? '正在搜索附近设备…' : '已停止扫描'}}</text>
      <button class="mini" size="mini" @tap="toggleScan">{{scanning ? '停止' : '重新搜索'}}</button>
    </view>
    <view class="sub-row">
      <text class="muted">已发现 {{list.length}} 台设备</text>
      <view class="switch" @tap="toggleBrand">
        <text class="switch-label">{{onlyBrand ? '仅本品牌' : '全部设备'}}</text>
        <view :class="'switch-track ' + (onlyBrand ? 'on' : 'off')"><view class="switch-thumb"></view></view>
      </view>
    </view>
    <view class="muted hint">请确保设备已通电并处于配对状态</view>
    <!-- 扫描异常诊断信息（定位开关 / 蓝牙开关 / 权限，按原因给对应入口） -->
    <view v-if="scanError" class="scan-error">
      <text class="scan-error-t">扫描异常：{{scanError}}</text>
      <text class="scan-error-a" @tap="openAppSetting">{{scanErrorActionText}} ›</text>
    </view>
  </view>

  <!-- 设备列表 -->
  <scroll-view scroll-y class="scan-list">
    <block v-for="(item, index) in list" :key="item.deviceId">
      <view v-if="!onlyBrand || item.isRGBYW" class="card dev-card" @tap="tapDevice" :data-i="(index)">
        <view class="row dev-row">
          <view class="dev-main">
            <view class="dev-title">
              <text style="font-size:30rpx;font-weight:600;color:#e4e4ed">{{item.name}}</text>
              <text v-if="item.isRGBYW" class="tag brand">RGBYW</text>
              <text v-else class="tag other">BLE</text>
            </view>
            <view class="muted">{{item.typeName}} · RSSI {{item.rssi}} · {{item.shortId}}</view>
          </view>
          <view class="signal">
            <view :class="'bar ' + (item.signal >= 1 ? 'on' : '')"></view>
            <view :class="'bar ' + (item.signal >= 2 ? 'on' : '')"></view>
            <view :class="'bar ' + (item.signal >= 3 ? 'on' : '')"></view>
          </view>
        </view>
      </view>
    </block>

    <view v-if="list.length === 0 && !scanning" class="empty-state">
      <view class="empty-text">未发现设备</view>
      <view class="empty-hint">点击上方"重新搜索"</view>
    </view>

    <view v-if="connecting" class="loading-mask">
      <view class="loading-box">
        <view class="spinner"></view>
        <text class="loading-text">正在连接…</text>
      </view>
    </view>
  </scroll-view>

  <!-- 命名 + 确认连接 弹窗 -->
  <view v-if="showRename" class="modal-mask" @tap="cancelRename">
    <view class="modal" @tap.stop="">
      <view class="modal-title">添加设备</view>
      <view class="modal-body">
        <view class="muted modal-dev-info">{{renameTarget.typeName}} · {{renameTarget.shortId}}</view>
        <input class="name-input" :value="(renameName)" placeholder="给设备起个名字" placeholder-class="ph" maxlength="20" @input="onRenameInput" confirm-type="done" @confirm="confirmAdd" :focus="(showRename)" />
      </view>
      <view class="modal-footer">
        <button class="btn-cancel" size="mini" @tap="cancelRename">取消</button>
        <button class="btn-confirm" size="mini" @tap="confirmAdd">确认添加</button>
      </view>
    </view>
  </view>

  <!-- 连接成功结果弹窗（暗色，与小程序风格一致） -->
  <ui-modal :show="(showResultModal)" title="连接成功" :lines="(resultLines)" btn-text="确定" @confirm="onResultOk" />
</view>
</template>

<script>
import { ble } from '@/utils/ble'

import { getDeviceMeta } from '@/utils/deviceType';
import deviceStore from '@/utils/deviceStore';
import {
  ensureBluetoothPermission,
  openAppPermissionSetting,
  openBluetoothSetting,
  openLocationSetting,
  describeScanError,
} from '@/utils/permission';

export default {
data() {
    return {
    list: [],           // 全量扫描到的设备
    onlyBrand: true,
    scanning: false,

    // 命名弹窗
    showRename: false,
    renameTarget: null, // 当前要添加的设备对象
    renameName: '',     // 用户输入的名称

    connecting: false,   // 正在连接中
    showResultModal: false,  // 连接成功弹窗（暗色自绘）
    resultLines: [],         // 弹窗内容 [{k, v}]
    scanError: '',           // 扫描失败原因（已翻译为用户可执行的提示）
    scanErrorAction: '',     // 错误对应的处理入口：location / bluetooth / app / ''
  }
  },
computed: {
    scanErrorActionText() {
      if (this.scanErrorAction === 'location') return '去开启位置信息';
      if (this.scanErrorAction === 'bluetooth') return '去打开蓝牙';
      if (this.scanErrorAction === 'app') return '打开应用权限设置';
      return '打开系统设置';
    },
  },
onLoad() {
    this._init();
  },
onShow() {
    // 从系统设置/控制中心返回：上次因定位相关错误失败时，自动重试一次扫描
    // （不预判定位状态：部分机型查询结果显示已开，实际仍需本次"关闭再打开"来刷新系统状态）
    if (this.scanError && this.scanErrorAction === 'location' && !this.scanning) this.start();
  },
onUnload() {
    if (ble) ble.stopScan();
    this.setData({ scanning: false });
  },

  methods: {
async _init() {
    try {
      // App 端：自行申请蓝牙/定位运行时权限（Android 12 前后权限集不同）
      const perm = await ensureBluetoothPermission();
      if (perm && perm.ok === false && !perm.unsupported) {
        const names = (perm.denied || []).map((p) => String(p).replace('android.permission.', '')).join('/');
        this.setData({
          scanError: '未授予蓝牙权限' + (names ? '（' + names + '）' : '') + '，请在系统设置中允许后重试',
          scanErrorAction: 'app',
        });
      }
      await ble.init();
      await this.start();
    } catch (e) {
      const msg = (e && (e.message || e.errMsg)) || '蓝牙不可用'
      const info = describeScanError(msg);
      this.setData({ scanError: info.text, scanErrorAction: info.action });
      this._toastError(info);
    }
  },
async start() {
    // 上一次是"定位状态"类错误：先重开一次蓝牙适配器，让系统重新取一次定位状态
    // （不做预先拦截：部分机型查询到定位已开，扫描仍会因系统缓存报错）
    const wasLocationError = this.scanErrorAction === 'location';
    // 先清空列表，让用户立即看到"已清空"
    this.setData({ list: [], scanning: true, scanError: '', scanErrorAction: '' });
    if (wasLocationError) {
      try {
        ble.close();
        await new Promise((r) => setTimeout(r, 300));
        await ble.init();
      } catch (err) { /* 重置失败不阻断，继续尝试扫描 */ }
    }
    try {
      await ble.startScan((device) => this._onDevice(device));
    } catch (e) {
      const raw = (e && (e.message || e.errMsg)) || '未知错误'
      const info = describeScanError(raw)
      this.setData({ scanning: false, scanError: info.text, scanErrorAction: info.action });
      if (e && e.kind === 'busy') uni.showToast({ title: '控制期间不能扫描，请先返回停止控制', icon: 'none' });
      try {
        const b = getApp().globalData && getApp().globalData.ble
        if (b && b._log) b._log('[SCAN] 启动失败: ' + raw, 'warn')
      } catch (_) { /* ignore */ }
      this._toastError(info);
    }
  },
_toastError(info) {
    const map = { location: '请开启系统定位服务', bluetooth: '请打开手机蓝牙', app: '请授予蓝牙权限' };
    uni.showToast({ title: map[info.action] || String(info.text).slice(0, 20), icon: 'none' });
  },
// 按错误类型跳对应系统设置页（定位服务 / 蓝牙 / 应用权限）
openAppSetting() {
    if (this.scanErrorAction === 'location') {
      if (openLocationSetting()) return;
    } else if (this.scanErrorAction === 'bluetooth') {
      openBluetoothSetting();
      return;
    }
    openAppPermissionSetting()
  },
_onDevice(device) {
    const list = this.list;
    if (list.some((d) => d.deviceId === device.deviceId)) return;
    list.push({
      deviceId: device.deviceId,
      shortId: device.deviceId.slice(-6).toUpperCase(),
      name: device.name,
      isRGBYW: device.isRGBYW,
      typeId: device.typeId,
      typeName: device.typeId != null ? (getDeviceMeta(device.typeId).name || '未知类型') : '未知设备',
      model: device.model || '',
      mac: device.mac || '',
      byteOrder: device.raw ? device.raw.byteOrder : '',
      ledCount: device.ledCount || 0,
      vendorId: device.vendorId || 0,
      config: device.config || 0,
      advHex: device.advHex || '',
      rssi: device.rssi == null ? 0 : device.rssi,
      signal: device.rssi == null ? 0 : (device.rssi >= -50 ? 3 : device.rssi >= -65 ? 2 : device.rssi >= -80 ? 1 : 0),
    });
    this.setData({ list });
  },
toggleBrand() {
    this.setData({ onlyBrand: !this.onlyBrand });
  },
async toggleScan() {
    if (this.scanning) {
      // 停止扫描
      ble.stopScan();
      this.setData({ scanning: false });
    } else {
      // 重新搜索：先停掉可能残留的扫描，清空列表，再重新开始
      ble.stopScan();
      this.setData({ list: [] });
      await this.start();
    }
  },
tapDevice(e) {
    const idx = e.currentTarget.dataset.i;
    const item = this.list[idx];
    if (!item) return;

    // 用广播名作为默认名，去掉常见前缀
    let defaultName = item.name || '未命名设备';
    defaultName = defaultName.replace(/^(qH-|qh-|BT_|BLE_)/i, '').replace(/_/g, ' ').trim() || defaultName;

    this.setData({
      showRename: true,
      renameTarget: item,
      renameName: defaultName,
    });
  },
onRenameInput(e) {
    this.setData({ renameName: e.detail.value.trim() });
  },
onResultOk() {
    this.setData({ showResultModal: false });
    uni.navigateBack({
      delta: 1,
      fail: () => uni.reLaunch({ url: '/pages/index/index' }),
    });
  },
cancelRename() {
    this.setData({ showRename: false, renameTarget: null, renameName: '' });
  },
async confirmAdd() {
    const target = this.renameTarget;
    const name = this.renameName;
    if (!target) return;
    if (!name || name.length === 0) {
      uni.showToast({ title: '请输入设备名称', icon: 'none' });
      return;
    }

    this.setData({ showRename: false, connecting: true });

    // 先停止扫描（避免干扰连接）
    ble.stopScan();
    this.setData({ scanning: false });

    try {
      await ble.connect(target.deviceId);

      // 连接成功 → 存储到本地
      deviceStore.save({
        deviceId: target.deviceId,
        name,
        typeId: target.typeId != null ? target.typeId : 1,
        model: target.model || target.typeName,
        shortId: target.shortId,
      });

      this.setData({ connecting: false });

      // 连接完成 → 消息提示框显示设备类型 + 广播信息
      // typeId 未知时不做兜底显示，避免误标为某类设备
      const known = target.typeId != null && target.typeId > 0;
      const typeId = known ? target.typeId : null;
      const meta = getDeviceMeta(typeId != null ? typeId : 0);
      const hex = typeId != null ? ('000' + typeId.toString(16).toUpperCase()).slice(-4) : null;
      // 广播配置位：Bit0 冷光调节 / Bit1 暖光调节 / Bit2 音频律动
      const cfg = target.config || 0;
      const cfgBits = [];
      if (cfg & 0x01) cfgBits.push('冷光');
      if (cfg & 0x02) cfgBits.push('暖光');
      if (cfg & 0x04) cfgBits.push('音频律动');
      const lines = known ? [
        { k: '设备类型', v: meta.name + '（0x' + hex + '）' },
        { k: '设备型号', v: target.model || '-' },
        { k: 'MAC', v: target.mac || '-' },
        { k: '广播字节序', v: target.byteOrder || '-' },
        { k: '灯珠数量', v: target.ledCount || '-' },
        { k: '厂商ID', v: target.vendorId != null ? target.vendorId : '-' },
        { k: '信号强度', v: target.rssi != null ? target.rssi + ' dBm' : '-' },
        { k: '配置项', v: (cfgBits.length ? cfgBits.join('/') : '无') + '（0x' + ((cfg < 16 ? '0' : '') + cfg.toString(16).toUpperCase()) + '）' },
      ] : [
        { k: '设备类型', v: '未识别（广播无有效类型ID）' },
        { k: '信号强度', v: target.rssi != null ? target.rssi + ' dBm' : '-' },
        { k: '广播数据', v: target.advHex || '无' },
      ];
      // 暗色自绘弹窗（与小程序主题一致）
      this.setData({ showResultModal: true, resultLines: lines });
    } catch (err) {
      this.setData({ connecting: false });
      uni.showToast({ title: '连接失败，请重试', icon: 'none' });
      // 连接失败后恢复扫描
      this.start();
    }
  },
  },
}
</script>

<style>
/* ===== 暗色主题添加设备页 ===== */

page {
  background: #0d0d1a;
  color: #e4e4ed;
}

.page-wrap {
  display: flex; flex-direction: column;
  height: 100vh; overflow: hidden;
}

.card {
  background: linear-gradient(135deg, #1a1a2e, #16162a);
  border-radius: 20rpx;
  padding: 28rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 4rpx 24rpx rgba(0,0,0,.3);
}
.row { display:flex; align-items:center; justify-content:space-between; }
.muted { color:#7a7a96; font-size:24rpx; }

/* 头部卡片 */
.header-card { margin:20rpx 24rpx 0; border:1rpx solid rgba(168,85,247,.08); }
.mini {
  background:#a855f7; color:#fff; font-size:22rpx; margin:0; padding:0 22rpx; border-radius:28rpx;
}
.sub-row {
  display:flex; align-items:center; justify-content:space-between;
  margin-top:18rpx; padding-top:16rpx;
  border-top:1rpx solid rgba(255,255,255,.06);
}
.hint { margin-top:10rpx; font-size:22rpx; opacity:.6; }

/* 扫描异常诊断 */
.scan-error { margin-top:16rpx; padding:16rpx; border-radius:12rpx; background:rgba(229,72,77,.12); border:1rpx solid rgba(229,72,77,.35); }
.scan-error-t { display:block; font-size:22rpx; color:#ff8a8f; line-height:1.5; }
.scan-error-a { display:block; margin-top:8rpx; font-size:22rpx; color:#a855f7; }

/* 过滤开关 */
.switch { display:flex; align-items:center; }
.switch-label { font-size:24rpx; color:#a855f7; margin-right:14rpx; }
.switch-track { width:84rpx; height:44rpx; border-radius:22rpx; background:#2a2a40; position:relative; transition:background .2s; }
.switch-track.on { background:#a855f7; }
.switch-thumb { position:absolute; top:4rpx; left:4rpx; width:36rpx; height:36rpx; border-radius:50%; background:#fff; transition:left .2s; }
.switch-track.on .switch-thumb { left:44rpx; }

/* 扫描列表 */
.scan-list { flex:1; padding:0 24rpx; }

.dev-card {
  transition: transform .12s; cursor:pointer;
  border:1rpx solid rgba(168,85,247,.06);
}
.dev-card:active { transform: scale(.97); }
.dev-main { flex:1; min-width:0; }
.dev-title { display:flex; align-items:center; flex-wrap:wrap; }
.tag { font-size:20rpx; padding:2rpx 14rpx; border-radius:20rpx; margin-left:12rpx; }
.tag.brand { background:rgba(168,85,247,.15); color:#c084fc; }
.tag.other { background:rgba(255,255,255,.06); color:#666680; }

/* 信号格 */
.signal { display:flex; align-items:flex-end; height:48rpx; margin-left:16rpx; }
.signal .bar { width:8rpx; margin-left:4rpx; border-radius:4rpx; background:#2a2a40; transition:background .15s; }
.signal .bar:nth-child(1) { height:20rpx; }
.signal .bar:nth-child(2) { height:30rpx; }
.signal .bar:nth-child(3) { height:42rpx; }
.signal .bar.on { background:#a855f7; }

/* 空状态 */
.empty-state { display:flex; flex-direction:column; align-items:center; padding-top:160rpx; }
.empty-text { font-size:30rpx; color:#666680; margin-bottom:10rpx; }
.empty-hint { font-size:24rpx; color:#444458; }

/* 连接中遮罩 */
.loading-mask {
  position:absolute; inset:0; z-index:50;
  display:flex; align-items:center; justify-content:center;
  background:rgba(13,13,26,.65); backdrop-filter:blur(4rpx);
}
.loading-box { display:flex; flex-direction:column; align-items:center; }
.spinner {
  width:60rpx; height:60rpx; border:5rpx solid #2a2a40;
  border-top-color:#a855f7; border-radius:50%;
  animation:spin .7s linear infinite;
}
@keyframes spin { to{transform:rotate(360deg);} }
.loading-text { color:#c0c0d0; font-size:26rpx; margin-top:20rpx; }

/* ===== 命名弹窗 ===== */
.modal-mask {
  position:fixed; inset:0; z-index:999;
  display:flex; align-items:center; justify-content:center;
  background:rgba(0,0,0,.6); backdrop-filter:blur(6rpx);
}
.modal {
  width:600rpx; background:#1a1a2e; border-radius:28rpx;
  padding:44rpx 36rpx 32rpx; box-shadow:0 20rpx 60rpx rgba(0,0,0,.5);
  border:1rpx solid rgba(168,85,247,.15);
}
.modal-title {
  font-size:34rpx; font-weight:700; color:#e4e4ed; text-align:center; margin-bottom:24rpx;
}
.modal-body { margin-bottom:36rpx; }
.modal-dev-info { text-align:center; margin-bottom:20rpx; font-size:24rpx; }
.name-input {
  width:100%; height:88rpx; line-height:88rpx;
  background:#0d0d1a; border:2rpx solid #2a2a40; border-radius:16rpx;
  padding:0 24rpx; box-sizing:border-box;
  font-size:30rpx; color:#e4e4ed; text-align:center;
  transition:border-color .2s;
}
.name-input:focus { border-color:#a855f7; }
.ph { color:#55556a; text-align:center; }

.modal-footer {
  display:flex; gap:20rpx; justify-content:flex-end;
}
.btn-cancel {
  background:transparent; color:#8888a0; border:1rpx solid #33334a; font-size:26rpx; border-radius:28rpx;
}
.btn-confirm {
  background:linear-gradient(135deg,#9333ea,#a855f7); color:#fff; font-size:26rpx; border-radius:28rpx;
}
</style>
