<template>
<view class="um-mask" v-if="show" @tap.stop="noop">
  <view class="um-card" @tap.stop="noop">
    <view class="um-title">{{title}}</view>
    <view class="um-body">
      <view v-for="(item, index) in lines" class="um-line" :key="index">
        <text class="um-k">{{item.k}}</text>
        <text class="um-v">{{item.v}}</text>
      </view>
    </view>
    <view class="um-btn" @tap="onOk">{{btnText}}</view>
  </view>
</view>
</template>

<script>
// ui-modal：暗色主题通用弹窗（与小程序整体风格一致）
// 用法：
//   <ui-modal show="{{show}}" title="标题" lines="{{rows}}" btn-text="确定" bindconfirm="onOk" />
//   rows: [{ k: '键', v: '值' }, ...]  两列键值排版
export default {
  props: {
    show: { type: Boolean, default: false },
    title: { type: String, default: '' },
    lines: { type: Array, default: () => [] },     // [{k, v}]
    btnText: { type: String, default: '确定' },
  },

  methods: {
    onOk() {
      this.$emit('confirm');
    },
    noop() { /* 阻止冒泡，点击遮罩/卡片不关闭 */ },
  },
}
</script>

<style>
.um-mask {
  position: fixed; inset: 0; z-index: 999;
  background: rgba(0, 0, 0, 0.72);
  display: flex; align-items: center; justify-content: center;
}
.um-card {
  width: 580rpx; max-height: 72vh;
  background: linear-gradient(160deg, #1a1a2e, #14142a);
  border: 1rpx solid rgba(168, 85, 247, 0.28);
  border-radius: 24rpx;
  padding: 40rpx 36rpx 32rpx;
  box-sizing: border-box;
  box-shadow: 0 16rpx 60rpx rgba(0, 0, 0, 0.6);
}
.um-title {
  text-align: center;
  font-size: 34rpx; font-weight: 700; color: #e8e8f0;
  margin-bottom: 30rpx;
}
.um-body { margin-bottom: 34rpx; }
.um-line {
  display: flex; align-items: flex-start;
  padding: 8rpx 0;
}
.um-k {
  flex-shrink: 0; width: 172rpx;
  font-size: 26rpx; color: rgba(255, 255, 255, 0.5);
}
.um-v {
  flex: 1; font-size: 26rpx; color: #e8e8f0;
  word-break: break-all;
}
.um-btn {
  height: 84rpx; border-radius: 42rpx;
  display: flex; align-items: center; justify-content: center;
  font-size: 30rpx; font-weight: 600; color: #fff;
  background: linear-gradient(90deg, #a855f7, #7c3aed);
  box-shadow: 0 8rpx 24rpx rgba(124, 58, 237, 0.35);
}
.um-btn:active { opacity: 0.85; }
</style>
