<template>
<view class="sp-wrap" v-show="!(hidden)">
  <!-- 子 Tab：温湿度 / 光照度 / 红外 / 雷达 / 设置 -->
  <view class="sub-tabs">
    <view v-for="(item, index) in subTabs" :class="'sub-tab ' + (currentSub === index ? 'active' : '')" :data-index="(index)" @tap="switchSubTab" :key="item.name">{{item.name}}</view>
  </view>

  <!-- ===== 温湿度子页（主）===== -->
  <block v-if="currentSub === 0">
    <!-- 数值 -->
    <view class="card">
      <text class="card-title">数值</text>
      <view class="val-row">
        <view class="val-item">
          <text class="val-label">温度</text>
          <text class="val-num">{{tempVal}}℃</text>
        </view>
        <view class="val-item">
          <text class="val-label">home.humidity</text>
          <text class="val-num">{{humiVal}}%</text>
        </view>
      </view>
    </view>

    <!-- 精度 -->
    <view class="card">
      <text class="card-title">精度</text>
      <view class="slider-row">
        <text class="sl-label">温度精度</text>
        <slider min="1" max="100" :value="(tempPrecision)" activeColor="#00b894" backgroundColor="rgba(0,184,148,.15)" block-size="24" block-color="#00b894" @change="onTempPrecision" />
        <text class="sl-val">{{tempPrecisionStr}}℃</text>
      </view>
      <view class="slider-row">
        <text class="sl-label">湿度精度</text>
        <slider min="1" max="100" :value="(humiPrecision)" activeColor="#00b894" backgroundColor="rgba(0,184,148,.15)" block-size="24" block-color="#00b894" @change="onHumiPrecision" />
        <text class="sl-val">{{humiPrecisionStr}}%</text>
      </view>
    </view>

    <!-- 阈值 -->
    <view class="card">
      <text class="card-title">阈值</text>
      <view class="slider-row">
        <text class="sl-label">温度阈值</text>
        <slider min="-2000" max="8000" :value="(tempThreshold)" activeColor="#00b894" backgroundColor="rgba(0,184,148,.15)" block-size="24" block-color="#00b894" @change="onTempTh" />
        <text class="sl-val">{{tempThStr}}℃</text>
      </view>
      <view class="slider-row">
        <text class="sl-label">湿度阈值</text>
        <slider min="0" max="10000" :value="(humiThreshold)" activeColor="#00b894" backgroundColor="rgba(0,184,148,.15)" block-size="24" block-color="#00b894" @change="onHumiTh" />
        <text class="sl-val">{{humiThStr}}%</text>
      </view>
    </view>

    <!-- 动作 -->
    <view class="card">
      <view class="row" style="justify-content:space-between;align-items:center;margin-bottom:16rpx">
        <text class="card-title" style="margin:0">动作</text>
        <text class="add-btn" @tap="onAddAction">+ 添加</text>
      </view>
      <view v-if="actions.length === 0" class="empty-action">
        暂无动作，点击添加按钮添加动作
      </view>
      <view v-for="(item, index) in actions" class="action-item" :key="item.id">
        <text>{{item.text}}</text>
        <text class="action-del" :data-id="(item.id)" @tap="onDelAction">×</text>
      </view>
    </view>

    <!-- 底部操作 -->
    <view class="action-row">
      <button class="act-btn clear" @tap="onClear">↻ 清空</button>
      <button class="act-btn save" @tap="onSave">💾 保存</button>
    </view>
  </block>

  <!-- ===== 其他传感器 Tab（占位）===== -->
  <block v-if="currentSub === 1">
    <view class="placeholder-box"><text class="ph-text">光照度传感器（待实现）</text></view>
  </block>
  <block v-if="currentSub === 2">
    <view class="placeholder-box"><text class="ph-text">红外传感器（待实现）</text></view>
  </block>
  <block v-if="currentSub === 3">
    <view class="placeholder-box"><text class="ph-text">雷达传感器（待实现）</text></view>
  </block>
  <block v-if="currentSub === 4">
    <view class="placeholder-box"><text class="ph-text">感类设置（待实现）</text></view>
  </block>
</view>
</template>

<script>
import protocol from '@/utils/protocol';

export default {
  props: {
    typeId: { type: Number, default: 1 },
    caps: { type: Object, default: () => ({}) },
    hidden: { type: Boolean, default: false },
  },

  data() {

    return {
    subTabs: [
      { name: '温湿度', id: 0x01 },
      { name: '光照度', id: 0x02 },
      { name: '红外', id: 0x03 },
      { name: '雷达', id: 0x04 },
      { name: '设置' },
    ],
    currentSub: 0,

    // 温湿度数值（占位，待协议接入）
    tempVal: '--',
    humiVal: '--',

    // 精度
    tempPrecision: 50,
    tempPrecisionStr: '0.50',
    humiPrecision: 500,
    humiPrecisionStr: '5.00',

    // 阈值
    tempThreshold: 3000,
    tempThStr: '30.00',
    humiThreshold: 8000,
    humiThStr: '80.00',

    // 动作列表
    actions: [],
    _actionId: 0,

    // 联动/延时
    linkageOn: false,
    delaySec: 10,
  }

  },

  methods: {
    _emit(func, data) { this.$emit('cmd', { func, data }); },

    switchSubTab(e) {
      const idx = Number(e.currentTarget.dataset.index);
      this.setData({ currentSub: idx });
      // 切换 Tab 时查询该传感器数据
      if (idx < 4) {
        const sid = this.subTabs[idx].id;
        this._emit(protocol.CMD.SENSOR_GET, protocol.sensor.get(sid));
      }
    },

    // ====== 精度 ======
    onTempPrecision(e) {
      const v = e.detail.value;
      this.setData({ tempPrecision: v, tempPrecisionStr: (v / 100).toFixed(2) });
      this._emit(protocol.CMD.SENSOR_SET, protocol.sensor.set(0x01, 0x02, v));
    },

    onHumiPrecision(e) {
      const v = e.detail.value;
      this.setData({ humiPrecision: v, humiPrecisionStr: (v / 100).toFixed(2) });
      this._emit(protocol.CMD.SENSOR_SET, protocol.sensor.set(0x01, 0x02, v));
    },

    // ====== 阈值 ======
    onTempTh(e) {
      const v = e.detail.value;
      const realV = v / 100;
      this.setData({ tempThreshold: v, tempThStr: realV.toFixed(2) });
      this._emit(protocol.CMD.SENSOR_SET, protocol.sensor.set(0x01, 0x02, v));
    },

    onHumiTh(e) {
      const v = e.detail.value;
      this.setData({ humiThreshold: v, humiThStr: (v / 100).toFixed(2) });
      this._emit(protocol.CMD.SENSOR_SET, protocol.sensor.set(0x01, 0x02, v));
    },

    // ====== 动作 ======
    onAddAction() {
      uni.showActionSheet({
        itemList: ['开灯', '关灯', '发送通知'],
        success: (res) => {
          const names = ['开灯', '关灯', '发送通知'];
          const id = ++this._actionId;
          const actions = this.actions.concat([{ id, text: names[res.tapIndex] }]);
          this.setData({ actions, _actionId: id });

          // 下发联动指令（param 0x03）
          this._emit(protocol.CMD.SENSOR_SET, [0x01, 0x03, res.tapIndex + 1]);
        },
      });
    },

    onDelAction(e) {
      const id = e.currentTarget.dataset.id;
      this.setData({ actions: this.actions.filter((a) => a.id !== id) });
    },

    // 底部操作
    onClear() {
      this.setData({
        tempVal: '--', humiVal: '--',
        tempPrecision: 50, tempPrecisionStr: '0.50',
        humiPrecision: 500, humiPrecisionStr: '5.00',
        tempThreshold: 3000, tempThStr: '30.00',
        humiThreshold: 8000, humiThStr: '80.00',
        actions: [],
      });
      uni.showToast({ title: '已清空', icon: 'none' });
    },

    onSave() {},

    // 外部调用：更新实时值
    setRealtime(sensorId, val) {
      if (sensorId === 0x01 && typeof val === 'string') {
        const parts = val.split(' / ');
        if (parts[0]) this.setData({ tempVal: parts[0].replace('℃', '') });
        if (parts[1]) this.setData({ humiVal: parts[1].replace('%', '') });
      }
    },
  },
}
</script>

<style>
.sp-wrap { padding: 0 28rpx 32rpx; }

/* 子 Tab（下划线风格） */
.sub-tabs {
  display: flex; gap: 40rpx; justify-content: center; padding: 14rpx 0 20rpx;
}
.sub-tab {
  font-size: 28rpx; color: rgba(255,255,255,.35);
  position: relative; padding-bottom: 10rpx;
}
.sub-tab.active { color: #00b894; font-weight: 500; }
.sub-tab.active::after {
  content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 36rpx; height: 4rpx; border-radius: 2rpx; background: #00b894;
}

/* ====== 卡片通用 ====== */
.card {
  background: linear-gradient(135deg, #16162e, #131324);
  border-radius: 18rpx;
  padding: 28rpx;
  margin-bottom: 22rpx;
  border: 1rpx solid rgba(0,184,148,.08);
}
.card-title {
  font-size: 28rpx; font-weight: 600; color: rgba(255,255,255,.7);
  display: block; margin-bottom: 20rpx;
}

/* 数值区 */
.val-row { display: flex; gap: 40rpx; }
.val-item { flex: 1; display: flex; flex-direction: column; gap: 8rpx; }
.val-label { font-size: 24rpx; color: rgba(255,255,255,.38); }
.val-num {
  font-size: 44rpx; font-weight: 700; color: #55efc4;
  letter-spacing: -1rpx;
}

/* 滑块行 */
.slider-row {
  display: flex; align-items: center; gap: 12rpx; margin-bottom: 16rpx;
}
.sl-label { font-size: 26rpx; color: rgba(255,255,255,.5); min-width: 120rpx; }
.slider-row slider { flex: 1; }
.sl-val { font-size: 26rpx; color: #55efc4; min-width: 100rpx; text-align: right; }

/* 动作 */
.add-btn {
  font-size: 26rpx; color: #55efc4;
  border: 1rpx solid rgba(85,239,196,.3);
  padding: 6rpx 24rpx; border-radius: 12rpx;
}
.empty-action {
  text-align: center; color: rgba(255,255,255,.25); font-size: 26rpx;
  padding: 32rpx 0 8rpx;
}
.action-item {
  display: flex; justify-content: space-between; align-items: center;
  padding: 16rpx 20rpx; background: rgba(0,184,148,.06);
  border-radius: 12rpx; margin-bottom: 10rpx;
  font-size: 26rpx; color: rgba(255,255,255,.65);
}
.action-del {
  font-size: 36rpx; color: rgba(255,107,107,.6); line-height: 1;
}

/* 占位 */
.placeholder-box { padding: 120rpx 0; text-align: center; }
.ph-text { color: rgba(255,255,255,.25); font-size: 28rpx; }

/* 底部按钮 */
.action-row { display: flex; gap: 24rpx; padding: 32rpx 0 8rpx; }
.act-btn {
  flex: 1; height: 80rpx; line-height: 80rpx; border-radius: 18rpx;
  font-size: 28rpx; font-weight: 500; border: none;
}
.act-btn.clear {
  background: transparent; color: rgba(255,255,255,.55);
  border: 1rpx solid rgba(255,255,255,.12);
}
.act-btn.save {
  background: linear-gradient(135deg, rgba(0,184,148,.25), rgba(0,184,148,.15));
  color: #55efc4; border: 1rpx solid rgba(0,184,148,.2);
}
</style>
