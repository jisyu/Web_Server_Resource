/**
 * 启动页生成的覆盖配置 —— 由 _tools/apply-splash-video.ps1 全量重写，请勿手工修改。
 *
 * customer    客户标识（-Customer，可空）
 * generatedAt 生成时间
 * videoSrc    视频相对路径（'' 表示使用内置动画）
 * overrides   与 src/config/splash.js 的 DEFAULT_CONFIG 深合并的覆盖项
 */
export default {
    "customer":  "",
    "generatedAt":  "2026-10-23 09:59:35",
    "videoSrc":  "/static/splash/splash-video.mp4",
    "overrides":  {
                      "video":  {
                                    "enabled":  true,
                                    "src":  "/static/splash/splash-video.mp4",
                                    "loop":  false,
                                    "muted":  true,
                                    "objectFit":  "cover",
                                    "poster":  "/static/splash/splash-still.jpg",
                                    "still":  {
                                                  "enabled":  true,
                                                  "image":  "/static/splash/splash-still.jpg",
                                                  "duration":  1500
                                              },
                                    "overlay":  0.2,
                                    "hideBrand":  false,
                                    "syncProgress":  true
                                },
                      "progress":  {
                                       "show":  true,
                                       "duration":  8000,
                                       "interval":  50,
                                       "holdAfterFull":  300
                                   }
                  }
};