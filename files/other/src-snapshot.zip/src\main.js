import { createSSRApp } from 'vue'
import App from './App.vue'

/**
 * setData 兼容层
 *
 * 小程序迁移过来的页面/组件保留了 this.setData({...}) 写法（含 'a.b' 路径写法），
 * 这里用 Vue 的直接赋值语义实现：普通键直接赋值触发响应式，路径键按对象链下钻赋值。
 * 要求：所有会被 setData 写入的键必须在 data() 中事先声明（Vue3 响应式的限制）。
 */
function applyPatch(vm, patch) {
  if (!patch || typeof patch !== 'object') return
  Object.keys(patch).forEach((key) => {
    const value = patch[key]
    if (key.indexOf('.') < 0) {
      vm[key] = value
      return
    }
    const parts = key.split('.')
    let target = vm
    for (let i = 0; i < parts.length - 1; i++) {
      if (target[parts[i]] == null) target[parts[i]] = {}
      target = target[parts[i]]
    }
    if (target && typeof target === 'object') {
      target[parts[parts.length - 1]] = value
    }
  })
}

export function createApp() {
  const app = createSSRApp(App)

  app.mixin({
    methods: {
      setData(patch) {
        applyPatch(this, patch)
      },
    },
  })

  // 未捕获异常统一记录，便于真机排障
  app.config.errorHandler = (err, instance, info) => {
    console.error('[app] unhandled error:', info, err && (err.stack || err.message || err))
  }

  return {
    app,
  }
}
