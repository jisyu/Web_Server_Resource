<template>
<view class="lp-wrap" :class="{ 'tips-off': !showTips }" v-show="!(hidden)">
  <!-- 灯珠数量 -->
  <view class="row led-row">
    <text class="label">灯珠数量：</text>
    <text class="led-val">{{ledCount}}</text>
    <text class="edit-icon" @tap="onEditLed">✎</text>
  </view>

  <!-- 亮度：色温栏作用于冷暖亮度(0~100)，彩色栏作用于整体/RGB 亮度，两路独立保存 -->
  <view class="section">
    <view class="row brightness-row">
      <text class="label">{{brightIsWarm ? '色温亮度' : '亮度'}}</text>
      <slider class="bright-slider" :min="(brightIsWarm ? 0 : (isStrip?100:0))" :max="(brightIsWarm ? 100 : (isStrip?1000:100))" :value="(brightIsWarm ? warmBrightness : brightness)" activeColor="#a855f7" backgroundColor="rgba(168,85,247,.18)" block-size="28" block-color="#a855f7" @changing="onBrightness" @change="onBrightness" />
      <text class="bright-pct">{{brightIsWarm ? warmBrightnessPct : brightnessPct}}%</text>
    </view>
    <view class="row brightness-row speed-row" v-if="caps.speed">
      <text class="label">速度</text>
      <slider class="bright-slider" min="1" max="100" step="1" :value="(speed)" activeColor="#22d3ee" backgroundColor="rgba(34,211,238,.18)" block-size="28" block-color="#22d3ee" @changing="onSpeedChanging" @change="onSpeedChange" />
      <text class="speed-value">{{speed}}%</text>
    </view>
  </view>

  <!-- 子 Tab：按设备能力动态显示（颜色 / 场景 / 音乐 / DIY / 设置） -->
  <view class="sub-tabs" v-if="subTabs.length">
    <view v-for="(item, index) in subTabs" :class="'sub-tab ' + (subKey === item.key ? 'active' : '')" :data-key="(item.key)" @tap="switchSubTab" :key="item.key">{{item.name}}</view>
  </view>

  <!-- 无可用子功能 -->
  <view v-if="!subTabs.length" class="placeholder-box">
    <text class="ph-text">该设备无可用的灯光功能</text>
  </view>

  <!-- ===== 颜色子页（hidden 保持 canvas 常驻 DOM）===== -->
  <view v-show="!(subKey !== 'color')">
    <!-- 色温 / 彩色 二级 Tab -->
    <view class="color-tabs">
      <view v-for="(item, index) in colorTabs" :class="'color-tab ' + (currentColorTab === index ? 'active' : '')" :data-index="(index)" @tap="switchColorTab" :key="item.name">{{item.name}}</view>
    </view>

    <!-- 色温（hidden 而非 wx:if）-->
    <view v-show="!(currentColorTab !== 0)">
      <view class="ct-section">
        <view class="ct-row-head">
          <text class="label">色温</text>
          <text class="ct-val">{{warmCool}}%</text>
        </view>
        <view class="ct-bar-wrap">
          <view class="ct-bar">
            <view class="ct-warm"></view>
            <view class="ct-cold"></view>
          </view>
          <slider min="0" max="100" :value="(warmCool)" activeColor="transparent" backgroundColor="transparent" block-size="36" block-color="#fff" @changing="onWarmCoolChanging" @change="onWarmCool" class="ct-slider" />
        </view>
      </view>

      <!-- 预设色温（固定档位，仅色温页显示，与彩色页「常用颜色」独立） -->
      <view class="warm-presets">
        <text class="rc-label">预设色温</text>
        <view class="wp-grid">
          <view v-for="(item, index) in warmPresets" :class="'wp-item ' + (warmCool === item.v ? 'active' : '')" :data-v="(item.v)" @tap="onWarmPresetTap" :key="item.name">
            <view class="wp-dot" :style="'background:' + (item.c) + ';'"></view>
            <text class="wp-name">{{item.name}}</text>
          </view>
        </view>
      </view>
    </view>

    <!-- 彩色：色相环（hidden 而非 wx:if，canvas 永驻 DOM）-->
    <view v-show="!(currentColorTab !== 1)">
      <view class="wheel-wrap">
        <!-- 首选：CSS conic-gradient 色环，由合成器绘制，边缘与渐变完全平滑且零 JS 开销 -->
        <view v-if="wheelCss" class="wheel-fallback" :style="wheelStyle"></view>
        <!-- 兜底：不支持 conic-gradient 时才用 canvas 绘制（绘制完成前先显示粗略占位） -->
        <view v-else-if="!wheelReady" class="wheel-fallback"></view>
        <!-- 同时给 id（canvas 2d 用）与 canvas-id（老式 createCanvasContext 兜底用）：
             App 端部分 WebView 拿不到 2d node，会自动降级到老式接口绘制。
             CSS 色环模式下 canvas 保持透明，仅用于接收触摸事件 -->
        <canvas type="2d" id="colorWheel" canvas-id="colorWheel" class="color-wheel" @touchstart="onTouchStart" @touchmove="onTouchMove" @touchend="onTouchEnd"></canvas>
        <view class="thumb" :style="'left:' + (thumbX) + 'px;top:' + (thumbY) + 'px;'"></view>
      </view>

      <!-- 当前颜色信息 -->
      <view class="color-info">
        <view class="preview-swatch" :style="'background:#' + (currentColorHex) + ';'"></view>
        <view class="color-text">
          <text class="color-label">当前颜色</text>
          <text class="color-hex">#{{currentColorHex}}</text>
        </view>
        <view class="rgb-badges">
          <view class="rgb-badge r"><text>R</text><text>{{rgbR}}</text></view>
          <view class="rgb-badge g"><text>G</text><text>{{rgbG}}</text></view>
          <view class="rgb-badge b"><text>B</text><text>{{rgbB}}</text></view>
        </view>
      </view>

      <!-- RGB 微调（非灯带类显示） -->
      <view v-if="!isStrip" class="rgb-tweak">
        <view class="tweak-row"><text class="tw-lbl">R</text><slider min="0" max="255" :value="(rgbR)" block-size="22" block-color="#ff6b6b" activeColor="#ff6b6b" backgroundColor="rgba(255,107,107,.15)" @changing="onTweakR" @change="onTweakDone" /></view>
        <view class="tweak-row"><text class="tw-lbl">G</text><slider min="0" max="255" :value="(rgbG)" block-size="22" block-color="#51cf66" activeColor="#51cf66" backgroundColor="rgba(81,207,102,.15)" @changing="onTweakG" @change="onTweakDone" /></view>
        <view class="tweak-row"><text class="tw-lbl">B</text><slider min="0" max="255" :value="(rgbB)" block-size="22" block-color="#339af0" activeColor="#339af0" backgroundColor="rgba(51,154,240,.15)" @changing="onTweakB" @change="onTweakDone" /></view>
      </view>

      <!-- 常用颜色（仅彩色页；色温页用的是「预设色温」，两者不共用） -->
      <view class="recent-colors">
        <text class="rc-label">常用颜色</text>
        <view class="rc-swatches">
          <view v-for="(item, index) in recentColors" :class="'rc-swatch ' + (item ? '' : 'empty')" :style="(item ? 'background:#' + item : '')" :data-color="(item)" @tap.stop="onRecentColorTap" :key="index"></view>
        </view>
      </view>
    </view>
  </view>

  <!-- ===== 场景子页 ===== -->
  <view v-show="!(subKey !== 'scene')">
    <!-- 场景分类 Tab -->
    <view class="scene-cats">
      <!-- 注意：Vue3 中 v-if 优先级高于 v-for，不能再写在同一个元素上（且会报 item 未定义） -->
      <template v-for="(item, index) in sceneCats" :key="item.name">
        <view v-if="!item.hidden" :class="'scene-cat ' + (currentSceneCat === index ? 'active' : '')" :data-index="(index)" @tap="switchSceneCat">{{item.name}}</view>
      </template>
    </view>

    <!-- 场景列表：grid=true 的分类走封面网格（精典 1~10），其余保持列表风格（常规 11~61 / 所有 1~61） -->
    <scroll-view scroll-y class="scene-list">
      <!-- 封面网格风格 -->
      <view class="scene-grid" v-if="sceneCats[currentSceneCat].grid">
        <view v-for="(item, index) in sceneCats[currentSceneCat].scenes" :class="'scene-card ' + (selectedScene === item.id ? 'active' : '')" :data-id="(item.id)" @tap="onSceneTap" :key="item.id">
          <view class="scene-cover" :style="'background:linear-gradient(135deg,' + (item.c[0] || '#6c5ce7') + ',' + (item.c[1] || '#a855f7') + ');'">
            <image v-if="item.img" class="scene-img" :src="(item.img)" mode="aspectFill" />
            <text v-else class="scene-cover-icon">{{item.icon}}</text>
          </view>
          <text class="scene-card-name">{{item.name}}</text>
        </view>
      </view>

      <!-- 列表风格 -->
      <block v-else>
        <view v-for="(item, index) in sceneCats[currentSceneCat].scenes" :class="'scene-item ' + (selectedScene === item.id ? 'active' : '')" :data-id="(item.id)" @tap="onSceneTap" :key="item.id">
          <image v-if="item.img" class="scene-thumb" :src="(item.img)" mode="aspectFill" />
          <view v-else class="scene-icon">{{item.id}}</view>
          <text class="scene-name">{{item.name}}</text>
        </view>
      </block>
    </scroll-view>
  </view>

  <!-- ===== 音乐子页 ===== -->
  <view v-show="!(subKey !== 'music')">
    <!-- 拾音器灵敏度：滑动松手即生效（采集增益 + 下发 0x08） -->
    <view class="section">
      <view class="row brightness-row">
        <text class="label">拾音灵敏度</text>
        <slider class="bright-slider" min="0" max="100" :value="(musicMic)" activeColor="#a855f7" backgroundColor="rgba(168,85,247,.18)" block-size="28" block-color="#a855f7" @changing="onMusicMic" @change="onMusicMicChange" />
        <text class="bright-pct">{{musicMic}}</text>
      </view>
    </view>

    <!-- 手机麦克风律动：采集环境声 → 实时驱动灯光 -->
    <text class="music-title">手机麦克风律动</text>
    <view class="section">
      <view :class="'apply-btn ' + (micRunning ? 'btn-stop' : '')" @tap="toggleMic">
        {{micRunning ? '停止律动' : '开始律动（手机麦克风）'}}
      </view>

      <!-- 实时电平条 -->
      <view class="mic-meter">
        <view class="mic-fill" :style="'width:' + (micLevel) + '%'"></view>
      </view>
      <view class="mic-level-text">音量 {{micLevel}}%（手机采的音只作为电平送给设备，画面由设备按节拍渲染）</view>
      <view class="mic-tip mic-live" v-if="micStatus">采集状态：{{micStatus}}<block v-if="micFrames"> · 已收 {{micFrames}} 帧</block></view>
    </view>

    <!-- 律动模式（三列网格，点击切换并自动开始） -->
    <text class="music-title">律动模式</text>
    <view class="music-grid">
      <view v-for="(item, index) in micModes" :class="'music-item ' + (micMode === item.key ? 'active' : '')" :data-key="(item.key)" @tap="pickMicMode" :key="item.key">
        <image v-if="item.img" class="music-thumb" :src="(item.img)" mode="aspectFill" />
        <view v-else class="music-icon">{{item.icon}}</view>
        <text class="music-name">{{item.name}}</text>
      </view>
    </view>

    <!-- 当前模式说明 -->
    <view class="mic-tip">当前：{{micDesc}}</view>
    <view class="mic-tip">对着手机播放音乐或说话，灯光会随音量与节拍变化；上方灵敏度滑块同时作为采集增益。律动算法在设备端运行（AGC 自动量程 + 节拍检测 + 逐颗灯珠渲染），手机断开后设备会用自带麦克风继续律动。</view>
  </view>

  <!-- ===== DIY 子页：灯珠编辑器 ===== -->
  <view v-show="!(subKey !== 'diy')">
    <!-- 类型 Tab：静态(左) / 动态(右) -->
    <view class="diy-cats">
      <view :class="'diy-cat ' + (diyTab === 1 ? 'active' : '')" @tap="onDiyTabStatic">静态模式</view>
      <view :class="'diy-cat ' + (diyTab === 0 ? 'active' : '')" @tap="onDiyTabDyn">动态模式</view>
    </view>

    <!-- 动态参数（仅动态 Tab） -->
    <view class="set-group" v-if="diyTab === 0">
      <view class="set-item">
        <text class="set-label">动态方式</text>
        <picker mode="selector" :range="(dynModeNames)" :value="(dynMode)" @change="onDynModeChange">
          <view class="set-picker">
            <text class="set-value">{{dynModeNames[dynMode]}}</text>
            <text class="set-arrow">›</text>
          </view>
        </picker>
      </view>
      <view class="set-item">
        <text class="set-label">方向</text>
        <picker mode="selector" :range="(dynDirNames)" :value="(dynDir)" @change="onDynDirChange">
          <view class="set-picker">
            <text class="set-value">{{dynDirNames[dynDir]}}</text>
            <text class="set-arrow">›</text>
          </view>
        </picker>
      </view>
      <view class="set-item">
        <text class="set-label">间隔(拍)</text>
        <input class="set-input" type="number" :value="(dynInterval)" @blur="onDynInterval" />
      </view>
      <view class="set-item">
        <text class="set-label">拖尾(点数)</text>
        <input class="set-input" type="number" :value="(dynTrail)" @blur="onDynTrail" />
      </view>
      <view class="set-item">
        <text class="set-label">过渡(%)</text>
        <input class="set-input" type="number" :value="(dynTrans)" @blur="onDynTrans" />
      </view>
      <view class="mic-tip" style="padding:0 28rpx 20rpx;">过渡：每次节拍切换的柔化程度。0 = 直接跳变（节拍最硬），数值越大，新旧画面交叠渐变的时间越长，切换越顺滑。</view>
    </view>

    <!-- 灯珠网格 -->
    <view class="set-group">
      <view class="set-item" style="border-bottom:none;">
        <text class="set-label">灯珠颜色</text>
        <text class="set-value">共 {{diyColors.length}} 颗</text>
      </view>
      <!-- 灯珠网格：每 20 颗/组，行首为组选择按钮（可多选）；组内灯珠支持横向拖动 -->
      <view class="diy-groups">
        <view v-for="(item, index) in diyRows" class="diy-row" :key="item.gi">
          <view :class="'grp-btn ' + (item.sel ? 'on' : '')" :data-g="(item.gi)" @tap="onGroupSel">
            <text class="grp-t">组{{item.gi + 1}}</text>
            <text class="grp-n">{{item.start}}-{{item.end}}</text>
          </view>
          <view class="grp-leds">
            <view v-for="(led, index) in item.leds" :class="'diy-led sm ' + (diySel === led.i ? 'sel' : '') + ' ' + (item.sel ? 'grp-on' : '')" :style="'background:' + (led.c)" :data-i="(led.i)" @tap="onDiyLedTap" :key="led.i"></view>
          </view>
        </view>
      </view>

      <view class="mic-tip" style="padding:6rpx 8rpx 0;">每组 20 颗（10×2 排列，一屏显示全）；点行首「组N」可多选整组。</view>

      <!-- 当前选择 + 色板 -->
      <view class="diy-cur">
        <text class="muted2">{{selGroupText || ('当前灯珠 #' + (diySel + 1))}}</text>
        <view class="diy-cur-color" :style="'background:' + (brush)"></view>
      </view>
      <view class="palette">
        <view v-for="(item, index) in palette" class="pal" :style="'background:' + (item)" :data-c="(item)" @tap="onPaletteTap" :key="index"></view>
      </view>

      <!-- 一键填充预设 -->
      <view class="preset-grid">
        <view v-for="(item, index) in fillPresets" class="preset-btn" :data-k="(item.key)" @tap="fillPreset" :key="item.key">{{item.name}}</view>
      </view>
      <view class="mic-tip" style="padding:8rpx;">「纯色填充」「全部熄灭」作用于全部灯珠；其余填充按当前选中范围（单颗或已选组）。</view>
    </view>

    <!-- 应用 / 保存 -->
    <view class="apply-btn" @tap="applyDiy">{{diyTab === 0 ? '应用动态到设备' : '应用静态到设备'}}</view>
    <view class="qbtn save" @tap="saveDiyCustom">保存到自定义{{diyTab === 0 ? '动态' : '静态'}}模式列表</view>

    <!-- 自定义模式列表 -->
    <view class="set-group custom-list">
      <view v-for="(item, index) in diyTab === 0 ? customDyn : customStatic" class="set-item" :key="index">
        <!-- data-dyn 必须是"是否动态页"的布尔量(1=动态/0=静态)，不能直接传 diyTab：
             diyTab 的取值是 0=动态、1=静态，与 handler 里的 isDyn 语义正好相反 -->
        <text class="set-label" :data-i="(index)" :data-dyn="(diyTab === 0 ? 1 : 0)" @tap="loadDiyCustom">#{{item.id || (index + 1)}} {{item.name}}</text>
        <text class="set-btn log-btn-danger" :data-i="(index)" :data-dyn="(diyTab === 0 ? 1 : 0)" :data-name="(item.name)" @tap.stop="removeDiyCustom">删除</text>
      </view>
      <view v-if="(diyTab === 0 ? customDyn.length : customStatic.length) === 0" class="mic-tip" style="padding:20rpx 28rpx;">
        暂无自定义{{diyTab === 0 ? '动态' : '静态'}}模式，编辑后点上方「保存」
      </view>
    </view>
    <view class="mic-tip">说明：点灯珠选中 → 在色板上取色 → 「应用」按 0x09 分批下发到设备；一个编辑点对应一颗 SM1191 IC，动态方式由固件逐帧渲染。流水按原色逐颗推进（不再整条熄灭），彗星头部固定为金色。切换静态色/预设模式会退出 DIY。「从设备读取」需固件提供回读指令，暂未开放。</view>
  </view>

  <!-- ===== 设置子页 ===== -->
  <block v-if="subKey === 'setting'">
    <view class="set-group">
      <!-- 设备名编辑 -->
      <view class="set-item" @tap="onEditNameTap">
        <text class="set-label">设备名称</text>
        <text class="set-value">{{deviceName || '未命名设备'}}</text>
        <text class="set-arrow">›</text>
      </view>

      <!-- 灯珠数（IC 数） -->
      <view class="set-item" @tap="onEditLed">
        <text class="set-label">IC 数（灯珠数量）</text>
        <text class="set-value">{{ledCount}}</text>
        <text class="set-arrow">›</text>
      </view>

      <!-- RGB 线序：picker 作为 set-item 的 flex 子项靠右（picker 元素不吃外层 class 的 flex，
           所以不能把 set-item 挂在 picker 上 —— 那样 label 和值会各占一行） -->
      <view class="set-item">
        <text class="set-label">灯珠 RGB 线序</text>
        <picker mode="selector" :range="(lineOrderNames)" :value="(lineOrderIndex)" @change="onLineOrderChange">
          <view class="set-picker">
            <text class="set-value">{{lineOrderNames[lineOrderIndex]}}</text>
            <text class="set-arrow">›</text>
          </view>
        </picker>
      </view>

      <!-- 灯珠驱动方案：与线序同一布局（暂为 UI 占位，不下发指令） -->
      <view class="set-item">
        <text class="set-label">灯珠驱动方案</text>
        <picker mode="selector" :range="(driverNames)" :value="(driverIndex)" @change="onDriverSchemeChange">
          <view class="set-picker">
            <text class="set-value">{{driverNames[driverIndex]}}</text>
            <text class="set-arrow">›</text>
          </view>
        </picker>
      </view>
    </view>

    <view class="set-group">
      <!-- 设备信息（只读） -->
      <view class="set-item">
        <text class="set-label">设备类型</text>
        <text class="set-value">{{typeName}}</text>
      </view>
      <view class="set-item">
        <text class="set-label">类型编号</text>
        <text class="set-value">0x{{typeHex}}</text>
      </view>
      <view class="set-item">
        <text class="set-label">所属系列</text>
        <text class="set-value">{{seriesName}}</text>
      </view>

      <!-- 软件版本 -->
      <view class="set-item">
        <text class="set-label">软件版本</text>
        <text class="set-value">{{firmware || '未读取'}}</text>
        <text class="set-btn" @tap.stop="onReadFirmware">读取</text>
      </view>
      <!-- 页面小字提示开关（默认关闭，保持界面清爽）；样式与顶栏设备开关一致，靠右对齐 -->
      <view class="set-item" @tap="onToggleTips">
        <text class="set-label">显示页面提示文字</text>
        <view :class="'tip-switch ' + (showTips ? 'on' : '')">
          <view class="tip-knob"></view>
        </view>
      </view>
    </view>
  </block>

</view>
</template>

<script>
import protocol from '@/utils/protocol';
import deviceType from '@/utils/deviceType';
import sceneModes from '@/utils/sceneModes';
import { ensureAudioPermission, openAppPermissionSetting } from '@/utils/permission';

// #ifdef APP-PLUS
// App-Android 的 uni.getRecorderManager().onFrameRecorded 不提供实时 PCM 帧；
// 使用离线包注册的 AudioRecord 原生模块，仅回传 RMS 数值。
const nativeMic = uni.requireNativePlugin('LightMicRecorder');
// #endif

// 能量柱分批下发：每批灯珠数（1 + 4*3 = 13 字节数据 → 整帧 18 字节，单包可送达）
const POWER_CHUNK = 4;
// 能量柱单组灯珠数：灯板 120 颗 = 6 组 × 20 颗，小程序只下发一组（5 批），
// 由固件把该组数据镜像到 6 组，使整板同步显示 6 条能量柱
const POWER_LED_N = 20;
// 底光：静音时灯珠保留的最低亮度（0~1），避免整体全黑看不出效果
const POWER_FLOOR = 0.15;

// 子功能页定义：按设备能力 caps 决定是否渲染
const SUB_TAB_DEFS = [
  { key: 'color', name: '颜色', need: (c) => !!(c.color || c.warmCool) },
  { key: 'scene', name: '场景', need: (c) => !!c.mode },
  { key: 'music', name: '音乐', need: (c) => !!(c.music || c.mic) },
  { key: 'diy', name: 'DIY', need: (c) => !!c.diy },
  { key: 'setting', name: '设置', need: (c) => !!(c.timer || c.ledCount || c.syncTime) },
];

export default {
  props: {
    typeId: { type: Number, default: 1 },
    caps: { type: Object, default: () => ({}) },
    status: { type: Object, default: null },
    hidden: { type: Boolean, default: false },
    deviceName: { type: String, default: '' },   // 设备名（设置页展示）
    firmware: { type: String, default: '' },     // 软件版本（0x02 读取后由父页面回传）
    lineOrder: { type: Number, default: -1 },    // 设备当前线序（0xF4 查询后由父页面回传, -1=未知）
    // （预留）driverScheme 属性：驱动方案协议实现后再由父页面回传
  },

  data() {

    return {
    // 灯珠（出厂默认 8 颗 IC；设备连上后由状态帧回读覆盖为设备实际值）
    ledCount: 8,
    // 灯带/字母灯类（u16 亮度、HSV 颜色），由 typeId 观察项计算后回填（Vue 需预先声明）
    isStrip: false,

    // ===== 设置页 =====
    typeName: '未知设备',
    typeHex: '0000',
    seriesName: '-',
    // RGB 线序（CMD 0xF4 厂端指令）：0 RGB / 1 RBG / 2 GRB / 3 GBR / 4 BRG / 5 BGR
    //   出厂默认 GRB(2)，与固件 LEDC_MAP_DEFAULT 一致；进入设置页会下发 0xF4 查询回读后刷新
    lineOrderIndex: 2,
    lineOrderNames: ['RGB', 'RBG', 'GRB', 'GBR', 'BRG', 'BGR'],
    // 灯珠驱动方案（暂为 UI 占位，不下发指令）：0 WS281x / 1 SM1191，出厂默认 SM1191
    driverIndex: 1,
    driverNames: ['WS281x', 'SM1191'],

    // 亮度：彩色栏（整体/RGB 亮度 0x05）
    brightness: 100,
    brightnessPct: 100,
    // 亮度：色温栏（冷暖亮度 0x13/0x14，0~100），与彩色栏各自独立保存
    warmBrightness: 100,
    warmBrightnessPct: 100,
    // 顶部亮度滑块当前作用于哪一路：true=色温(冷暖亮度) false=彩色(整体亮度)
    brightIsWarm: false,
    // 动态模式速度：固件 0x0F 范围 1~100，与遥控器速度 +/- 共用当前值
    speed: 1,

    // 子 Tab：默认全量（caps 未就绪时保证功能可用），caps 到达后按能力过滤
    subTabs: SUB_TAB_DEFS.map((t) => ({ key: t.key, name: t.name })),
    subKey: 'color',

    // 颜色二级 Tab
    colorTabs: [{ name: '色温' }, { name: '彩色' }],
    currentColorTab: 1, // 默认彩色

    // 色温
    warmCool: 50,
    // 色温预设（固定档位；与「彩色」页的常用颜色相互独立，不共用）
    // v: 0=最暖 → 100=最冷；c: 面板展示用近似光色
    warmPresets: [
      { name: '暖黄', v: 0, c: '#ffb765' },
      { name: '暖白', v: 20, c: '#ffd0a0' },
      { name: '柔白', v: 40, c: '#ffe3c2' },
      { name: '自然白', v: 60, c: '#fff3e2' },
      { name: '正白', v: 80, c: '#eaf2ff' },
      { name: '冷白', v: 100, c: '#c9e2ff' },
    ],

    // 色相环：仅 UI 相关字段放 data（WXML 需要的）
    thumbX: 240,
    thumbY: 40,
    wheelReady: false,      // canvas 色环是否已完成首帧绘制（false 时显示 CSS 占位）
    wheelCss: false,        // 是否启用 CSS conic-gradient 色环（优先方案，边缘与渐变最平滑）
    wheelStyle: '',         // CSS 色环的 background 声明
    showTips: false,        // 页面说明性小字（默认关闭，可在设置页打开）
    currentColorHex: '7e61ff',
    rgbR: 126, rgbG: 97, rgbB: 255,
    // 常用颜色（最近操作的6个颜色）
    recentColors: ['', '', '', '', '', ''],

    // 场景分类：精典(1~10) / 常规(11~61) / 所有(全部 61)
    // 数据统一来自 utils/sceneModes.js，与首页群控/联动共用
    sceneCats: sceneModes.buildSceneCats(),
    // 默认落在「精典」（数组第 0 项，不再有隐藏分类，索引可直接对应）
    currentSceneCat: 0,
    selectedScene: null,

    // ===== DIY 灯珠编辑器 =====
    diyTab: 0,              // 0=动态模式 1=静态模式
    diyColors: [],          // 灯珠颜色（'#rrggbb'，长度=灯珠数）
    diyRows: [],            // 按 20 颗/组 分行（渲染用）
    diySel: 0,              // 当前选中灯珠索引
    selMode: 'group',       // 'led'=单颗  'group'=整组（可多选）；默认整组选中
    selGroups: [0],         // 已选中的组索引（多选）；默认选中第 1 组
    selGroupText: '',       // 选中组提示文案
    brush: '#ff0000',       // 当前画笔色（色卡选中色，快捷设定直接使用）
    lastPreset: '',         // 最近一次使用的快捷设定（改色卡时自动关联重算）
    // 一键填充预设
    fillPresets: [
      { key: 'fill', name: '纯色填充' },
      { key: 'rainbow', name: '彩虹渐变' },
      { key: 'gradient', name: '明暗渐变' },
      { key: 'alt', name: '隔颗交替' },
      { key: 'warmcool', name: '冷暖渐变' },
      { key: 'groupbow', name: '分组彩虹' },
      { key: 'mirror', name: '镜像对称' },
      { key: 'random', name: '随机彩色' },
      { key: 'off', name: '全部熄灭' },
    ],
    // 动态方式：0 无(静态呈现) 1 跑马(整体平移) 2 流水(逐颗推进) 3 呼吸(整体明暗)
    //           4 彗星(带头拖尾) 5 波浪(正弦推移) 6 闪烁(整体闪烁)
    dynMode: 1,
    dynDir: 0,              // 0 正向 1 反向
    dynInterval: 5,         // 间隔(拍)：默认 5
    dynTrail: 8,            // 拖尾(点数)：默认跟随灯珠数（整条一起做拖尾）
    dynTrans: 100,          // 过渡(%)：默认 100，切换最柔顺
    dynModeNames: ['无(静态呈现)', '跑马(整体平移)', '流水(原色推进)', '呼吸(整体明暗)', '彗星(金头拖尾)', '波浪(正弦推移)', '闪烁(整体闪烁)'],
    dynDirNames: ['正向', '反向'],
    palette: ['#ff0000', '#ff7a00', '#ffd400', '#00c853', '#00e5cc', '#00b0ff', '#3d5afe', '#a855f7', '#ff4d94', '#ffffff', '#9aa0a6', '#000000'],
    customDyn: [],          // 自定义动态模式（本地存储）
    customStatic: [],       // 自定义静态模式（本地存储）

    // 手机麦克风律动
    micRunning: false,      // 是否正在采集
    micLevel: 0,            // 实时音量 0~100（UI 电平条）
    micStatus: '',          // 采集状态提示（启动中/采集正常/失败原因）
    micFrames: 0,           // 已收到的音频帧计数（用于确认是否真的在采集）
    micMode: 'strobe',      // 当前律动模式
    micDesc: '节拍触发白光爆闪，瞬间拉满后骤降',
    // 六种律动模式（手机端算法，视觉差异明显）
    micModes: [
      { key: 'strobe', name: '爆闪', icon: '⚡', img: '/static/images/generated_scenes/thumb/f22.jpg', desc: '节拍触发白光爆闪，瞬间拉满后骤降' },
      { key: 'pulse', name: '脉冲', icon: '🌊', img: '/static/images/generated_scenes/thumb/f48.jpg', desc: '亮度随音量呼吸起伏，色彩缓慢流转' },
      { key: 'rainbow', name: '彩虹冲击', icon: '🌈', img: '/static/images/generated_scenes/thumb/f12.jpg', desc: '音量越大色相飞转越快，同时加速动态' },
      { key: 'power', name: '能量柱', icon: '🔋', img: '/static/images/generated_scenes/thumb/f29.jpg', desc: '灯板从左右两端向中间蓄能，蓄能量与音量等比，左右比例错开形成落差' },
      { key: 'heart', name: '心跳', icon: '❤️', img: '/static/images/generated_scenes/thumb/f19.jpg', desc: '模拟心跳“咚-咚”双击脉冲' },
      { key: 'bars', name: '能量分级', icon: '📊', img: '/static/images/generated_scenes/thumb/f06.jpg', desc: '音量分 5 档，颜色与亮度阶梯跳变' },
    ],

    // 音乐律动：拾音灵敏度 + 律动选择
    musicMic: 50,           // 拾音器灵敏度 0~100（滑动即生效：采集增益 + 0x08 下发）
    // 注意：ctx / buf* / css* 绘制参数不再放 data，改用实例属性 this._*
    // 原因：CanvasRenderingContext2D 跨 setData 桥序列化后会失效导致 _drawWheel() 静默跳过
  }

  },

  // ===== 生命周期（小程序 lifetimes → Vue）=====
  mounted() {
    // attached：读取常用颜色
    const saved = uni.getStorageSync('recentLightColors');
    if (Array.isArray(saved) && saved.length === 6) {
      this.setData({ recentColors: saved });
    }
    // 提示小字开关（未设置过默认关闭）
    try {
      const tips = uni.getStorageSync('lightPanelShowTips');
      if (tips !== '' && tips != null) this.setData({ showTips: !!tips });
    } catch (e) { /* ignore */ }
    // ready：优先用 CSS 色环（平滑、零开销），不支持时才走 canvas 绘制
    this.$nextTick(() => {
      if (this._setupWheelCss()) this._setupCssGeometry();
      else this._initCanvas();
    });
  },
  unmounted() {
    this._stopMic();
  },

  // ===== 观察者（小程序 observers → Vue watch）=====
  // 说明：WeChat 的 observers 在属性首次赋值时也会触发，Vue 的 watch 默认不会，
  //       故涉及初次渲染数据的观察项统一加 immediate: true；对象型 prop 加 deep: true
  watch: {
    lineOrder: { handler: '_onLineOrder', immediate: true },
    caps: { handler: '_onCaps', immediate: true },
    subKey: { handler: '_onSubKey' },
    currentColorTab: { handler: '_onColorTab' },
    typeId: { handler: '_onTypeId', immediate: true },
    status: { handler: '_onStatus', immediate: true, deep: true },
    ledCount: { handler: '_onLedCount', immediate: true },
  },

  methods: {
    // 页面显示/隐藏：小程序由 pageLifetimes 自动回调，uni-app 组件不支持该钩子，
    // 改由宿主页面（pages/device/device.vue）在 onShow/onHide 中显式转发
    onPageShow() {
      // 已有 ctx 时只补一次绘制（走缓存，毫秒级），避免重新初始化 canvas 造成长时间空白
      if (this._ctx) this._drawWheel();
      else this._initCanvas();
    },
    onPageHide() {
      this._stopMic();
    },

    // 顶部亮度滑块作用对象：颜色页→色温栏时作用于冷暖亮度，其余作用于整体/RGB 亮度
    _syncBrightTarget() {
      const warm = this.subKey === 'color' && Number(this.currentColorTab) === 0
        && !!(this.caps && this.caps.warmCool);
      if (warm !== this.brightIsWarm) this.setData({ brightIsWarm: warm });
    },

    // 设备回读的线序（父页面解析 0xF4 应答后回传）: 同步设置页 picker 显示
    _onLineOrder(v) {
      const idx = Number(v);
      if (idx >= 0 && idx < this.lineOrderNames.length && idx !== this.lineOrderIndex) {
        this.setData({ lineOrderIndex: idx });
      }
    },

    // 设备能力变化：过滤子功能页，并定位到第一个可用页
    // 注意：caps 未就绪（空对象）时保持现有子页不变，避免初始化竞态把功能页清空
    _onCaps(v) {
      const c = v || {};
      if (!Object.keys(c).length) return;
      const subTabs = SUB_TAB_DEFS.filter((t) => t.need(c)).map((t) => ({ key: t.key, name: t.name }));
      if (!subTabs.length) return;
      const patch = { subTabs };
      if (!subTabs.some((t) => t.key === this.subKey)) patch.subKey = subTabs[0].key;
      // 无彩色能力时默认落到色温页
      if (!c.color && c.warmCool) patch.currentColorTab = 0;
      this.setData(patch);
      this._syncBrightTarget();
    },

    // 切到「颜色」子页时确保色环已绘制（此前可能因 v-show 隐藏拿不到布局尺寸）
    _onSubKey(v) {
      this._syncBrightTarget();
      if (v === 'color') {
        setTimeout(() => {
          if (this._ctx) this._drawWheel();
          else this._initCanvas();
        }, 50);
      }
    },

    _onColorTab(v) {
      this._syncBrightTarget();
      if (v === 1) {
        // view 从隐藏变为可见，等一帧让布局稳定再重绘
        setTimeout(() => {
          if (this._ctx) this._drawWheel();
          else this._initCanvas();
        }, 50);
      }
    },

    _onTypeId(v) {
      const isStrip = deviceType.isHsvType(v);
      const meta = deviceType.getDeviceMeta(v);
      const id = meta.typeId != null ? meta.typeId : (v || 0);
      this.setData({
        isStrip,
        typeName: meta.name,
        typeHex: ('000' + id.toString(16)).slice(-4).toUpperCase(),
        seriesName: meta.series ? meta.series.name : '-',
      });
      if (isStrip) this.setData({ brightness: 500, brightnessPct: 50 });
      else this.setData({ brightness: 100, brightnessPct: 100 });
    },

    // 父页面同步设备状态：更新亮度、灯珠数等
    _onStatus(v) {
      if (!v) return;
      const patch = {};
      if (v.brightness != null) {
        // 通用状态结构下 RGB 亮度为 u16：灯带类 0~1000，其余默认 0~100；超 100 按 1000 量程
        const maxB = this.isStrip || v.brightness > 100 ? 1000 : 100;
        patch.brightness = v.brightness;
        patch.brightnessPct = Math.max(0, Math.min(100, Math.round((v.brightness / maxB) * 100)));
      }
      // 设备侧冷暖同步（遥控/按键改动后由父页面回传）：0~100
      if (v.warmCool != null) patch.warmCool = Math.round(v.warmCool);
      if (v.warmBrightness != null) {
        patch.warmBrightness = Math.round(v.warmBrightness);
        patch.warmBrightnessPct = Math.round(v.warmBrightness);
      }
      if (v.ledCount != null && v.ledCount > 0) patch.ledCount = v.ledCount;
      if (v.speed != null) patch.speed = Math.max(1, Math.min(100, Math.round(v.speed)));
      if (Object.keys(patch).length) this.setData(patch);
    },

    // 灯珠数变化时同步 DIY 编辑器长度
    _onLedCount(v) {
      // 设备没上报灯珠数（0/空）时保持当前值，不能退回 20 颗，否则 DIY 会按错误的灯珠数下发
      if (!(Number(v) > 0)) return;
      const n = Math.max(1, Math.min(120, Number(v)));
      const c = (this.diyColors || []).slice(0, n);
      while (c.length < n) c.push('#000000');
      const patch = { diyColors: c };
      // 拖尾跟随灯珠数（用户手动改过则保留手动值）
      if (this._dynTrailAuto !== false) patch.dynTrail = n;
      const text = this._groupText(this.selGroups, n);
      if (text !== this.selGroupText) patch.selGroupText = text;
      this.setData(patch);
      this._rebuildRows();
    },
    // silent=true：高频实时指令（律动），父页面不等响应、不提示失败
    _emit(func, data, silent) { this.$emit('cmd', { func, data, silent: !!silent }); },
    // 批量帧：每一帧都是有效数据（DIY 分批/分段数据），必须全部按序下发，不能被"只保留最新帧"合并
    _emitBurst(frames) { this.$emit('cmd', { frames: frames || [], burst: true }); },

    // ====== CSS 色环（首选渲染方式）======
    // 用 conic-gradient 画色相、radial-gradient 叠加白色实现饱和度，
    // 由系统合成器渲染：边缘抗锯齿、渐变连续，且没有逐像素/逐弧段的 JS 开销。
    _setupWheelCss() {
      // 注意：App-Plus 的逻辑层（V8）没有 document，不能用 DOM 探测 CSS 能力，
      // 否则会误判成"不支持"→ 退回 canvas 弧段绘制 → 首屏平滑色环两秒后被粗色环覆盖。
      // 这里按系统版本判断：Android 8+ / iOS 12+ 的 WebView 均支持 conic-gradient。
      let ok = true;
      try {
        const info = uni.getSystemInfoSync() || {};
        const sys = String(info.system || info.platform || '');
        if (/iOS|iPadOS/i.test(sys)) ok = true;
        else {
          const m = sys.match(/Android\s+(\d+)/i);
          ok = m ? Number(m[1]) >= 8 : true;
        }
      } catch (e) { ok = true; }
      if (!ok) return false;

      // 36 段色相（每 10°），sRGB 线性插值后肉眼已无断层
      const N = 36;
      const stops = [];
      for (let i = 0; i <= N; i++) {
        const h = Math.round((i / N) * 360);
        stops.push('hsl(' + h + ',100%,50%) ' + ((i / N) * 100).toFixed(2) + '%');
      }
      // 白色叠加层在半径 71% 处收边（对应实际圆环半径 R），alpha 线性递减 → 等价 HSV 的饱和度
      // closest-side 让叠加层以画布半宽为基准，88% 处收边 ≈ 取色半径 R（四周留 16px 边距），
      // 保证可点击区域的边缘饱和度为满值，与取色算法一致
      const style = 'background:'
        + 'radial-gradient(circle closest-side at 50% 50%, #ffffff 0%, rgba(255,255,255,0.94) 4%, rgba(255,255,255,0) 88%),'
        + 'conic-gradient(from 90deg, ' + stops.join(',') + ');';
      this._wheelCssOn = true;
      this.setData({ wheelCss: true, wheelStyle: style, wheelReady: true });
      return true;
    },

    // CSS 模式下也要拿到圆心/半径用于触摸取色与 thumb 定位
    _setupCssGeometry() {
      const apply = (cssW) => {
        this._cssSize = cssW;
        this._cssCx = cssW / 2;
        this._cssCy = cssW / 2;
        // 取色半径必须等于可视半径：之前减 16px 会导致最外圈约 16px 的色环"看得到点不到"
        this._cssR = Math.max(1, cssW / 2 - 1);
        if (!this._inited) {
          this._placeThumb(270, 0.75);
          this._inited = true;
        }
      };
      try {
        uni.createSelectorQuery().in(this).select('.color-wheel').boundingClientRect((rect) => {
          if (rect && rect.width > 0) { apply(Math.round(rect.width)); return; }
          apply(this._fallbackCssWidth());
        }).exec();
      } catch (e) {
        apply(this._fallbackCssWidth());
      }
    },

    _fallbackCssWidth() {
      let winW = 375;
      try {
        winW = (uni.getWindowInfo ? uni.getWindowInfo().windowWidth
          : uni.getSystemInfoSync().windowWidth) || 375;
      } catch (e) { /* ignore */ }
      return Math.round(winW * 480 / 750);
    },

    // ====== canvas 初始化（ctx/绘制参数走实例属性，不走 setData 桥）======
    _initCanvas() {
      // 已启用 CSS 色环时无需初始化 canvas，仅补几何参数
      if (this._wheelCssOn) { this._setupCssGeometry(); return; }
      const that = this;

      // 老式接口兜底：uni.createCanvasContext（App 端拿不到 2d node 时走这条）
      const fallbackLegacy = () => {
        if (that._legacy && that._ctx) return true; // 已走老式通道，不重复初始化
        try {
          if (typeof uni.createCanvasContext !== 'function') return false;
          const ctx = uni.createCanvasContext('colorWheel', that);
          if (!ctx) return false;
          let winW = 375;
          try {
            winW = (uni.getWindowInfo ? uni.getWindowInfo().windowWidth
              : uni.getSystemInfoSync().windowWidth) || 375;
          } catch (e) { /* ignore */ }
          const cssW = Math.round(winW * 480 / 750); // 与 .color-wheel 的 480rpx 对齐
          that._ctx = ctx;
          that._legacy = true;          // 老式接口：坐标系 = CSS px
          that._cssSize = cssW;
          that._cssCx = cssW / 2;
          that._cssCy = cssW / 2;
          that._cssR = Math.max(1, cssW / 2 - 1);
          console.log('[light-panel] canvas 走老式接口兜底', { cssW });
          that._drawWheel();
          if (!that._inited) {
            that._placeThumb(270, 0.75);
            that._inited = true;
          }
          return true;
        } catch (e) {
          console.warn('[light-panel] 老式 canvas 接口也不可用', e);
          return false;
        }
      };

      // 兜底守卫：若 1.5s 内拿不到可用的 2d ctx，直接用老式接口重画
      // （App 端 createSelectorQuery 在 canvas 上可能不回调，导致"什么都不画"）
      if (that._initGuard) clearTimeout(that._initGuard);
      that._initGuard = setTimeout(() => {
        if (that._ctx) return;
        console.warn('[light-panel] canvas 初始化超时，强制走老式接口');
        fallbackLegacy();
      }, 1500);

      const start = (retryCount) => {
        try {
          uni.createSelectorQuery()
            .in(that)
            .select('#colorWheel')
            .fields({ node: true, size: true })
            .exec((res) => {
            if (!res[0] || !res[0].node) {
              // canvas 用 v-show 保持常驻 DOM，正常情况首次就能拿到；
              // App 端若始终拿不到 2d node，降级到老式 createCanvasContext
              if (retryCount < 5) {
                setTimeout(() => start(retryCount + 1), 50 + retryCount * 30);
              } else {
                console.warn('[light-panel] canvas 2d 节点获取失败，尝试老式接口');
                fallbackLegacy();
              }
              return;
            }

            const canvas = res[0].node;
            const dpr = (uni.getWindowInfo ? uni.getWindowInfo().pixelRatio
              : uni.getSystemInfoSync().pixelRatio) || 2;
            let winW = 375;
            try {
              winW = (uni.getWindowInfo ? uni.getWindowInfo().windowWidth
                : uni.getSystemInfoSync().windowWidth) || 375;
            } catch (e) { /* ignore */ }

            // 布局未算完时 width=0；用 rpx 兜底
            const cssW = (res[0].width > 0) ? Math.round(res[0].width)
              : Math.round(winW * 480 / 750);
            // 缓冲区上限 360px：色环是平滑渐变，更高分辨率肉眼无差别，
            // 但逐像素绘制量按平方增长（dpr=3 时 700²≈49 万像素，绘制要 1~2 秒）
            const rawBuf = Math.round(cssW * dpr);
            const bufW = Math.min(rawBuf, 360);
            const bufScale = rawBuf > 0 ? bufW / rawBuf : 1;

            // 每次都重设缓冲（隐藏后原生层会回收）
            canvas.width = bufW;
            canvas.height = bufW;

            // ctx 存实例属性，不走 data/setData！
            const ctx2d = canvas.getContext('2d');
            if (!ctx2d) {
              console.warn('[light-panel] getContext(2d) 返回空，改用老式接口');
              fallbackLegacy();
              return;
            }
            that._ctx = ctx2d;
            that._cssSize = cssW;
            that._cssCx = cssW / 2;
            that._cssCy = cssW / 2;
            that._cssR = Math.max(1, cssW / 2 - 1);
            that._bufSize = bufW;
            that._bufCx = bufW / 2;
            that._bufCy = bufW / 2;
            // 绘制半径同样贴满画布（1 像素收边，避免边缘锯齿/溢出）
            that._bufR = Math.max(1, bufW / 2 - Math.max(1, dpr * bufScale));

            console.log('[light-panel] canvas init ok', { cssW, bufW, dpr, retryCount });
            that._drawWheel();

            // 仅首次定位 thumb 到紫色
            if (!that._inited) {
              that._placeThumb(270, 0.75);
              that._inited = true;
            }
          });
        } catch (e) {
          // createSelectorQuery 在 canvas 上抛异常（部分 App WebView），直接降级
          console.warn('[light-panel] canvas 2d 初始化异常', e);
          fallbackLegacy();
        }
      };
      start(0);
    },

    // 供父页面在 Tab 切换后主动调用，确保色环重绘
    refresh() {
      if (this._ctx) this._drawWheel();
      else this._initCanvas();
    },

    // ====== 子 Tab ======
    switchSubTab(e) {
      const key = e.currentTarget.dataset.key;
      this.setData({ subKey: key });
      if (key === 'diy') this._loadCustomModes();
      if (key === 'setting') {
        // 回读设备当前线序: UI 初始显示的不是设备真实状态。
        //   查询帧不带数据段, 老固件不支持 0xF4 时会回 0xE2, 父页面对"查询"静默处理。
        //   （驱动方案暂未实现, 等 0xF9 落地后再一起回读）
        this._emit(protocol.CMD.LINE_ORDER, protocol.factory.lineOrderQuery());
      }
    },
    switchColorTab(e) { this.setData({ currentColorTab: Number(e.currentTarget.dataset.index) }); },
    switchSceneCat(e) { this.setData({ currentSceneCat: Number(e.currentTarget.dataset.index) }); },

    // DIY 类型 Tab（静态/动态）
    onDiyTabStatic() { this.setData({ diyTab: 1 }); this._loadCustomModes(); },
    onDiyTabDyn() { this.setData({ diyTab: 0 }); this._loadCustomModes(); },

    // ====== DIY 编辑器 ======
    _ensureDiyColors() {
      const n = Math.max(1, Math.min(120, this.ledCount || 8));
      let c = (this.diyColors || []).slice(0, n);
      while (c.length < n) c.push('#000000');
      const patch = {};
      if (c.length !== (this.diyColors || []).length) patch.diyColors = c;
      // 拖尾默认 = 当前灯珠数（整条一起拖）；用户手动改过之后不再覆盖
      if (this._dynTrailAuto !== false && this.dynTrail !== n) patch.dynTrail = n;
      // 组选择提示按实际灯珠数计算（默认选中第 1 组时不再固定显示 20 颗）
      const text = this._groupText(this.selGroups, n);
      if (text !== this.selGroupText) patch.selGroupText = text;
      if (Object.keys(patch).length) this.setData(patch);
      this._rebuildRows();
      return c;
    },

    // 组选择文案：按实际灯珠数统计选中颗数
    _groupText(groups, total) {
      if (!groups || !groups.length) return '';
      const n = total || (this.diyColors || []).length;
      let cnt = 0;
      groups.forEach((g) => { cnt += Math.max(0, Math.min(20, n - g * 20)); });
      return '已选 ' + groups.map((g) => '组' + (g + 1)).join('、') + '（' + cnt + ' 颗）';
    },

    // 按 20 颗/组 重建行数据（渲染用）
    _rebuildRows() {
      const colors = this.diyColors || [];
      const sel = this.selGroups || [];
      const rows = [];
      for (let s = 0; s < colors.length; s += 20) {
        const gi = rows.length;
        const leds = [];
        for (let i = s; i < Math.min(s + 20, colors.length); i++) leds.push({ i, c: colors[i] });
        rows.push({
          gi,
          name: '组' + (gi + 1),
          start: s + 1,
          end: Math.min(s + 20, colors.length),
          sel: sel.indexOf(gi) >= 0,
          leds,
        });
      }
      this.setData({ diyRows: rows });
    },

    // 组多选：单击选中，再次单击取消；全部取消后回到单颗模式
    onGroupSel(e) {
      const g = Number(e.currentTarget.dataset.g);
      const sel = (this.selGroups || []).slice();
      const at = sel.indexOf(g);
      if (at >= 0) sel.splice(at, 1);
      else sel.push(g);
      sel.sort((a, b) => a - b);
      const text = this._groupText(sel);
      this.setData({ selGroups: sel, selMode: sel.length ? 'group' : 'led', selGroupText: text });
      this._rebuildRows();
    },

    // 当前作用范围的灯珠索引数组（单颗→1 个；多选组→组内所有）
    _selIndexes() {
      const n = (this.diyColors || []).length;
      const sel = this.selGroups || [];
      if (this.selMode === 'group' && sel.length) {
        const idx = [];
        sel.forEach((g) => {
          const s = g * 20;
          const e = Math.min(s + 20, n) - 1;
          for (let i = s; i <= e; i++) idx.push(i);
        });
        return idx;
      }
      return [this.diySel];   // 单颗模式：只作用于当前灯珠
    },

    // 取颜色色相（0~359），用于分组彩虹等以色卡色相为基准的预设
    _rgb2hue(r, g, b) {
      const rr = r / 255; const gg = g / 255; const bb = b / 255;
      const mx = Math.max(rr, gg, bb);
      const mn = Math.min(rr, gg, bb);
      const d = mx - mn;
      if (d === 0) return 0;
      let h;
      if (mx === rr) h = ((gg - bb) / d) % 6;
      else if (mx === gg) h = (bb - rr) / d + 2;
      else h = (rr - gg) / d + 4;
      h *= 60;
      return h < 0 ? h + 360 : Math.round(h);
    },

    _rgb2hex(r, g, b) {
      return '#' + [r, g, b].map((v) => ('0' + Math.max(0, Math.min(255, Math.round(v))).toString(16)).slice(-2)).join('');
    },

    // 点单颗灯珠：切回单颗模式（取消组选中）
    onDiyLedTap(e) {
      this.setData({
        diySel: Number(e.currentTarget.dataset.i),
        selMode: 'led',
        selGroups: [],
        selGroupText: '',
      });
      this._rebuildRows();
    },

    // 色卡取色：设为当前画笔色
    //  - 若已用过快捷设定 → 用新颜色自动重跑该设定（改色卡即实时关联，无需再点）
    //  - 否则按当前选择范围（单颗 / 已选组）直接上色
    onPaletteTap(e) {
      const color = e.currentTarget.dataset.c;
      this.setData({ brush: color });
      if (this.lastPreset) {
        this.fillPreset({ currentTarget: { dataset: { k: this.lastPreset } } });
        return;
      }
      const idx = this._selIndexes();
      const c = this.diyColors.slice();
      idx.forEach((i) => { c[i] = color; });
      this.setData({ diyColors: c });
      this._rebuildRows();
    },

    // ====== 一键填充预设 ======
    fillPreset(e) {
      const key = e.currentTarget.dataset.k;
      // 「纯色填充」「全部熄灭」不受选择限制，直接作用于全部灯珠
      const forceAll = (key === 'fill' || key === 'off');
      const idx = forceAll
        ? (this.diyColors || []).map((x, i) => i)
        : this._selIndexes();
      const n = idx.length;
      const c = this.diyColors.slice();
      const cur = this.brush || c[this.diySel] || '#ff0000'; // 快捷设定直接使用画笔色
      const curRgb = this._hex2rgb(cur);
      for (let k = 0; k < n; k++) {
        const i = idx[k];
        let hex = '#000000';
        switch (key) {
          case 'fill':
            hex = cur;
            break;
          case 'rainbow': {
            const [r, g, b] = this._hsv2rgb(Math.round((k / n) * 300), 1, 1);
            hex = this._rgb2hex(r, g, b);
            break;
          }
          case 'gradient': {
            // 当前色由暗到亮（明度 0.08 → 1）
            const v = 0.08 + (k / Math.max(1, n - 1)) * 0.92;
            hex = this._rgb2hex(curRgb.r * v, curRgb.g * v, curRgb.b * v);
            break;
          }
          case 'alt':
            hex = (k % 2 === 0) ? cur : '#000000';
            break;
          case 'warmcool': {
            // 以画笔色为基调：暖端(混暖白) → 冷端(混冷白)
            const t = k / Math.max(1, n - 1);
            const mixv = (a, b, w) => a + (b - a) * w;
            const wr = mixv(curRgb.r, 255, 0.7);
            const wg = mixv(curRgb.g, 180, 0.7);
            const wb = mixv(curRgb.b, 90, 0.7);
            const cr = mixv(curRgb.r, 180, 0.7);
            const cg = mixv(curRgb.g, 225, 0.7);
            const cb = mixv(curRgb.b, 255, 0.7);
            hex = this._rgb2hex(wr + (cr - wr) * t, wg + (cg - wg) * t, wb + (cb - wb) * t);
            break;
          }
          case 'groupbow': {
            // 以画笔色相为起点，每 20 颗一组递增 55°
            const baseHue = this._rgb2hue(curRgb.r, curRgb.g, curRgb.b);
            const hue = (baseHue + Math.floor(i / 20) * 55) % 360;
            const [r, g, b] = this._hsv2rgb(hue, 1, 1);
            hex = this._rgb2hex(r, g, b);
            break;
          }
          case 'mirror': {
            // 前半段：画笔色由暗到亮；后半段镜像，形成对称山峰
            const half = Math.max(1, Math.ceil(n / 2));
            const src = k < half ? k : (n - 1 - k);
            const t = half > 1 ? (src / (half - 1)) : 0;
            const v = 0.1 + t * 0.9;
            hex = this._rgb2hex(curRgb.r * v, curRgb.g * v, curRgb.b * v);
            break;
          }
          case 'random': {
            const [r, g, b] = this._hsv2rgb(Math.floor(Math.random() * 360), 1, 1);
            hex = this._rgb2hex(r, g, b);
            break;
          }
          case 'off':
          default:
            hex = '#000000';
            break;
        }
        c[i] = hex;
      }
      this.setData({ diyColors: c, lastPreset: key }); // 记录本次设定，改色卡时自动关联
      this._rebuildRows();
      uni.showToast({ title: '已填充', icon: 'none' });
    },

    onDiyFillAll() { this.fillPreset({ currentTarget: { dataset: { k: 'fill' } } }); },
    onDiyRainbow() { this.fillPreset({ currentTarget: { dataset: { k: 'rainbow' } } }); },
    onDiyAllOff() { this.fillPreset({ currentTarget: { dataset: { k: 'off' } } }); },

    onDynModeChange(e) { this.setData({ dynMode: Number(e.detail.value) }); },
    onDynDirChange(e) { this.setData({ dynDir: Number(e.detail.value) }); },
    onDynInterval(e) { this.setData({ dynInterval: Math.max(1, Number(e.detail.value) || 5) }); },
    // 拖尾：用户手动输入后标记为"非自动"，不再随灯珠数变化覆盖
    onDynTrail(e) {
      this._dynTrailAuto = false;
      this.setData({ dynTrail: Math.max(0, Number(e.detail.value) || 0) });
    },
    // 过渡：0~100(%)，控制每拍切换的柔和程度（0=硬切，越大交叉渐变越长）
    onDynTrans(e) {
      const v = Number(e.detail.value) || 0;
      this.setData({ dynTrans: Math.min(100, Math.max(0, v)) });
    },

    _hex2rgb(hex) {
      const h = (hex || '#000000').replace('#', '');
      return {
        r: parseInt(h.slice(0, 2), 16) || 0,
        g: parseInt(h.slice(2, 4), 16) || 0,
        b: parseInt(h.slice(4, 6), 16) || 0,
      };
    },

    // 应用到设备：DIY 颜色与动态参数统一走 0x09，由固件写进自己的编辑点缓冲并渲染到各 IC
    //   静态(diyTab=1) → mode=0（各点显示自己被编辑的颜色）
    //   动态(diyTab=0) → 界面选的方式/方向/间隔/拖尾/过渡，由固件在各灯珠上做逐点动画
    //   单包净荷只有 14 字节：首批 = startIndex + 5 参数 + 2 颗；其余批 = startIndex + 4 颗
    applyDiy() {
      this._ensureDiyColors();
      const isDyn = this.diyTab === 0;
      const rgb = this.diyColors.map((h) => this._hex2rgb(h));
      const dyn = isDyn
        ? {
          mode: this.dynMode, dir: this.dynDir,
          interval: this.dynInterval, trail: this.dynTrail,
          trans: this.dynTrans,
        }
        : { mode: 0, dir: 0, interval: 1, trail: 0, trans: 0 };
      const frames = [];
      let base = 0;
      while (base < rgb.length) {
        // 首批额外携带 5 个动态参数(1+5+3×2=12 字节)，故只放得下 2 颗；之后每批 4 颗
        const n = (base === 0) ? 2 : 4;
        frames.push({
          func: protocol.CMD.DIY,
          data: protocol.light.diyBatch(base, rgb.slice(base, base + n), dyn),
        });
        base += n;
      }
      // 整批交给 BLE 层按序发送：8 灯 = 3 帧(2+4+2)，缺任意一帧就会有灯珠不亮
      this._emitBurst(frames);
      uni.showToast({ title: '已应用到设备', icon: 'none' });
    },

    // ====== 自定义模式（本地存储）======
    _loadCustomModes() {
      this.setData({
        customDyn: uni.getStorageSync('customDynModes') || [],
        customStatic: uni.getStorageSync('customStaticModes') || [],
        lastPreset: '',   // 载入自定义模式后取消关联，避免下次点色卡误改
      });
      this._ensureDiyColors();
    },

    saveDiyCustom() {
      this._ensureDiyColors();
      const isDyn = this.diyTab === 0;
      const key = isDyn ? 'customDynModes' : 'customStaticModes';
      const seqKey = isDyn ? 'customDynSeq' : 'customStaticSeq';
      const list = uni.getStorageSync(key) || [];
      const that = this;
      // 模式 ID：独立自增序列，从 1 开始；删除已有效果也不会复用旧 ID
      const seq = (uni.getStorageSync(seqKey) || 0) + 1;
      uni.showModal({
        title: '保存为自定义模式',
        editable: true,
        placeholderText: '输入模式名称',
        confirmColor: '#a855f7',
        success(res) {
          if (!res.confirm) return;   // 取消则不占用序号
          const name = (res.content || '').trim() || ('自定义' + seq);
          const item = isDyn
            ? { id: seq, name, colors: that.diyColors.slice(), mode: that.dynMode, dir: that.dynDir, interval: that.dynInterval, trail: that.dynTrail, trans: that.dynTrans }
            : { id: seq, name, colors: that.diyColors.slice() };
          list.push(item);
          uni.setStorageSync(key, list);
          uni.setStorageSync(seqKey, seq);   // 确认后才落盘自增，避免取消产生空号
          that.setData(isDyn ? { customDyn: list } : { customStatic: list });
          uni.showToast({ title: '已保存 #' + seq, icon: 'success' });
        },
      });
    },

    // 载入自定义模式：isDyn 同样取自 WXML 的 data-dyn（1=动态页，与 diyTab 取值相反）
    loadDiyCustom(e) {
      const isDyn = e.currentTarget.dataset.dyn === 1 || e.currentTarget.dataset.dyn === '1';
      const i = Number(e.currentTarget.dataset.i);
      const list = isDyn ? this.customDyn : this.customStatic;
      const item = list[i];
      if (!item) return;
      this.setData({
        diyColors: (item.colors || []).slice(),
        diySel: 0,
        ...(isDyn ? {
          dynMode: item.mode || 0, dynDir: item.dir || 0,
          dynInterval: item.interval || 5,
          dynTrail: (item.trail === undefined || item.trail === null) ? (this.ledCount || 8) : item.trail,
          // 老版本存的自定义模式没有 trans 字段 → 兜底成界面默认值 100
          dynTrans: (item.trans === undefined) ? 100 : item.trans,
        } : {}),
      });
      this.applyDiy();
    },

    // 删除自定义模式：优先按 id 精确删除（列表刷新期间下标会错位，按下标可能删错项），
    //   删除前二次确认；先落盘再 setData，保证界面与 storage 一致。
    //   注意 isDyn 来自 WXML 的 data-dyn（1=动态页），不要直接传 diyTab（0 才是动态）。
    removeDiyCustom(e) {
      const d = e.currentTarget.dataset;
      const isDyn = d.dyn === 1 || d.dyn === '1';
      const i = Number(d.i);
      const key = isDyn ? 'customDynModes' : 'customStaticModes';
      const list = uni.getStorageSync(key) || [];
      const item = list[i];
      if (!item) { this._loadCustomModes(); return; }
      const that = this;
      uni.showModal({
        title: '删除自定义模式',
        content: `确定删除「${item.name || ('#' + (item.id || (i + 1)))}」？`,
        confirmText: '删除',
        confirmColor: '#ef4444',
        success(res) {
          if (!res.confirm) return;
          // 老数据没有 id 字段时退回按下标删除，避免 id 全为 undefined 时误删整列
          const next = (item.id === undefined)
            ? list.filter((x, xi) => xi !== i)
            : list.filter((x) => x.id !== item.id);
          uni.setStorageSync(key, next);
          that.setData(isDyn ? { customDyn: next } : { customStatic: next });
          uni.showToast({ title: '已删除', icon: 'none' });
        },
      });
    },

    // ====== 场景 ======
    onSceneTap(e) {
      const id = Number(e.currentTarget.dataset.id);
      this.setData({ selectedScene: id });
      this._emit(protocol.CMD.MODE, protocol.light.mode(this.typeId, id));
    },

    // ====== 音乐律动 ======
    // 拾音器灵敏度：滑动中仅更新本地显示（同时作为采集增益）
    onMusicMic(e) {
      this.setData({ musicMic: e.detail.value });
    },
    // 松手即生效：下发拾音灵敏度 CMD.MIC(0x08)
    onMusicMicChange(e) {
      const v = e.detail.value;
      this.setData({ musicMic: v });
      this._emit(protocol.CMD.MIC, protocol.light.mic(v));
    },

    // ====== 手机麦克风律动 ======
    // 点律动按钮：切换模式；若尚未开始采集则自动开始
    //   模式号要下发到固件(0x07): 六种律动方式现在由固件逐颗 IC 渲染, 手机只负责喂音量。
    //   编号与固件 device_mic_chioce_mode 一致 —— 顺序必须等于 micModes 的数组顺序。
    pickMicMode(e) {
      const key = e.currentTarget.dataset.key;
      const m = (this.micModes || []).find((x) => x.key === key);
      const idx = (this.micModes || []).findIndex((x) => x.key === key);
      this.setData({ micMode: key, micDesc: m ? m.desc : '' });
      if (idx >= 0) {
        this._emit(protocol.CMD.MUSIC, protocol.light.music(idx + 1));
      }
      // 注意: 不再在能量柱模式发 0x04 分段 —— 固件 case 0x04 会把 rgb_state 置 0,
      //   等于把律动踢出去; 能量柱本身就由固件渲染。
      if (!this.micRunning) this._startMic();
    },

    // 能量柱自检：按满音量下发一帧（外侧绿→内侧红渐变）
    // 若只有最前面几颗变化，说明固件未烧录 0x04 分批支持
    _powerSweep() {
      const colors = this._buildPowerColors(100);
      const frames = [];
      for (let base = 0; base < colors.length; base += POWER_CHUNK) {
        frames.push({
          func: protocol.CMD.SEGMENT,
          data: protocol.light.segment(base, colors.slice(base, base + POWER_CHUNK)),
        });
      }
      this._emitBurst(frames);
    },

    async toggleMic() {
      if (this.micRunning) { this._stopMic(); return; }
      await this._startMic();
    },

    async _startMic() {
      // Android App 使用原生 AudioRecord；uni.getRecorderManager 的实时帧回调在 App-Android 不可用。
      // #ifdef APP-PLUS
      const granted = await ensureAudioPermission();
      if (!granted) {
        uni.showModal({
          title: '需要麦克风权限',
          content: '请允许本应用使用麦克风后再开启音乐律动。',
          confirmText: '去设置',
          confirmColor: '#a855f7',
          success: (res) => { if (res.confirm) openAppPermissionSetting(); },
        });
        this.setData({ micStatus: '未授予麦克风权限' });
        return;
      }
      if (!nativeMic || typeof nativeMic.start !== 'function') {
        this.setData({ micStatus: '原生实时采音模块未加载，请重新安装完整 APK' });
        uni.showToast({ title: '实时采音模块不可用', icon: 'none' });
        return;
      }

      this._micLevel = 0;
      this._micPeak = 0;
      this._lastMicSend = 0;
      this._micFrameCnt = 0;
      this.setData({ micRunning: true, micLevel: 0, micStatus: '原生录音启动中…', micFrames: 0 });
      this._micLog('[MIC] start: native AudioRecord 16k/mono PCM');
      try {
        nativeMic.start({ sampleRate: 16000 }, (res) => this._onNativeMicEvent(res));
        this._micTimer = setTimeout(() => {
          if (this.micRunning && !this._micFrameCnt) {
            this.setData({ micStatus: '未收到麦克风音频帧，请检查系统麦克风权限' });
            this._micLog('启动后 2 秒无原生音频帧', true);
          }
        }, 2000);
      } catch (e) {
        this.setData({ micRunning: false, micStatus: '启动原生录音失败：' + (e.message || e) });
        this._micLog('native start exception: ' + (e.message || e), true);
      }
      return;
      // #endif

      // 非 Android App 平台保留原有录音管理器实现。
      if (!uni.getRecorderManager) {
        uni.showToast({ title: '当前环境不支持录音', icon: 'none' });
        return;
      }
      const rm = uni.getRecorderManager();
      this._rm = rm;
      this._micLevel = 0;
      this._micHue = 0;
      this._micPeak = 0;
      this._lastMicSend = 0;
      this.setData({ micStatus: '录音启动中…', micFrames: 0 });
      this._micLog('[MIC] start: PCM 16k/单声道 frameSize=1');
      rm.onFrameRecorded((res) => this._onMicFrame(res));
      rm.onError((e) => {
        const msg = '录音异常：' + ((e && e.errMsg) || '未知');
        this.setData({ micStatus: msg });
        this._micLog('[MIC] error: ' + msg, true);
        uni.showToast({ title: '录音异常，已停止', icon: 'none' });
        this._stopMic();
      });
      rm.onStop(() => {
        this.setData({ micRunning: false, micLevel: 0 });
      });
      try {
        rm.start({
          format: 'PCM',          // 原始 PCM，便于直接计算音量
          sampleRate: 16000,      // 16k 单声道足够做能量检测，数据量小
          numberOfChannels: 1,
          frameSize: 1,           // 每帧 1KB（约 32ms）
        });
        this.setData({ micRunning: true });
      } catch (e) {
        uni.showToast({ title: '启动录音失败', icon: 'none' });
      }
    },

    _stopMic() {
      // #ifdef APP-PLUS
      try {
        if (nativeMic && typeof nativeMic.stop === 'function') nativeMic.stop();
      } catch (e) { this._micLog('native stop exception: ' + (e.message || e), true); }
      // #endif
      try {
        if (this._rm) {
          this._rm.onFrameRecorded(null);
          this._rm.stop();
        }
      } catch (e) { /* ignore */ }
      this._rm = null;
      clearTimeout(this._micTimer);
      this._micTimer = null;
      this._micAvg = null;
      this._micStep = null;
      this._micBeatAt = 0;
      if (this.micRunning || this.micLevel) {
        this.setData({ micRunning: false, micLevel: 0, micStatus: '' });
      }
      this._micFrameCnt = 0;
    },

    // 写入 BLE 调试日志（仅落 ble.js 内部缓冲，界面入口已隐藏）
    _micLog(text, warn) {
      try {

        if (ble && ble._log) ble._log('[MIC] ' + text, warn ? 'warn' : undefined);
      } catch (e) { /* ignore */ }
      console.log('[MIC] ' + text);
    },

    // Android AudioRecord 原生回调只传 RMS 标量，避免高频 PCM 跨 JS Bridge。
    _onNativeMicEvent(res) {
      if (!res || !res.type) return;
      if (res.type === 'started') {
        this.setData({ micStatus: '采集正常（Android 原生）' });
        this._micLog('原生 AudioRecord 已开始');
        return;
      }
      if (res.type === 'stopped') {
        if (!this._micStopping) this.setData({ micRunning: false, micLevel: 0 });
        return;
      }
      if (res.type === 'error') {
        const message = '录音异常：' + (res.message || '未知错误');
        this.setData({ micRunning: false, micStatus: message, micLevel: 0 });
        this._micLog(message, true);
        clearTimeout(this._micTimer);
        this._micTimer = null;
        uni.showToast({ title: '录音异常', icon: 'none' });
        return;
      }
      if (res.type !== 'frame') return;
      const rms = Number(res.rms);
      if (!Number.isFinite(rms) || rms < 0) return;

      this._micFrameCnt = (this._micFrameCnt || 0) + 1;
      if (this._micFrameCnt === 1) {
        clearTimeout(this._micTimer);
        this._micTimer = null;
        this.setData({ micStatus: '采集正常（Android 原生）' });
        this._micLog('原生首帧到达 rms=' + rms.toFixed(5));
      } else if (this._micFrameCnt % 20 === 0) {
        this.setData({ micFrames: this._micFrameCnt });
      }
      this._processMicRms(rms);
    },

    // 录音帧回调：非 Android App 平台使用 PCM buffer 计算 RMS。
    _onMicFrame(res) {
      if (!res || !res.frameBuffer) return;
      let pcm;
      try {
        pcm = new Int16Array(res.frameBuffer);
      } catch (e) {
        this.setData({ micStatus: '音频帧解析失败（非 PCM？）' });
        return;
      }
      if (!pcm.length) return;

      // 帧计数（每 20 帧刷新一次 UI，避免 setData 过密）
      this._micFrameCnt = (this._micFrameCnt || 0) + 1;
      if (this._micFrameCnt === 1) {
        this.setData({ micStatus: '采集正常' });
        this._micLog('首帧到达，采样点数=' + pcm.length);
      } else if (this._micFrameCnt % 20 === 0) {
        this.setData({ micFrames: this._micFrameCnt });
      }

      let sum = 0;
      let n = 0;
      const step = pcm.length > 1024 ? 2 : 1; // 降采样，减少计算量
      for (let i = 0; i < pcm.length; i += step) {
        const v = pcm[i] / 32768;
        sum += v * v;
        n++;
      }
      if (!n) return;
      const rms = Math.sqrt(sum / n);
      this._processMicRms(rms);
    },

    // 统一 RMS → AGC → 平滑 → 节流下发，原生 AudioRecord 与录音管理器共用
    _processMicRms(rms) {
      if (!Number.isFinite(rms) || rms < 0) return;

      // AGC：以近期峰值为基准归一化，使任何环境音量都能映射满量程
      const raw = Math.pow(rms, 0.6) * 220; // 原始能量（未归一化）
      // 峰值衰减 0.995 → 0.985（半衰期 ≈1.5s）：原来衰减太慢，连续播放时 peak 会一路爬升，
      //   raw/peak 长期贴住 1 → level 恒为 100，亮度没有起伏（律动"很平"的主因之一）
      this._micPeak = Math.max(raw, (this._micPeak || 0) * 0.985);
      const peak = Math.max(this._micPeak, 8); // 下限，避免安静时噪声被放大满
      // 增益：拾音灵敏度滑块作为增益系数（50 → 1.0）
      const gain = (this.musicMic || 50) / 50;
      let level = Math.round((raw / peak) * 100 * gain);
      if (level > 100) level = 100;
      // 一阶平滑：起快（0.7，保留打击感）落慢（0.25，留余韵）
      const prev = this._micLevel || 0;
      const k = level > prev ? 0.7 : 0.25;
      this._micLevel = Math.round(prev * (1 - k) + level * k);
      this.setData({ micLevel: this._micLevel });

      // 节流下发（BLE 有响应等待，过密会堵塞）
      //   现在每帧只有 1~2 条短指令（渲染在固件里），可以比原来发得更密，律动更连贯
      const intervals = { strobe: 70, pulse: 70, rainbow: 80, power: 70, heart: 70, bars: 80 };
      const gap = intervals[this.micMode] || 80;

      const now = Date.now();
      if (now - (this._lastMicSend || 0) < gap) return;
      this._lastMicSend = now;
      this._applyMicLevel(this._micLevel);
    },

    /**
     * 能量柱（灯板显示）：按 0x04 分段设置颜色，20 组 RGB 逐颗下发
     * 布局：左半 10 颗（i=0 最外 → i=9 最内）、右半 10 颗（i=10 最内 → i=19 最外）
     * 权重：外侧高内侧低 → 能量从两端向中间灌注；左右权重不同 → 形成落差
     */
    _buildPowerColors(lv) {
      const W_L = [1.0, 0.86, 0.72, 0.58, 0.46, 0.34];  // 左侧 6 柱（外→内）
      const W_R = [0.95, 0.80, 0.66, 0.52, 0.40, 0.28]; // 右侧 6 柱（外→内）与左侧错开
      const sample = (W, t) => {
        const x = Math.max(0, Math.min(1, t)) * (W.length - 1);
        const i = Math.floor(x);
        const f = x - i;
        return i + 1 < W.length ? W[i] * (1 - f) + W[i + 1] * f : W[W.length - 1];
      };
      const N = POWER_LED_N;
      const half = N / 2;
      const colors = [];
      for (let i = 0; i < N; i++) {
        // t: 0=最外, 1=最内
        const t = i < half ? i / (half - 1) : (N - 1 - i) / (half - 1);
        const w = i < half ? sample(W_L, t) : sample(W_R, t);
        // 该灯珠能量 = 音量 × 位置权重（外侧先亮，向中间推进）
        const e = Math.max(0, Math.min(1, (lv / 100) * w));
        // 绿(低) → 黄 → 红(高)；亮度带底光，静音时也有微光可见
        const hue = Math.round(120 * (1 - e));
        const v = Math.min(1, POWER_FLOOR + e * (1 - POWER_FLOOR));
        // 注意：组件内 _hsv2rgb 返回数组 [r,g,b]（定义在文件后部），勿按对象取值
        const [r, g, b] = this._hsv2rgb(hue, 1, v) || [0, 0, 0];
        colors.push({ r, g, b });
      }
      return colors;
    },

    // 把音量/节拍映射为灯光指令
    //   律动画面已由固件渲染(固件 rgb_mic_render: 6 种方式逐颗 IC、100Hz 帧率),
    //   手机这边只负责"喂数据"。不要再自己做爆闪/心跳的 setTimeout ——
    //   那些延迟帧会覆盖音量通道, 与固件自己的节拍检测打架, 结果反而更乱。
    //     0x05 亮度帧 = 当前音量(HSV 机型 0~1000, 固件在律动态下把它当电平用)
    //     0x0F 速度帧 = 非 HSV 机型的音量通道(1~100, 固件 ×10 还原)
    //     0x03 颜色帧 = 基准色相, 只给"脉冲/彩虹"这类要色彩流转的模式
    _applyMicLevel(lv) {
      const typeId = this.typeId;
      const mode = this.micMode;
      // 律动指令：全部走 silent 通道（不等响应，避免超时报错）
      const send = (cmd, data) => this._emit(cmd, data, true);

      if (this.isStrip) {
        send(protocol.CMD.BRIGHTNESS,
          protocol.light.brightness(typeId, Math.round(1000 * lv / 100)));
      } else {
        // 非 HSV 机型的亮度帧只有 1 字节, 用速度通道(1~100)带音量
        send(protocol.CMD.SPEED,
          protocol.light.speed(Math.max(1, Math.min(100, Math.round(lv)))));
      }

      // 色彩流转：脉冲缓慢转、彩虹随音量加速（固件会在这个基准色相上继续漂移）
      if (mode === 'pulse' || mode === 'rainbow') {
        const step = mode === 'rainbow' ? (8 + Math.round(lv / 4)) : 2;
        this._micHue = ((this._micHue || 0) + step) % 360;
        send(protocol.CMD.COLOR,
          protocol.light.color(typeId, { r: 0, g: 0, b: 0, h: this._micHue, s: 1000 }));
      }
    },

    // ====== 设置页 ======
    // 设备名编辑：交由父页面（device）弹出编辑框
    onEditNameTap() {
      this.$emit('editname');
    },

    // RGB 线序（CMD 0xF4 + factory.lineOrder）
    onLineOrderChange(e) {
      const idx = Number(e.detail.value);
      this.setData({ lineOrderIndex: idx });
      this._emit(protocol.CMD.LINE_ORDER, protocol.factory.lineOrder(idx));
    },
    // 灯珠驱动方案：⚠️ 目前只做 UI 占位（本地显示），不下发任何指令。
    //   协议与固件实现（0xF9：设置/查询 + 断电保持）待驱动方案落地后再接。
    onDriverSchemeChange(e) {
      this.setData({ driverIndex: Number(e.detail.value) });
    },
    // 页面提示文字开关：关闭后界面上所有说明性小字隐藏（自定义开关，点击即切换）
    onToggleTips(e) {
      const v = (e && e.detail && typeof e.detail.value !== 'undefined')
        ? !!e.detail.value
        : !this.showTips;
      this.setData({ showTips: v });
      try { uni.setStorageSync('lightPanelShowTips', v); } catch (err) { /* ignore */ }
      uni.showToast({ title: v ? '已显示提示文字' : '已隐藏提示文字', icon: 'none' });
    },

    // 读取软件版本（CMD 0x02），结果由父页面回传到 firmware 属性
    onReadFirmware() {
      this._emit(protocol.CMD.FIRMWARE, protocol.light.firmware());
    },

    // ====== 灯珠数量 ======
    onEditLed() {
      const that = this;
      uni.showModal({
        title: '灯珠数量', editable: true, placeholderText: '输入灯珠数量',
        content: String(that.ledCount),
        confirmColor: '#a855f7',
        success(res) {
          if (!res.confirm) return;
          const n = parseInt(res.content, 10);
          if (!(n > 0 && n <= 65535)) {
            uni.showToast({ title: '请输入 1~65535 的整数', icon: 'none' });
            return;
          }
          // 先更新本地显示
          that.setData({ ledCount: n });
          // 灯珠设定完成确认后下发：0x55 0x0B 0xFF 0x07 data1 data2 checksum
          // data1/data2 = 当前设定灯珠数（大端 16bit），长度/校验由 ble.js 自动封装
          that._emit(protocol.CMD.LED_COUNT, protocol.light.ledCount(n));
        },
      });
    },

    // ====== 亮度 ======
    // 色温栏 / 彩色栏各用各的亮度值：色温栏→冷暖亮度，彩色栏→整体(RGB)亮度
    onBrightness(e) {
      const v = e.detail.value;
      if (this.brightIsWarm) {
        this.setData({ warmBrightness: v, warmBrightnessPct: Math.round(v) });
        this._debounceEmitWarmBright(v);
        return;
      }
      this.setData({
        brightness: v,
        brightnessPct: Math.round((v / (this.isStrip ? 1000 : 100)) * 100),
      });
      this._debounceEmit(protocol.CMD.BRIGHTNESS, protocol.light.brightness(this.typeId, v));
    },

    // 动态速度：拖动时只预览，松手后通过 0x0F 下发并由 ACK 回读确认值
    onSpeedChanging(e) {
      const speed = Math.max(1, Math.min(100, Math.round(Number(e.detail.value) || 1)));
      this.setData({ speed });
    },
    onSpeedChange(e) {
      const speed = Math.max(1, Math.min(100, Math.round(Number(e.detail.value) || 1)));
      this.setData({ speed });
      this._emit(protocol.CMD.SPEED, protocol.light.speed(speed));
    },

    // 冷暖亮度：CW 统一走 0x12 单帧（同时回写当前色温）；
    // 设备不具备 CW 能力时退回 0x05 整体亮度，保证仍能调光
    _emitWarmBright(v) {
      const frames = protocol.cwFrames(this.typeId, this.warmCool, v);
      if (!frames.length) {
        this._emit(protocol.CMD.BRIGHTNESS, protocol.light.brightness(this.typeId, v));
        return;
      }
      this._emit(frames[0][0], frames[0][1]);
    },
    _debounceEmitWarmBright(v) {
      if (this._warmBrightTimer) clearTimeout(this._warmBrightTimer);
      this._warmBrightTimer = setTimeout(() => this._emitWarmBright(v), 80);
    },

    // ====== 色温 ======
    // 拖动中：只更新本地显示（0 最暖 → 100 最冷）
    onWarmCoolChanging(e) { this.setData({ warmCool: Number(e.detail.value) }); },
    // 松手：下发当前色温
    onWarmCool(e) { this._applyWarmCool(Number(e.detail.value)); },
    // 预设色温：点即下发（色温页专用，与彩色页常用颜色互不干扰）
    onWarmPresetTap(e) {
      const v = Number(e.currentTarget.dataset.v);
      if (isNaN(v)) return;
      this._applyWarmCool(v);
    },
    // 下发色温：CW 统一走 0x12 单帧（同时回写当前冷暖亮度）
    _applyWarmCool(v) {
      this.setData({ warmCool: v });
      const frames = protocol.cwFrames(this.typeId, v, this.warmBrightnessPct);
      if (!frames.length) {
        uni.showToast({ title: '该设备不支持色温', icon: 'none' });
        return;
      }
      this._emit(frames[0][0], frames[0][1]);
    },

    // ====== 色相环绘制（基于实例属性，不走 data）======
    _drawWheel(force) {
      if (this._wheelCssOn) return;   // CSS 色环已就绪，无需 canvas 绘制
      const ctx = this._ctx;
      if (!ctx) return;
      // 2d 模式用缓冲区坐标系，老式接口用 CSS px 坐标系
      const legacy = !!this._legacy;
      const S = legacy ? this._cssSize : this._bufSize;
      const cx = legacy ? this._cssCx : this._bufCx;
      const cy = legacy ? this._cssCy : this._bufCy;
      const R = legacy ? this._cssR : this._bufR;
      if (!S || !R) return;

      // 已生成过同尺寸色环：直接复用缓存的 ImageData。
      // 切 Tab / 回到页面都会触发重绘，走缓存后是"一次 putImageData"，毫秒级。
      if (!legacy && !force && this._wheelImg && this._wheelImgSize === S) {
        try {
          ctx.putImageData(this._wheelImg, 0, 0);
          this._markWheelReady();
          return;
        } catch (e) { this._wheelImg = null; }
      }

      const finish = () => {
        if (legacy && typeof ctx.draw === 'function') ctx.draw();
      };
      const setStroke = (color, w) => {
        if (legacy) {
          ctx.setStrokeStyle(color);
          ctx.setLineWidth(w);
        } else {
          ctx.strokeStyle = color;
          ctx.lineWidth = w;
        }
      };

      // 清空
      try {
        ctx.clearRect(0, 0, S, S);
      } catch (e) { /* ignore */ }

      // 老式接口（或不支持 ImageData 的 WebView）走色相弧段绘制，效果等同
      const canImage =
        !legacy && typeof ctx.createImageData === 'function' && typeof ctx.putImageData === 'function';
      if (!canImage) {
        // 弧段模式：条数减半即可保持观感（原 180×24=4320 段，绘制同样要一秒多）
        const HUES = 144;
        const RINGS = 20;
        const ringW = Math.max(1, R / RINGS);
        for (let m = 0; m < RINGS; m++) {
          const r = Math.max(0.5, R - m * ringW - ringW / 2);
          const sat = 1 - m / (RINGS > 1 ? RINGS - 1 : 1); // 外圈饱和 → 圆心纯白
          for (let h = 0; h < HUES; h++) {
            const a0 = (h / HUES) * 2 * Math.PI;
            const a1 = ((h + 1.08) / HUES) * 2 * Math.PI; // 略微重叠，避免出现缝隙
            const rgb = this._hsv2rgb((h / HUES) * 360, sat, 1);
            setStroke('rgb(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ')', ringW + 1);
            ctx.beginPath();
            ctx.arc(cx, cy, r, a0, a1);
            ctx.stroke();
          }
        }
        finish();
        this._markWheelReady();
        console.log('[light-panel] wheel drawn (arc mode, legacy=' + legacy + ')');
        return;
      }

      const innerR = 0;
      // 逐像素绘制；任何异常（如 WebView 不支持 putImageData）都退回到弧段绘制
      try {
        this._drawWheelPixels(ctx, S, cx, cy, R, innerR);
        finish();
        this._markWheelReady();
        return;
      } catch (e) {
        console.warn('[light-panel] ImageData 绘制失败，改用弧段绘制', e);
        this._legacy = true; // 老式接口语义（setStrokeStyle / draw）
        this._drawWheelArcs(ctx, S, cx, cy, R);
        this._markWheelReady();
        return;
      }
    },

    // 首帧绘制完成：撤掉 CSS 占位层
    _markWheelReady() {
      if (this.wheelReady) return;
      this.setData({ wheelReady: true });
    },

    // 逐像素生成色环：
    //  - 色相走 720 段 LUT，像素着色只剩一次乘法插值（不再每像素调用 _hsv2rgb）
    //  - 用 Uint32Array 一次写 4 字节，比 4 次字节赋值快 2~3 倍
    //  - 缓冲区已限幅到 360px，整体从秒级降到几十毫秒
    _drawWheelPixels(ctx, S, cx, cy, R, innerR) {
      const imgData = ctx.createImageData(S, S);
      const d = imgData.data;

      if (!this._hueLut) {
        const N = 720;
        const lut = new Uint8Array(N * 3);
        for (let i = 0; i < N; i++) {
          const rgb = this._hsv2rgb((i / N) * 360, 1, 1);
          lut[i * 3] = rgb[0]; lut[i * 3 + 1] = rgb[1]; lut[i * 3 + 2] = rgb[2];
        }
        this._hueLut = lut;
      }
      const lut = this._hueLut;
      const N = 720;
      const TWO_PI = Math.PI * 2;
      const R2 = R * R;
      const BG = 0xFF12120C; // ABGR：rgb(12,12,18)，与主题底色一致

      // 32 位批量写入依赖小端字节序（Android ARM 均满足）；不满足则退回逐字节写
      let d32 = null;
      try {
        const littleEndian = new Uint8Array(new Uint32Array([1]).buffer)[0] === 1;
        if (littleEndian) d32 = new Uint32Array(d.buffer, d.byteOffset, S * S);
      } catch (e) { d32 = null; }

      for (let y = 0; y < S; y++) {
        const dy = y - cy;
        const dy2 = dy * dy;
        const row = y * S;
        if (dy2 > R2) {
          // 整行都在圆外
          if (d32) for (let x = 0; x < S; x++) d32[row + x] = BG;
          else for (let x = 0; x < S; x++) { const i = (row + x) * 4; d[i] = 12; d[i + 1] = 12; d[i + 2] = 18; d[i + 3] = 255; }
          continue;
        }
        for (let x = 0; x < S; x++) {
          const dx = x - cx;
          const dist2 = dx * dx + dy2;
          const idx = row + x;
          if (dist2 > R2) {
            if (d32) d32[idx] = BG;
            else { const i = idx * 4; d[i] = 12; d[i + 1] = 12; d[i + 2] = 18; d[i + 3] = 255; }
            continue;
          }
          const dist = Math.sqrt(dist2);
          let ang = Math.atan2(dy, dx);
          if (ang < 0) ang += TWO_PI;
          let k = ((ang / TWO_PI) * N) | 0;
          if (k >= N) k = N - 1;
          const sat = dist >= R ? 1 : dist / R;
          const pr = lut[k * 3], pg = lut[k * 3 + 1], pb = lut[k * 3 + 2];
          const r = 255 - sat * (255 - pr);
          const g = 255 - sat * (255 - pg);
          const b = 255 - sat * (255 - pb);
          if (d32) d32[idx] = 0xFF000000 | (b << 16) | (g << 8) | r;
          else { const i = idx * 4; d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 255; }
        }
      }
      ctx.putImageData(imgData, 0, 0);
      this._wheelImg = imgData;
      this._wheelImgSize = S;
    },

    // 弧段绘制：不支持 ImageData（或绘制抛异常）时的等价实现
    _drawWheelArcs(ctx, S, cx, cy, R) {
      const legacy = !!this._legacy;
      const setStroke = (color, w) => {
        if (legacy) {
          ctx.setStrokeStyle(color);
          ctx.setLineWidth(w);
        } else {
          ctx.strokeStyle = color;
          ctx.lineWidth = w;
        }
      };
      const HUES = 144;
      const RINGS = 20;
      const ringW = Math.max(1, R / RINGS);
      for (let m = 0; m < RINGS; m++) {
        const r = Math.max(0.5, R - m * ringW - ringW / 2);
        const sat = 1 - m / (RINGS > 1 ? RINGS - 1 : 1); // 外圈饱和 → 圆心纯白
        for (let h = 0; h < HUES; h++) {
          const a0 = (h / HUES) * 2 * Math.PI;
          const a1 = ((h + 1.08) / HUES) * 2 * Math.PI;
          const rgb = this._hsv2rgb((h / HUES) * 360, sat, 1);
          setStroke('rgb(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ')', ringW + 1);
          ctx.beginPath();
          ctx.arc(cx, cy, r, a0, a1);
          ctx.stroke();
        }
      }
      if (legacy && typeof ctx.draw === 'function') ctx.draw();
      console.log('[light-panel] wheel drawn (arc mode, legacy=' + legacy + ')');
    },

    _placeThumb(hue, sat) {
      const cx = this._cssCx, cy = this._cssCy, R = this._cssR;
      if (!R) return;
      const innerR = 0;
      const rr = innerR + sat * (R - innerR);
      const ang = hue / 360 * 2 * Math.PI;
      const tx = cx + rr * Math.cos(ang);
      const ty = cy + rr * Math.sin(ang);
      const [r, g, b] = this._hsv2rgb(hue, sat, 1);
      const hex = ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1).toUpperCase();
      // 合并为一次 setData：拖动时每帧一次渲染，避免两次赋值触发两轮视图更新
      this.setData({ thumbX: tx, thumbY: ty, rgbR: r, rgbG: g, rgbB: b, currentColorHex: hex });
    },

    // ====== 触摸取色 ======
    _pickColor(x, y) {
      const cx = this._cssCx, cy = this._cssCy, R = this._cssR;
      if (!R) return false;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      // 画布半径（可视区域）：比取色半径多留 2px 容差，
      // 贴边/圆角边缘的点击按"最外圈饱和色"处理，而不是直接丢弃（避免边缘点不动）
      const limit = (this._cssSize || R * 2) / 2 + 2;
      if (dist > limit) return false;

      let ang = Math.atan2(dy, dx);
      if (ang < 0) ang += Math.PI * 2;
      const hue = (ang / (Math.PI * 2)) * 360;
      const sat = Math.min(1, dist / R);

      this._placeThumb(hue, sat);

      // 下发颜色：type 0x01 用 HSV(色相0~360, 饱和度0~1000)，其它 type 用 RGB
      // 协议帧：0x55 0x03 0xff 0x09 H_hi H_lo S_hi S_lo checksum
      // 拖动过程走"实时通道"（节流 + 只保留最新一帧），松手时再补一帧确认，
      // 否则每帧都排进 BLE 指令链会积压，滑一会儿就整体卡顿。
      const [r, g, b] = this._hsv2rgb(hue, sat, 1);
      const h = Math.round(hue);
      const s = Math.round(sat * 1000);
      const colorData = protocol.light.color(this.typeId, { h, s, r, g, b });
      this._lastColorData = colorData;
      this._emitColorRealtime(colorData);
      return true;
    },

    _toCanvasPos(e) {
      const touch = e.touches && e.touches[0] ? e.touches[0] : e.changedTouches[0];
      return { x: touch.x, y: touch.y };
    },

    onTouchStart(e) {
      const p = this._toCanvasPos(e);
      this._pickColor(p.x, p.y);
    },
    onTouchMove(e) {
      const p = this._toCanvasPos(e);
      this._pickColor(p.x, p.y);
    },
    onTouchEnd() {
      // 松手：补发最终颜色（走有回包通道，失败可提示），保证停在最后取到的颜色
      this._flushColorRealtime();
      this._addRecentColor(this.currentColorHex);
      this.$emit('saverequest', { panel: 'light', action: 'color' });
    },

    // RGB 微调
    onTweakR(e) { this._tweakRgb('rgbR', e.detail.value); },
    onTweakG(e) { this._tweakRgb('rgbG', e.detail.value); },
    onTweakB(e) { this._tweakRgb('rgbB', e.detail.value); },
    _tweakRgb(key, val) {
      this.setData({ [key]: val });
      const { rgbR: r, rgbG: g, rgbB: b } = this.data;
      const hex = ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1).toUpperCase();
      this.setData({ currentColorHex: hex });

      // RGB→HSV 转换后同时携带 H/S 和 R/G/B；拖动过程同样走实时节流通道
      const [hf, sf] = this._rgb2hsv(r, g, b);
      const colorData = protocol.light.color(this.typeId, {
        h: Math.round(hf * 360), s: Math.round(sf * 1000), r, g, b,
      });
      this._lastColorData = colorData;
      this._emitColorRealtime(colorData);

      // 拖拽停止后延时记录常用颜色
      if (this._recentTimer) clearTimeout(this._recentTimer);
      this._recentTimer = setTimeout(() => this._addRecentColor(hex), 800);
    },
    // RGB 滑块松手：补发最终颜色
    onTweakDone() { this._flushColorRealtime(); },

    // ====== 常用颜色 ======
    _addRecentColor(hex) {
      let list = this.recentColors.filter(c => c && c !== hex);
      list.unshift(hex);
      if (list.length > 6) list = list.slice(0, 6);
      while (list.length < 6) list.push('');
      this.setData({ recentColors: list });
      uni.setStorageSync('recentLightColors', list);
    },

    onRecentColorTap(e) {
      const hex = e.currentTarget.dataset.color;
      if (!hex) return;
      const r = parseInt(hex.slice(0, 2), 16);
      const g = parseInt(hex.slice(2, 4), 16);
      const b = parseInt(hex.slice(4, 6), 16);
      this.setData({ rgbR: r, rgbG: g, rgbB: b, currentColorHex: hex });
      // 移动 thumb 到对应位置
      const [hf, sf] = this._rgb2hsv(r, g, b);
      this._placeThumb(hf * 360, sf);
      // 下发：同时携带 H/S 和 R/G/B
      this._emit(protocol.CMD.COLOR, protocol.light.color(this.typeId, {
        h: Math.round(hf * 360), s: Math.round(sf * 1000), r, g, b,
      }));
    },

    _rgb2hsv(r, g, b) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b);
      const d = max - min;
      let h = 0;
      if (d !== 0) {
        if (max === r) h = ((g - b) / d) % 6;
        else if (max === g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;
        h /= 6;
        if (h < 0) h += 1;
      }
      const s = max === 0 ? 0 : d / max;
      return [h, s];
    },

    // ====== 工具 ======
    _initColor() {
      this._placeThumb(270, 0.75);
    },

    _hsv2rgb(h, s, v) {
      h = ((h % 360) + 360) % 360;
      const c = v * s;
      const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
      const m = v - c;
      let r = 0, g = 0, b = 0;
      if (h < 60) { r = c; g = x; }
      else if (h < 120) { r = x; g = c; }
      else if (h < 180) { g = c; b = x; }
      else if (h < 240) { g = x; b = c; }
      else if (h < 300) { r = x; b = c; }
      else { r = c; b = x; }
      return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
    },

    _debounceEmit(func, data) {
      if (this._emitTimer) clearTimeout(this._emitTimer);
      this._emitTimer = setTimeout(() => this._emit(func, data), 80);
    },

    // ====== 颜色实时下发（拖动调色专用）======
    // 拖动时触摸/滑块事件可达 60 帧/秒，若每帧都走普通指令链（等回包），
    // BLE 队列会越积越多，手指停下后还要排队很久才恢复 → 表现为"卡顿一阵"。
    // 这里节流到 ~12 帧/秒，并走 silent 实时通道（writeNoWait：同功能只保留最新一帧）。
    _emitColorRealtime(colorData) {
      this._pendingColorData = colorData;
      if (this._colorRtTimer) return;
      this._colorRtTimer = setTimeout(() => {
        this._colorRtTimer = null;
        const data = this._pendingColorData;
        this._pendingColorData = null;
        if (data) this._emit(protocol.CMD.COLOR, data, true);
      }, 80);
    },
    // 松手：取消节流并用有回包通道补发最后一帧（只发一次，不影响流畅度）
    _flushColorRealtime() {
      if (this._colorRtTimer) { clearTimeout(this._colorRtTimer); this._colorRtTimer = null; }
      this._pendingColorData = null;
      if (this._lastColorData) this._emit(protocol.CMD.COLOR, this._lastColorData);
    },
  },
}
</script>

<style>
.lp-wrap { padding: 0 28rpx 32rpx; }

/* 通用行 */
.row { display: flex; align-items: center; }
.label { font-size: 28rpx; color: rgba(255,255,255,.7); min-width: 100rpx; }
.edit-icon {
  font-size: 26rpx; color: rgba(255,255,255,.3); margin-left: 12rpx;
}

/* 灯珠数量 */
.led-row { padding: 20rpx 0; border-bottom: 1rpx solid rgba(255,255,255,.06); }
.led-val { font-size: 30rpx; color: #e8e8f0; font-weight: 600; }

/* ====== 亮度 ====== */
.section { padding: 24rpx 0; }
.brightness-row { gap: 16rpx; align-items: center; }
.bright-slider { flex: 1; margin: 0 8rpx; }
.speed-row { padding-top: 36rpx; }
.speed-value {
  font-size: 28rpx; color: #22d3ee; font-weight: 600;
  min-width: 80rpx; text-align: right;
}
.bright-pct {
  font-size: 28rpx; color: #a855f7; font-weight: 600;
  min-width: 80rpx; text-align: right;
}

/* ====== 子 Tab（颜色/场景/音乐/DIY/设置）===== */
.sub-tabs {
  display: flex; gap: 12rpx; padding: 20rpx 0 10rpx;
}
.sub-tab {
  font-size: 26rpx; color: rgba(255,255,255,.45);
  padding: 10rpx 28rpx; border-radius: 999rpx;
  background: rgba(255,255,255,.05); transition: all .2s;
}
.sub-tab.active {
  background: rgba(168,85,247,.2);
  color: #c4b5fd; font-weight: 500;
}

/* ====== 颜色二级 Tab（色温/彩色）===== */
.color-tabs {
  display: flex; gap: 40rpx; justify-content: center; padding: 14rpx 0 24rpx;
}
.color-tab {
  font-size: 28rpx; color: rgba(255,255,255,.35);
  position: relative; padding-bottom: 10rpx;
}
.color-tab.active {
  color: #a855f7; font-weight: 500;
}
.color-tab.active::after {
  content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 36rpx; height: 4rpx; border-radius: 2rpx; background: #a855f7;
}

/* ====== 色温（slider 叠在渐变条上）====== */
.ct-section { padding: 16rpx 0; }
.ct-row-head {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 16rpx;
}
.ct-val {
  font-size: 28rpx; color: #f5d78e; font-weight: 600;
  min-width: 80rpx; text-align: right;
}
.ct-bar-wrap {
  position: relative; width: 100%; height: 48rpx;
}
.ct-bar {
  position: absolute; top: 0; left: 0; width: 100%; height: 100%;
  border-radius: 24rpx;
  background: linear-gradient(90deg, #fff4e0, #a8d4ff);
  overflow: hidden;
  pointer-events: none;
}
.ct-warm, .ct-cold { height: 100%; width: 50%; display: inline-block; vertical-align: top; }
.ct-slider {
  position: absolute; top: 0; left: 0; width: 100% !important; height: 100% !important;
  margin: 0 !important;
}

/* ====== 色相环 ====== */
/* 提示文字总开关：关闭后隐藏所有说明性小字（采集状态这类实时反馈保留） */
.lp-wrap.tips-off .mic-tip { display: none; }
.lp-wrap.tips-off .mic-tip.mic-live { display: block; }

.wheel-wrap {
  position: relative; width: 480rpx; height: 480rpx;
  margin: 20rpx auto; display: flex; align-items: center; justify-content: center;
}
.color-wheel {
  width: 480rpx; height: 480rpx; border-radius: 50%;
  box-shadow: 0 6rpx 40rpx rgba(0,0,0,.5);
}
/* 色环首帧占位：conic(色相) + radial(饱和度→白)，与逐像素结果视觉一致 */
.wheel-fallback {
  position: absolute; left: 0; top: 0; width: 480rpx; height: 480rpx;
  border-radius: 50%; pointer-events: none;
  background:
    radial-gradient(circle at center, #ffffff 0%, rgba(255,255,255,0.96) 4%, rgba(255,255,255,0) 70%),
    conic-gradient(from 90deg, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
}
.thumb {
  position: absolute; width: 36rpx; height: 36rpx;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 2rpx 10rpx rgba(0,0,0,.4), inset 0 0 0 3rpx rgba(0,0,0,.08);
  pointer-events: none;
  transform: translate(-50%, -50%);
  z-index: 2;
}

/* ====== 当前颜色信息 ====== */
.color-info {
  display: flex; align-items: center; gap: 20rpx;
  padding: 24rpx 16rpx; margin-top: 10rpx;
}
.preview-swatch {
  width: 72rpx; height: 72rpx; border-radius: 18rpx;
  border: 3rpx solid rgba(255,255,255,.12); flex-shrink: 0;
}
.color-text { display: flex; flex-direction: column; gap: 4rpx; }
.color-label { font-size: 24rpx; color: rgba(255,255,255,.4); }
.color-hex { font-size: 32rpx; font-weight: 700; color: #e8e8f0; letter-spacing: 1rpx; }
.rgb-badges {
  display: flex; gap: 10rpx; margin-left: auto;
}
.rgb-badge {
  display: flex; align-items: center; gap: 6rpx;
  padding: 8rpx 16rpx; border-radius: 12rpx;
  font-size: 22rpx;
}
.rgb-badge text:first-child { font-weight: 800; font-size: 22rpx; }
.rgb-badge.r { background: rgba(255,107,107,.15); color: #ff8787; }
.rgb-badge.g { background: rgba(81,207,102,.15); color: #69db7c; }
.rgb-badge.b { background: rgba(51,154,240,.15); color: #74c0fc; }

/* RGB 微调 */
.rgb-tweak { padding: 16rpx 0; }
.tweak-row { display: flex; align-items: center; gap: 12rpx; margin-bottom: 10rpx; }
.tw-lbl {
  width: 36rpx; font-size: 24rpx; font-weight: 700; text-align: center;
}
.tweak-row slider { flex: 1; }

/* ====== 场景 / DIY 分类与列表 ====== */
.scene-cats, .diy-cats {
  display: flex; gap: 12rpx; padding: 10rpx 0 24rpx;
}
.scene-cat, .diy-cat {
  flex: 1; text-align: center;
  font-size: 26rpx; color: rgba(255,255,255,.45);
  padding: 14rpx 0; border-radius: 999rpx;
  background: rgba(255,255,255,.05); transition: all .2s;
}
.scene-cat.active, .diy-cat.active {
  background: rgba(168,85,247,.2);
  color: #c4b5fd; font-weight: 500;
}

.scene-list {
  max-height: 760rpx;
}
.scene-item {
  display: flex; align-items: center; gap: 24rpx;
  padding: 26rpx 28rpx; margin-bottom: 18rpx;
  border-radius: 22rpx;
  background: linear-gradient(135deg, #141426, #111121);
  border: 1rpx solid rgba(255,255,255,.06);
  box-shadow: 0 6rpx 24rpx rgba(0,0,0,.25);
  transition: all .18s;
}
.scene-item:active { transform: scale(.985); }
.scene-item.active {
  background: linear-gradient(135deg, rgba(168,85,247,.18), rgba(124,58,237,.10));
  border-color: rgba(168,85,247,.45);
  box-shadow: 0 0 24rpx rgba(168,85,247,.15);
}
.scene-icon {
  width: 72rpx; height: 72rpx; border-radius: 18rpx;
  background: rgba(255,255,255,.06);
  display: flex; align-items: center; justify-content: center;
  font-size: 38rpx;
}
/* 列表项封面缩略图（与 .scene-icon 同尺寸，无边框/连线） */
.scene-thumb {
  width: 72rpx; height: 72rpx; border-radius: 18rpx;
  flex-shrink: 0;
  border: none;
  background: transparent;
}
.scene-name {
  font-size: 30rpx; color: #e8e8f0; font-weight: 500;
}

/* ====== 场景封面网格（三列封面 + 下方名称，参考图风格） ====== */
.scene-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 22rpx;
  padding: 4rpx 0 12rpx;
}
.scene-card {
  display: flex; flex-direction: column; align-items: center;
  transition: transform .15s;
}
.scene-card:active { transform: scale(.96); }
/* 封面卡：3 列网格下每列约 216rpx，取 216 高度使封面接近正方形 */
.scene-cover {
  width: 100%; height: 216rpx; border-radius: 20rpx;
  position: relative; overflow: hidden;
  display: flex; align-items: center; justify-content: center;
  background: #111121;                       /* 与卡片底色一致，边缘残留不可见 */
  box-shadow: 0 8rpx 24rpx rgba(0,0,0,.35);
  border: none;
  box-sizing: border-box;
}
.scene-card.active .scene-cover {
  border: 3rpx solid #a855f7;
  box-shadow: 0 0 24rpx rgba(168,85,247,.5);
}
/* 图片放大 10% 并负边距居中：裁掉图片自身的亮色边缘（不依赖 transform，兼容性更好） */
.scene-img {
  width: 110%; height: 110%;
  margin-left: -5%; margin-top: -5%;
}
.scene-cover-icon { font-size: 64rpx; opacity: .9; }
.scene-card-name {
  margin-top: 14rpx; font-size: 26rpx; color: rgba(255,255,255,.75);
  text-align: center;
}
.scene-card.active .scene-card-name { color: #c4b5fd; font-weight: 600; }

/* ====== 常用颜色 ====== */
.recent-colors {
  padding: 28rpx 0 8rpx;
}
.rc-label {
  font-size: 26rpx; color: rgba(255,255,255,.5); margin-bottom: 20rpx;
  display: block;
}
.rc-swatches {
  display: flex; gap: 20rpx; justify-content: space-between;
}
.rc-swatch {
  width: 84rpx; height: 84rpx; border-radius: 20rpx;
  border: 3rpx solid rgba(255,255,255,.12);
  transition: transform .15s;
}
.rc-swatch:active { transform: scale(.9); }
.rc-swatch.empty {
  background: rgba(255,255,255,.04);
  border: 2rpx dashed rgba(255,255,255,.1);
}

/* ====== 预设色温（色温页专用，与彩色页常用颜色独立）====== */
.warm-presets { padding: 24rpx 0 4rpx; }
.wp-grid {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 16rpx;
}
.wp-item {
  box-sizing: border-box;
  display: flex; flex-direction: column; align-items: center; gap: 10rpx;
  padding: 16rpx 0; border-radius: 16rpx;
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.1);
  transition: transform .15s;
}
.wp-item:active { transform: scale(.95); }
.wp-item.active {
  background: rgba(168,85,247,.16);
  border-color: rgba(168,85,247,.6);
}
.wp-dot {
  width: 56rpx; height: 56rpx; border-radius: 50%;
  border: 2rpx solid rgba(255,255,255,.25);
}
.wp-name { font-size: 24rpx; color: rgba(255,255,255,.7); }
.wp-item.active .wp-name { color: #c4b5fd; font-weight: 600; }

/* ====== 音乐律动 ====== */
.apply-btn {
  margin-top: 18rpx;
  height: 84rpx; border-radius: 42rpx;
  display: flex; align-items: center; justify-content: center;
  font-size: 30rpx; font-weight: 600; color: #fff;
  background: linear-gradient(90deg, #a855f7, #7c3aed);
  box-shadow: 0 8rpx 24rpx rgba(124,58,237,.35);
}
.apply-btn:active { opacity: .9; }

.music-title {
  display: block;
  font-size: 26rpx;
  color: #9a9ab0;
  margin: 18rpx 0 6rpx;
}

/* ====== 设置页 ====== */
.set-group {
  background: linear-gradient(135deg, #141426, #111121);
  border: 1rpx solid rgba(255,255,255,.06);
  border-radius: 22rpx;
  margin-bottom: 24rpx;
  overflow: hidden;
}
.set-item {
  display: flex; align-items: center;
  padding: 28rpx 28rpx;
  border-bottom: 1rpx solid rgba(255,255,255,.05);
}
.set-item:last-child { border-bottom: none; }
.set-item:active { background: rgba(255,255,255,.03); }
.set-label { font-size: 28rpx; color: rgba(255,255,255,.7); }
.set-value {
  margin-left: auto; font-size: 28rpx; color: #e8e8f0;
  max-width: 320rpx; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.set-arrow { margin-left: 12rpx; font-size: 32rpx; color: rgba(255,255,255,.3); }
/* picker 是 set-item 的 flex 子项: 用元素选择器把它推到行尾,
   这样"值+箭头"与 .set-value 的右对齐效果一致(picker 元素不吃外层 class 的 flex 布局) */
.set-item picker { margin-left: auto; }
.set-picker {
  display: flex; align-items: center;
}
.set-btn {
  margin-left: 20rpx; padding: 8rpx 24rpx; border-radius: 999rpx;
  font-size: 24rpx; color: #c4b5fd;
  background: rgba(168,85,247,.18); border: 1rpx solid rgba(168,85,247,.35);
}
.set-btn:active { opacity: .8; }
/* 行内开关：与顶栏设备电源开关 (.power-switch) 同风格同尺寸，靠右对齐 */
.tip-switch {
  margin-left: auto; flex-shrink: 0;
  width: 72rpx; height: 40rpx; border-radius: 20rpx;
  background: rgba(255,255,255,.12);
  position: relative;
  transition: background .25s;
}
.tip-knob {
  position: absolute; top: 4rpx; left: 4rpx;
  width: 32rpx; height: 32rpx; border-radius: 50%;
  background: #fff;
  transition: transform .25s;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,.3);
}
.tip-switch.on {
  background: #a855f7;
  box-shadow: 0 0 12rpx rgba(168,85,247,.4);
}
.tip-switch.on .tip-knob { transform: translateX(32rpx); }

/* ====== DIY 灯珠编辑器 ====== */
.diy-leds-wrap { width: 100%; white-space: nowrap; }
.diy-leds { display: inline-flex; flex-wrap: nowrap; padding: 4rpx 8rpx 16rpx; }
.diy-led {
  width: 44rpx; height: 44rpx; margin: 4rpx;
  border-radius: 8rpx; flex-shrink: 0;
  border: 2rpx solid rgba(255,255,255,.15);
  font-size: 16rpx; color: rgba(255,255,255,.5);
  display: flex; align-items: center; justify-content: center;
  box-sizing: border-box;
}
.diy-led.sel { border-color: #a855f7; box-shadow: 0 0 12rpx rgba(168,85,247,.6); }
/* 分组（每 20 颗一组）：行首组按钮固定，灯珠区可横向拖动 */
.diy-groups { padding: 6rpx 4rpx; }
.diy-row { display: flex; align-items: center; margin-bottom: 12rpx; }
.grp-btn {
  width: 104rpx; flex-shrink: 0; margin-right: 12rpx;
  padding: 12rpx 0; border-radius: 12rpx;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  background: rgba(255,255,255,.06);
  border: 2rpx solid rgba(255,255,255,.14);
}
.grp-btn:active { background: rgba(255,255,255,.14); }
.grp-btn.on { background: rgba(168,85,247,.3); border-color: rgba(168,85,247,.65); }
.grp-t { font-size: 26rpx; color: rgba(255,255,255,.8); }
.grp-n { font-size: 18rpx; color: rgba(255,255,255,.4); margin-top: 4rpx; }
/* 组内灯珠：2 行 × 10 列，每颗占容器宽 10%（用底色边框做缝隙），任何屏宽都精确 10 颗/行 */
.grp-leds { flex: 1; display: flex; flex-wrap: wrap; align-content: flex-start; }
.diy-led.sm {
  width: 10%; height: 48rpx;
  margin: 0;                             /* 必须清零：基础 .diy-led 带 4rpx margin 会挤掉第 10 颗 */
  border: 3rpx solid #111121;            /* 与卡片底色同色，形成灯珠间隙 */
  border-radius: 6rpx;
  box-sizing: border-box; flex-shrink: 0;
}
.diy-led.sm:active { transform: scale(.88); }
.diy-led.grp-on { border-color: rgba(168,85,247,.55); }

/* 一键填充预设（3 列） */
.preset-grid {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 14rpx; padding: 12rpx 8rpx 4rpx;
}
.preset-btn {
  box-sizing: border-box; text-align: center;
  padding: 16rpx 0; border-radius: 14rpx;
  font-size: 24rpx; color: rgba(255,255,255,.65);
  background: rgba(255,255,255,.05);
  border: 1rpx solid rgba(255,255,255,.1);
}
.preset-btn:active { background: rgba(168,85,247,.18); color: #c4b5fd; }

.diy-cur { display: flex; align-items: center; gap: 16rpx; padding: 10rpx 8rpx; }
.muted2 { font-size: 24rpx; color: rgba(255,255,255,.5); }
.diy-cur-color {
  width: 56rpx; height: 56rpx; border-radius: 12rpx;
  border: 2rpx solid rgba(255,255,255,.2);
}
.palette { display: flex; flex-wrap: wrap; gap: 14rpx; padding: 8rpx; }
.pal {
  width: 56rpx; height: 56rpx; border-radius: 12rpx;
  border: 2rpx solid rgba(255,255,255,.2);
}
.pal:active { transform: scale(.92); }
.diy-quick { display: flex; gap: 16rpx; padding: 12rpx 8rpx 4rpx; }
.qbtn {
  padding: 10rpx 26rpx; border-radius: 999rpx;
  font-size: 24rpx; color: rgba(255,255,255,.7);
  background: rgba(255,255,255,.06); border: 1rpx solid rgba(255,255,255,.12);
}
.qbtn:active { opacity: .8; }
.qbtn.save {
  display: flex; align-items: center; justify-content: center;
  margin: 16rpx 0 20rpx; padding: 18rpx 0;
  font-size: 28rpx; color: #c4b5fd;
  background: rgba(168,85,247,.12); border-color: rgba(168,85,247,.4);
}
.custom-list .set-btn { color: #ff8787; background: rgba(239,68,68,.12); border-color: rgba(239,68,68,.35); }
.set-input {
  margin-left: auto; width: 160rpx; text-align: right;
  font-size: 28rpx; color: #e8e8f0;
}

/* ====== 手机麦克风律动 ====== */
.btn-stop { background: linear-gradient(90deg, #ef4444, #f97316); box-shadow: 0 8rpx 24rpx rgba(239,68,68,.3); }
.mic-meter {
  margin-top: 20rpx; height: 28rpx; border-radius: 14rpx;
  background: rgba(255,255,255,.06); overflow: hidden;
}
.mic-fill {
  height: 100%; width: 0;
  background: linear-gradient(90deg, #22c55e, #eab308, #ef4444);
  transition: width .08s linear;
}
.mic-level-text {
  display: block; margin-top: 10rpx;
  font-size: 24rpx; color: rgba(255,255,255,.55); text-align: right;
}

.mic-modes { display: flex; gap: 14rpx; margin-top: 20rpx; flex-wrap: wrap; }
.mic-mode {
  padding: 12rpx 30rpx; border-radius: 999rpx;
  font-size: 26rpx; color: rgba(255,255,255,.5);
  background: rgba(255,255,255,.05);
}
.mic-mode.active { background: rgba(168,85,247,.25); color: #c4b5fd; font-weight: 500; }
.mic-tip {
  display: block; margin-top: 18rpx;
  font-size: 22rpx; line-height: 1.6; color: rgba(255,255,255,.35);
}
.music-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 18rpx;
  padding: 8rpx 0 12rpx;
}
.music-item {
  width: 100%;
  box-sizing: border-box;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 16rpx 12rpx 18rpx; border-radius: 22rpx;
  background: linear-gradient(135deg, #141426, #111121);
  border: 1rpx solid rgba(255,255,255,.06);
  box-shadow: 0 6rpx 24rpx rgba(0,0,0,.25);
  transition: all .18s;
}
.music-item:active { transform: scale(.97); }
.music-item.active {
  background: linear-gradient(135deg, rgba(168,85,247,.18), rgba(124,58,237,.10));
  border-color: rgba(168,85,247,.45);
  box-shadow: 0 0 24rpx rgba(168,85,247,.18);
}
.music-icon {
  width: 72rpx; height: 72rpx; border-radius: 18rpx;
  background: rgba(255,255,255,.06);
  display: flex; align-items: center; justify-content: center;
  font-size: 38rpx; margin-bottom: 12rpx;
}
/* 律动模式封面图：铺满卡片宽度（对齐小程序视觉，aspectFill 裁切不变形） */
.music-thumb {
  width: 100%; height: 150rpx; border-radius: 16rpx;
  margin-bottom: 12rpx; border: none; background: rgba(255,255,255,.04);
}
.music-item.active .music-thumb {
  box-shadow: 0 0 20rpx rgba(168,85,247,.45);
}
.music-name {
  font-size: 28rpx; color: #e8e8f0; font-weight: 500;
}
</style>
