/**
 * ble.js —— Light_RGBYW BLE 通信层（多连接）
 *
 * 职责：BLE 适配器初始化、设备扫描/过滤、多设备并发连接、特征值发现、
 *      写指令（含 MTU 分包 + 累加和校验）、读通知、请求/响应关联。
 *
 * 连接模型：以 deviceId 为 key 维护多条并发连接（手机 BLE 栈支持多连接），
 *           上层按 deviceId 调用 connect / write / disconnect。
 *
 * 数据帧：报头(0x55 APP→设备 / 0x56 设备→APP) | 功能码 | 序列号 | 长度 | 数据 | 校验码
 *  - 序列号默认 0xFF；数据超单包时从 0x01 起分包，末包 0xFF
 *  - 校验码 = 对(报头+功能码+序列号+长度+数据)累加和折叠 8bit 后取反
 */

import proto from './protocol';
import deviceType from './deviceType';

// 实时日志：真机日志可在「小程序后台 → 开发 → 开发管理 → 运维中心 → 实时日志」查询
let rtLogger = null;
try {
  if (typeof wx !== 'undefined' && wx.getRealtimeLogManager) rtLogger = wx.getRealtimeLogManager();
} catch (e) { /* ignore */ }

const SERVICE_UUID = '0000FFF0-0000-1000-8000-00805F9B34FB';
const WRITE_UUID = '0000FFF3-0000-1000-8000-00805F9B34FB';
const NOTIFY_UUID = '0000FFF4-0000-1000-8000-00805F9B34FB';

const HEADER_APP = 0x55;
const HEADER_DEV = 0x56;

// 自动连接超时（ms）：超过该时间仍未连接成功则放弃，转由用户手动连接
const AUTO_CONNECT_TIMEOUT = 12000;

class BLEManager {
  constructor() {
    // deviceId -> { connected, serviceId, writeChar, notifyChar, pending:{} }
    this.connections = {};
    // 单包最大数据字节（20 字节 MTU 时：20 - 6 帧头尾 = 14）
    this.maxData = 14;
    this.adapterReady = false;
    this._discovered = {};   // deviceId -> true（扫描去重）
    this._scanCb = null;
    this._notifyCbs = [];    // [(deviceId, packet, meta{solicited}) => {}] 设备上报监听（可多订阅）
    this._connCb = null;     // (res{dviceId,connected}) => {}
    this.debug = true;       // 设备上报数据日志开关（见 setDebug）
    this.logBuffer = [];     // 内存日志环形缓冲（真机无控制台时可通过 getLogs() 展示/导出）
    this.logBufferMax = 300;
    this._connecting = {};
    this._connectQueue = Promise.resolve();
    this._reconnects = {};
    this._connectGenerations = {};
    this._intentionalDisconnect = {};
    this._connCbs = [];
  }

  // ===== 日志 =====
  setDebug(on) { this.debug = !!on; }

  // 统一日志出口：console + 实时日志 + 内存缓冲（真机均可查）
  _log(text, level) {
    if (!this.debug) return;
    if (level === 'warn') console.warn(text);
    else console.log(text);
    this.logBuffer.push(text);
    if (this.logBuffer.length > this.logBufferMax) this.logBuffer.shift();
    if (rtLogger) {
      try { rtLogger[level === 'warn' ? 'warn' : 'info'](text); } catch (e) { /* ignore */ }
    }
  }

  // 获取内存中的日志（最近 logBufferMax 条），供页面展示或导出
  getLogs() { return this.logBuffer.slice(); }

  clearLogs() { this.logBuffer.length = 0; }

  subscribeConnectionChange(cb) {
    if (typeof cb !== 'function') return () => {};
    this._connCbs.push(cb);
    return () => {
      const index = this._connCbs.indexOf(cb);
      if (index >= 0) this._connCbs.splice(index, 1);
    };
  }

  _notifyConnectionChange(res) {
    this._connCbs.slice().forEach((cb) => { try { cb(res); } catch (e) { this._log('[BLE] connection callback failed', 'warn'); } });
    if (this._connCb) { try { this._connCb(res); } catch (e) { this._log('[BLE] legacy connection callback failed', 'warn'); } }
  }

  _pad(n, w) {
    const s = String(n);
    return s.length >= w ? s : new Array(w - s.length + 1).join('0') + s;
  }

  _now() {
    const d = new Date();
    return this._pad(d.getHours(), 2) + ':' + this._pad(d.getMinutes(), 2)
      + ':' + this._pad(d.getSeconds(), 2) + '.' + this._pad(d.getMilliseconds(), 3);
  }

  _hex2(v) {
    const s = ((v || 0) & 0xff).toString(16).toUpperCase();
    return s.length < 2 ? '0' + s : s;
  }

  _hex(arr) {
    let s = '';
    for (let i = 0; i < arr.length; i++) { if (i) s += ' '; s += this._hex2(arr[i]); }
    return s;
  }

  // 统一错误文本：uni 各 API 的 fail 对象形态不一致（errMsg / message / 字符串）
  _fmtErr(e) {
    if (!e) return '未知错误';
    if (typeof e === 'string') return e;
    return e.errMsg || e.message || String(e);
  }

  // 特征属性可读化：真机日志与诊断面板用于判断 write / writeNoResponse / notify
  _propsText(c) {
    const p = (c && c.properties) || {};
    const names = ['read', 'write', 'notify', 'indicate', 'writeNoResponse', 'writeDefault'].filter((k) => p[k]);
    if (names.length) return names.join('|');
    if (c && c.isNotifying != null) return 'notify=' + c.isNotifying;
    return '-';
  }

  // 设备控制页的 BLE 诊断信息（连接参数、写/通知特征及属性）
  getDiagText(deviceId) {
    const conn = this._getConnection(deviceId);
    if (!conn) return 'dev=' + deviceId + ' (未连接)';
    const lines = [];
    lines.push('dev=' + deviceId);
    lines.push('connected=' + conn.connected + ' mtu=' + (conn.mtu || '-') + ' notifyReady=' + conn.notifyReady);
    lines.push('writeChar=' + conn.writeChar + ' @ ' + conn.serviceId + ' type=' + (conn.writeType || 'auto'));
    lines.push('notifyChar=' + conn.notifyChar + ' @ ' + conn.notifyService);
    lines.push('统计: txOk=' + (conn.txOk || 0) + ' txFail=' + (conn.txFail || 0)
      + ' rxBytes=' + (conn.rxBytes || 0) + ' rxFrames=' + (conn.rxFrames || 0)
      + ' rxParseFail=' + (conn.rxParseFail || 0) + ' rxBuf=' + ((conn.rxBuf && conn.rxBuf.length) || 0));
    if (conn.lastRxAt) lines.push('lastRx=' + new Date(conn.lastRxAt).toLocaleTimeString() + ' (' + (Date.now() - conn.lastRxAt) + 'ms 前)');
    if (conn.writeCombo) lines.push('writeCombo=' + JSON.stringify(conn.writeCombo));
    (conn.allChars || []).forEach((c) => {
      lines.push('char ' + c.uuid + ' [' + this._propsText(c.raw) + ']');
    });
    return lines.join('\n');
  }

  // 校验：对除校验码外的整帧求校验和，与帧尾校验码比对
  _csOK(packet) {
    if (!packet || packet.length < 5) return false;
    return this._checksum(packet.slice(0, packet.length - 1)) === packet[packet.length - 1];
  }

  /**
   * 打印设备上报帧日志
   * solicited=true 表示是对某条下发指令的响应，false 表示设备主动上报
   */
  _logRx(deviceId, packet, solicited) {
    if (!this.debug) return;
    const func = packet[1] || 0;
    const seq = packet[2] || 0;
    const len = packet[3] || 0;
    // STATUS(0x00) 回包无结果字节，其余功能码首字节为返回结果
    const hasResult = func !== proto.CMD.STATUS;
    const result = hasResult && packet.length > 4 ? packet[4] : null;
    // 设备回包 len 语义不统一（数据长度 / 整帧长度），统一按帧尾校验码位置截取数据段
    const end = packet.length > 5 ? packet.length - 1 : packet.length;
    const data = packet.slice(hasResult ? 5 : 4, end);

    this._log('[BLE][RX] ' + this._now()
      + ' dev=' + deviceId
      + ' func=0x' + this._hex2(func) + '(' + (proto.CMD_NAME[func] || 'UNKNOWN') + ')'
      + ' seq=0x' + this._hex2(seq)
      + ' len=' + len
      + ' cs=' + (this._csOK(packet) ? 'OK' : 'ERR')
      + (solicited ? ' [响应]' : ' [主动上报]')
      + '\n  raw : ' + this._hex(packet)
      + '\n  data: ' + (data.length ? this._hex(data) : '(空)')
      + (result !== null ? '  result=0x' + this._hex2(result) + '(' + proto.parseResult(result).msg + ')' : ''));
  }

  // ===== 基础 =====
  isSupport() {
    return typeof wx !== 'undefined' && wx.openBluetoothAdapter;
  }

  _p(fn, obj) {
    return new Promise((resolve, reject) => {
      fn(Object.assign({}, obj, { success: resolve, fail: reject }));
    });
  }

  async init() {
    if (!this.isSupport()) throw new Error('当前环境不支持 BLE');
    try {
      await this._p(wx.openBluetoothAdapter);
    } catch (e) {
      // 已开启时也会进 fail，忽略
    }
    this.adapterReady = true;
    this._bindGlobalListeners();
    // 注意：wx.setBLEMTU 必须带 deviceId，只能在建立连接后按连接调用（见 connect），此处无法协商
    return true;
  }

  _bindGlobalListeners() {
    if (this._bound) return;
    this._bound = true;
    wx.onBLECharacteristicValueChange((res) => this._onValueChange(res));
    wx.onBLEConnectionStateChange((res) => this._onConnectionStateChange(res));
    if (wx.onBluetoothAdapterStateChange) wx.onBluetoothAdapterStateChange((res) => this._onAdapterStateChange(res));
  }

  // ===== 扫描 =====
  // 注意：不要传 services 过滤！本品牌设备把类型 ID 放在 0xFF 厂商数据里，
  // 广播包里未必挂 FFF0 服务 UUID，传 services 会导致大量设备进不了回调。
  // 改为全量扫描，再按 0xFF 厂商数据判定是否本品牌。
  async startScan(onDevice) {
    if (Object.values(this.connections).some((conn) => conn && conn.connected)) {
      throw Object.assign(new Error('设备正在控制中，请停止控制后再扫描'), { kind: 'busy' });
    }
    // 先确保上一次发现会话完全停止，否则系统不会重复上报已缓存的设备
    try { await this._p(wx.stopBluetoothDevicesDiscovery); } catch (e) { /* ignore */ }
    // 清掉旧监听器，避免多次 startScan 后监听器堆积
    try { wx.offBluetoothDeviceFound(); } catch (e) { /* ignore */ }
    this._scanCb = onDevice;
    this._discovered = {};
    // allowDuplicatesKey: true → 让系统持续上报所有设备（含已见过的）
    // 去重由 _discovered 自己处理，不依赖系统级缓存
    await this._p(wx.startBluetoothDevicesDiscovery, {
      allowDuplicatesKey: true,
      interval: 500,
    });
    wx.onBluetoothDeviceFound((res) => {
      (res.devices || []).forEach((d) => this._safeHandleFound(d));
    });
    // 立即拉取系统已缓存的设备列表（部分安卓机 stop/start 后只靠此途径能拿到旧设备）
    try {
      const cached = await this._p(wx.getBluetoothDevices);
      (cached.devices || []).forEach((d) => this._safeHandleFound(d));
    } catch (e) { /* ignore */ }
  }

  // 单台设备的广播处理异常不得中断其它设备的上报
  _safeHandleFound(d) {
    try {
      this._handleFound(d);
    } catch (e) {
      console.error('[BLE] 处理广播设备异常', e, d && d.deviceId);
    }
  }

  _handleFound(d) {
    if (!d || !d.deviceId) return;
    if (this._discovered[d.deviceId]) return;
    this._discovered[d.deviceId] = true;
    const adv = this._parseAdvertise(d.advertisData);
    const isRGBYW = !!(adv && adv.typeId);
    const rawHex = d.advertisData ? this._hex(Array.from(new Uint8Array(d.advertisData))) : '';
    const device = {
      deviceId: d.deviceId,
      name: d.name || d.localName || '未知设备',
      rssi: d.RSSI,
      isRGBYW,                       // 是否本品牌（解析到合法类型ID）
      mac: adv ? adv.mac : '',       // 广播中的 MAC（6 字节）
      typeId: adv ? adv.typeId : null,
      model: adv ? adv.model : '',
      ledCount: adv ? adv.ledCount : 0,
      vendorId: adv ? adv.vendorId : 0,
      config: adv ? adv.config : 0,
      raw: adv || null,              // 广播解析结果（调试/展示用）
      advHex: rawHex,                // 广播原始数据 hex（诊断解析问题用）
    };
    // 广播原始数据日志：用于核对解析偏移（每设备仅首次发现时打印一次）
    this._log('[BLE][ADV] ' + device.name + ' rssi=' + d.RSSI
      + '\n  raw : ' + (rawHex || '(无广播数据)')
      + '\n  解析: ' + (adv ? JSON.stringify(adv) : '未匹配到 0xFF 厂商段'));
    if (this._scanCb) this._scanCb(device);
  }

  stopScan() {
    this._scanCb = null;
    try { wx.offBluetoothDeviceFound(); } catch (e) { /* ignore */ }
    if (this.adapterReady) {
      wx.stopBluetoothDevicesDiscovery({ fail() {} });
    }
  }

  // 解析广播包（0xFF 厂商数据段：保留FF FF | MAC 6B | 保留 | 类型ID | 型号 | 灯珠数 | 厂商ID | 保留）
  //
  // 类型 ID 探测顺序（以《广播数据包定义》为准，兼容现场固件）：
  //   ① 文档布局：Byte[10..11] = 2 字节编号（大类 0x1000 光类 / 0x2000 动类 / 0x3000 感类 / 0x4000 能类
  //      + 小类 0x00–0xFF），后续字段后移 1 字节：型号 Byte[12..21]、灯珠数 Byte[22..23]、
  //      厂商ID Byte[24..27]、配置 Byte[28]；同时兼容大端(20 09)与小端(09 20)
  //   ② 现场固件变体：类型 2 字节位于 Byte[9..10]（MAC 后保留缩为 1 字节），
  //      型号/灯珠/厂商偏移与旧 1 字节格式一致
  //   ③ 旧固件：Byte[10] = 1 字节品类号，型号 Byte[11..20]、灯珠数 Byte[21..22]、厂商ID Byte[23..26]
  // 广播形态兼容：
  //   A. 完整 AD 结构 [0x1E 长度][0xFF 功能码][数据段]
  //   B. 仅数据段 [0xFF 保留][0xFF 保留]...——微信 advertisData 已剥离长度/功能码（实测如此）
  _parseAdvertise(buffer) {
    if (!buffer) return null;
    const u = new Uint8Array(buffer);
    for (let i = 0; i < u.length - 12; i++) {
      const isFullAD = u[i] === 0x1e && u[i + 1] === 0xff;
      const isDataOnly = u[i] === 0xff && u[i + 1] === 0xff;
      if (!isFullAD && !isDataOnly) continue;
      const p = isFullAD ? u.subarray(i + 2) : u.subarray(i);

      const readStr = (off, len) => {
        let s = '';
        for (let k = 0; k < len; k++) { if (p[off + k]) s += String.fromCharCode(p[off + k]); }
        return s;
      };
      // MAC：数据段 Byte[2..7]（6 字节，按原始字节顺序拼接）
      const macBytes = p.subarray(2, 8);
      const mac = macBytes.length === 6
        ? Array.prototype.map.call(macBytes, (b) => this._hex2(b)).join(':')
        : '';

      // ① 文档布局：类型 2 字节位于 Byte[10..11]，后续字段整体后移 1 字节
      //    字节序兼容：先按大端（20 09）试，再按小端（09 20）试
      if (p.length >= 12) {
        const be = ((p[10] || 0) << 8) | (p[11] || 0);
        const le = ((p[11] || 0) << 8) | (p[10] || 0);
        let typeId2 = 0;
        let order = '';
        if (deviceType.DEVICE_TYPES[be]) { typeId2 = be; order = 'BE(20 09)'; }
        else if (deviceType.DEVICE_TYPES[le]) { typeId2 = le; order = 'LE(09 20)'; }
        if (typeId2) {
          return {
            mac,
            typeId: typeId2,
            byteOrder: order,
            model: readStr(12, 10),
            ledCount: ((p[22] || 0) << 8) | (p[23] || 0),
            vendorId: ((p[24] || 0) << 24) | ((p[25] || 0) << 16) | ((p[26] || 0) << 8) | (p[27] || 0),
            config: p[28] || 0,
          };
        }
      }
      // ② 现场固件变体：类型 2 字节位于 Byte[9..10]（MAC 后保留缩为 1 字节），
      //    型号/灯珠/厂商偏移与旧 1 字节格式一致（型号 p[11]、灯珠 p[21]、厂商 p[23]）
      if (p.length >= 27) {
        const tc = ((p[9] || 0) << 8) | (p[10] || 0);
        if (deviceType.DEVICE_TYPES[tc]) {
          return {
            mac,
            typeId: tc,
            byteOrder: 'TYPE@[9..10]',
            model: readStr(11, 10),
            ledCount: ((p[21] || 0) << 8) | (p[22] || 0),
            vendorId: ((p[23] || 0) << 24) | ((p[24] || 0) << 16) | ((p[25] || 0) << 8) | (p[26] || 0),
            config: p[27] || 0,
          };
        }
      }
      // 旧格式：1 字节品类号（需在旧→新映射表中，防其它厂商误匹配）
      if (p.length >= 27) {
        const legacyId = p[10] || 0;
        const mapped = deviceType.LEGACY_TO_TYPE[legacyId];
        if (mapped) {
          return {
            mac,
            typeId: mapped, // 统一归一化为 2 字节编号
            byteOrder: 'LEGACY(1B)',
            model: readStr(11, 10),
            ledCount: ((p[21] || 0) << 8) | (p[22] || 0),
            vendorId: ((p[23] || 0) << 24) | ((p[24] || 0) << 16) | ((p[25] || 0) << 8) | (p[26] || 0),
            config: p[27] || 0,
          };
        }
      }
    }
    return null;
  }

  // ===== 连接（多设备并发） =====
  isConnected(deviceId) {
    const c = this._getConnection(deviceId);
    return !!(c && c.connected);
  }

  getConnectedList() {
    return Object.keys(this.connections).filter((id) => this.connections[id].connected);
  }

  // 连接键归一化：uni 的 notify / 状态回调里 deviceId 大小写可能与连接时不一致
  _connectionKey(deviceId) {
    if (this.connections[deviceId]) return deviceId;
    const lower = String(deviceId || '').toLowerCase();
    return Object.keys(this.connections).find((id) => String(id).toLowerCase() === lower) || null;
  }

  _getConnection(deviceId) {
    const key = this._connectionKey(deviceId);
    return key ? this.connections[key] : null;
  }

  connect(deviceId, timeout = 10000, opts = {}) {
    const current = this.connections[deviceId];
    if (current && current.connected) return Promise.resolve(true);
    if (this._connecting[deviceId]) return this._connecting[deviceId];
    if (!opts.internalReconnect && !opts.internalRecovery) {
      this._cancelReconnect(deviceId);
      // 用户/页面主动重连时清除"主动断开"标记，否则自动重连会被拦掉
      delete this._intentionalDisconnect[deviceId];
    }
    const generation = (this._connectGenerations[deviceId] || 0) + 1;
    this._connectGenerations[deviceId] = generation;
    const cleanup = () => {
      const conn = this.connections[deviceId];
      if (conn && conn.generation === generation) {
        this._rejectPending(conn, 'BLE 连接建立失败');
        delete this.connections[deviceId];
      }
    };
    const run = this._connectQueue.then(async () => {
      if (this._connectGenerations[deviceId] !== generation) throw Object.assign(new Error('连接请求已取消'), { kind: 'connection' });
      try {
        return await this._connectOne(deviceId, timeout, opts, generation);
      } catch (error) {
        cleanup();
        try { await this._p(wx.closeBLEConnection, { deviceId }); } catch (_) { /* ignore */ }
        // 自检/通知失败：系统可能还残留上一次 GATT 连接。
        // 注意：重试必须在当前队列槽内完成，不能在队列链的 catch 里递归 connect —— 会死锁。
        if ((error.kind === 'notify' || error.kind === 'connection') && !opts.retriedHandshake && !opts.skipRetry) {
          await new Promise((r) => setTimeout(r, 500));
          if (this._connectGenerations[deviceId] !== generation) throw Object.assign(new Error('连接请求已取消'), { kind: 'connection' });
          try {
            return await this._connectOne(deviceId, timeout, Object.assign({}, opts, { retriedHandshake: true }), generation);
          } catch (e2) {
            cleanup();
            try { await this._p(wx.closeBLEConnection, { deviceId }); } catch (_) { /* ignore */ }
            throw e2;
          }
        }
        throw error;
      }
    });
    this._connectQueue = run.catch(() => {});
    this._connecting[deviceId] = run;
    return run.finally(() => {
      if (this._connecting[deviceId] === run) delete this._connecting[deviceId];
    });
  }

  async _connectOne(deviceId, timeout, opts, generation) {
    const assertCurrent = () => {
      if (this._connectGenerations[deviceId] !== generation) throw Object.assign(new Error('连接请求已取消'), { kind: 'connection' });
    };
    assertCurrent();
    const existing = this.connections[deviceId];
    if (existing && existing.connected) return true;
    // 蓝牙开关被关过再打开时适配器需要重新初始化，否则后续连接全部失败
    if (!this.adapterReady) {
      try {
        await this.init();
        this._log('[BLE][CONN] 适配器已重新初始化');
      } catch (e) {
        this._log('[BLE][CONN] 适配器重新初始化失败: ' + this._fmtErr(e), 'warn');
      }
      assertCurrent();
    }
    const conn = {
      connected: false, serviceId: null, writeChar: null, notifyChar: null, notifyReady: false,
      pending: {}, generation, queue: [], sending: false,
      strategy: { skipMtu: !!opts.skipMtu, deferNotify: !!opts.deferNotify, mtuSize: opts.mtuSize || 247 },
    };
    this.connections[deviceId] = conn;

    // 建链重试：Android 上偶发 133/10003（系统 GATT 忙、旧连接未释放），退避后重连通常可恢复。
    // 单次硬超时 6s、最多 2 次，避免系统不回调时页面长时间卡在"正在连接"。
    const attemptsMax = 2;
    const hardTimeout = Math.min(timeout || 10000, 6000);
    let connectError = null;
    for (let attempt = 0; attempt < attemptsMax; attempt++) {
      assertCurrent();
      try {
        // 系统层连接可能既不成功也不回报失败（一直 pending），必须加硬超时
        await this._withTimeout(this._p(wx.createBLEConnection, { deviceId, timeout }), hardTimeout, '建链超时');
        connectError = null;
        break;
      } catch (e) {
        connectError = e;
        this._log('[BLE][CONN] 建链失败(第' + (attempt + 1) + '/' + attemptsMax + '次): ' + this._fmtErr(e), 'warn');
        if (/取消|cancel/i.test(this._fmtErr(e))) break;
        // 先释放系统侧的半开连接，再退避重试，否则下一次仍会 133
        try { await this._p(wx.closeBLEConnection, { deviceId }); } catch (_) { /* ignore */ }
        if (attempt < attemptsMax - 1) await new Promise((resolve) => setTimeout(resolve, 300));
      }
    }
    if (connectError) {
      if (this.connections[deviceId] === conn) delete this.connections[deviceId];
      try { await this._p(wx.closeBLEConnection, { deviceId }); } catch (_) { /* ignore */ }
      throw connectError;
    }

    // MTU 必须在服务/特征发现之前协商：部分机型在 GATT 发现之后再设 MTU 会失败，
    // 仍按 23 字节（净荷 20）工作，23 字节状态帧就收不全。
    // skipMtu：写入自愈重建连接时跳过，避免再次触发同样问题。
    if (!conn.strategy.skipMtu && wx.setBLEMTU) {
      try {
        const r = await this._withTimeout(this._p(wx.setBLEMTU, { deviceId, mtu: conn.strategy.mtuSize }), 4000, 'setBLEMTU 超时');
        conn.mtu = (r && r.mtu) || conn.strategy.mtuSize;
        this._log('[BLE] MTU 协商成功 mtu=' + conn.mtu + ' dev=' + deviceId);
      } catch (e) {
        conn.mtu = 23;
        this._log('[BLE] MTU 协商失败（默认净荷 20）：' + this._fmtErr(e), 'warn');
      }
      assertCurrent();
    } else if (conn.strategy.skipMtu) {
      this._log('[BLE] 本次连接跳过 MTU 协商（skipMtu）');
    }

    const svcRes = await this._withTimeout(this._p(wx.getBLEDeviceServices, { deviceId }), 5000, '服务发现超时');
    assertCurrent();
    const services = svcRes.services || [];
    const service = services.find((s) => s.uuid.toUpperCase() === SERVICE_UUID.toUpperCase()) || services[0];
    if (!service) { delete this.connections[deviceId]; throw new Error('未找到目标服务'); }

    // 特征发现：先在主服务找 FFF3(写)/FFF4(通知)；部分固件把两者分散在不同服务，
    // 故再遍历其余服务补全。所有特征都记录到 allChars，作为写失败时的候选。
    const charsOf = async (svcUuid) => {
      try {
        const r = await this._withTimeout(this._p(wx.getBLEDeviceCharacteristics, { deviceId, serviceId: svcUuid }), 4000, '特征发现超时');
        return r.characteristics || [];
      } catch (e) { return []; }
    };
    const findByUuid = (list, uuid) =>
      list.find((c) => (c.uuid || '').toUpperCase() === uuid.toUpperCase()) || null;
    const allChars = [];
    const collectChars = (svcUuid, list) => {
      (list || []).forEach((c) => {
        if (c && c.uuid) allChars.push({ serviceId: svcUuid, uuid: c.uuid, properties: c.properties || {}, raw: c });
      });
    };

    let write = null; let notify = null;
    let writeSvc = service.uuid; let notifySvc = service.uuid;
    const mainChars = await charsOf(service.uuid);
    collectChars(service.uuid, mainChars);
    write = findByUuid(mainChars, WRITE_UUID);
    notify = findByUuid(mainChars, NOTIFY_UUID);
    for (let i = 0; i < services.length && (!write || !notify); i++) {
      if (services[i].uuid === service.uuid) continue;
      const cs = await charsOf(services[i].uuid);
      collectChars(services[i].uuid, cs);
      if (!write) { const w = findByUuid(cs, WRITE_UUID); if (w) { write = w; writeSvc = services[i].uuid; } }
      if (!notify) { const n = findByUuid(cs, NOTIFY_UUID); if (n) { notify = n; notifySvc = services[i].uuid; } }
    }
    // 补齐未遍历服务的特征（写候选需要完整列表）
    for (let i = 0; i < services.length; i++) {
      if (allChars.some((c) => c.serviceId === services[i].uuid)) continue;
      collectChars(services[i].uuid, await charsOf(services[i].uuid));
    }
    if (!notify) {
      notify = mainChars.find((c) => c.properties && c.properties.notify) || null;
      if (notify) notifySvc = service.uuid;
    }
    if (!notify) {
      // 试探：逐特征尝试开启通知，找到真正可通知的特征（部分固件不上报 notify 属性）
      for (let i = 0; i < allChars.length && !notify; i++) {
        const c = allChars[i];
        try {
          // 试探必须带超时：某些特征写 CCCD 后系统不回调，会把连接流程永远挂住
          await this._withTimeout(this._p(wx.notifyBLECharacteristicValueChange, {
            deviceId, serviceId: c.serviceId, characteristicId: c.uuid, state: true,
          }), 1200, '试探通知超时');
          notify = c.raw; notifySvc = c.serviceId;
          conn.notifyPreEnabled = true;
          this._log('[BLE] 未匹配到 FFF4，试探开启通知成功: ' + c.uuid);
        } catch (e) { /* 该特征不支持通知，继续试下一个 */ }
      }
      if (!notify) this._log('[BLE] 已试探特征均无通知能力: ' + allChars.map((c) => c.uuid).join(','), 'warn');
    }
    if (!write) {
      // 兜底：FFF3 不存在时，改用任意声明了写属性的特征，避免写入报 property not support
      const anyWritable = allChars.find((c) => c.properties && (c.properties.write || c.properties.writeNoResponse));
      if (anyWritable) {
        write = anyWritable.raw; writeSvc = anyWritable.serviceId;
        this._log('[BLE][CONN] 未找到 FFF3，改用可写特征 ' + write.uuid + ' 服务=' + writeSvc, 'warn');
      }
    }
    if (!write) { delete this.connections[deviceId]; throw new Error('未找到写特征'); }
    if (!notify) this._log('[BLE] 未找到可通知特征：设备主动上报（遥控/按键状态）无法接收', 'warn');

    conn.serviceId = writeSvc;
    conn.notifyService = notifySvc;
    conn.writeChar = write.uuid;
    conn.notifyChar = notify ? notify.uuid : null;
    conn.allChars = allChars;
    conn.services = services.map((s) => s.uuid);
    // 首选写入方式由特征属性决定（属性可能缺失，缺失时留空由写入层自动试）
    const writeProps = write.properties || {};
    if (writeProps.write) conn.writeType = 'write';
    else if (writeProps.writeNoResponse) conn.writeType = 'writeNoResponse';
    // 支持无响应写时，高频实时流优先走 writeNoResponse：不占 GATT 事务，避免高频率下排队/10008
    conn.supportNoResponse = !!writeProps.writeNoResponse;

    // 写候选：主写特征 → 声明可写特征 → 全部特征（个别固件属性上报为空），写入时逐个试
    const candidates = [];
    const addCandidate = (svcUuid, charId) => {
      if (!charId) return;
      if (conn.notifyChar && charId.toUpperCase() === conn.notifyChar.toUpperCase()) return;
      const key = svcUuid + '|' + charId;
      if (candidates.some((c) => c.key === key)) return;
      candidates.push({ key, serviceId: svcUuid, charId });
    };
    addCandidate(writeSvc, write.uuid);
    allChars.filter((c) => (c.properties && (c.properties.write || c.properties.writeNoResponse)))
      .forEach((c) => addCandidate(c.serviceId, c.uuid));
    allChars.forEach((c) => addCandidate(c.serviceId, c.uuid));
    conn.writeCandidates = candidates;
    this._log('[BLE][CONN] dev=' + deviceId
      + ' services=' + conn.services.join(',')
      + '\n  mainChars=' + mainChars.map((c) => c.uuid + '[' + this._propsText(c) + ']').join(',')
      + '\n  writeChar=' + write.uuid + '[' + this._propsText(write) + ']'
      + ' notifyChar=' + (notify ? notify.uuid + '[' + this._propsText(notify) + ']' : 'null')
      + '\n  写候选(' + candidates.length + '): ' + candidates.map((c) => c.charId).join(','));

    if (conn.strategy.deferNotify) {
      conn.notifyReady = false;
      this._log('[BLE] 本次连接延后开启 notify（deferNotify），待首帧写通后补开');
      conn.connected = true;
      this._notifyConnectionChange({ deviceId, connected: true });
      return true;
    }

    if (conn.notifyChar) {
      // CCCD 修改是连接最后一步的 GATT 操作，增加超时保护和连接代次校验。
      // 试探阶段已成功开启过通知的特征无需重复开启。
      try {
        if (!conn.notifyPreEnabled) {
          await this._withTimeout(this._p(wx.notifyBLECharacteristicValueChange, {
            deviceId, serviceId: conn.notifyService || conn.serviceId,
            characteristicId: conn.notifyChar, state: true,
          }), 3500, '开启通知超时');
        }
        await new Promise((resolve) => setTimeout(resolve, 250));
        assertCurrent();
        conn.notifyReady = true;
      } catch (e) {
        if (e && e.kind === 'connection') throw e;
        this._log('[BLE] 开启通知失败：' + this._fmtErr(e), 'warn');
        conn.notifyReady = false;
        throw Object.assign(new Error('BLE 通知订阅失败，请重新连接以保证回包'), { kind: 'notify', cause: e });
      }
    }
    assertCurrent();
    conn.connected = true;
    // 链路自检：设备断电重启后，安卓可能仍报"已连接"但 GATT/CCCD 已失效，
    // 不做校验就会出现"显示已连接、控制全无回包"。这里主动发一帧状态查询确认。
    const alive = await this._handshake(deviceId, conn, opts);
    if (!alive) {
      conn.connected = false;
      throw Object.assign(new Error('BLE 链路自检失败：设备未响应，请重新连接'), { kind: 'notify' });
    }
    this._notifyConnectionChange({ deviceId, connected: true });
    return true;
  }

  // 连接建立后的链路自检（有回包才算真正连上）
  async _handshake(deviceId, conn, opts = {}) {
    if (!conn.notifyReady || opts.skipHandshake) return true;
    conn.handshaking = true;
    try {
      for (let i = 0; i < 2; i++) {
        try {
          await this.write(deviceId, proto.CMD.STATUS, [], 1500);
          conn.lastRxAt = Date.now();
          conn.linkFail = 0;
          this._log('[BLE][CONN] 链路自检通过 dev=' + deviceId);
          return true;
        } catch (e) {
          this._log('[BLE][CONN] 链路自检失败(' + (i + 1) + '/2): ' + this._fmtErr(e), 'warn');
          if (i === 0) await this._reenableNotify(deviceId, conn);
        }
      }
      return false;
    } finally {
      conn.handshaking = false;
    }
  }

  // 链路体检：发一帧状态查询，连续失败则强制重建连接（用于"显示已连接但无回包"）
  async verifyLink(deviceId) {
    const key = this._connectionKey(deviceId) || deviceId;
    const conn = this.connections[key];
    if (!conn || !conn.connected) return false;
    try {
      await this.write(key, proto.CMD.STATUS, [], 1500);
      conn.linkFail = 0;
      return true;
    } catch (e) {
      conn.linkFail = (conn.linkFail || 0) + 1;
      this._log('[BLE] 链路体检失败(' + conn.linkFail + '): ' + this._fmtErr(e), 'warn');
      if (conn.linkFail >= 2) {
        conn.linkFail = 0;
        this.forceReconnect(key);
      }
      return false;
    }
  }

  // 强制重建连接：先彻底关闭再重连，让安卓丢弃失效的 GATT/CCCD 缓存
  async forceReconnect(deviceId) {
    const key = this._connectionKey(deviceId) || deviceId;
    if (this._forcing) this._forcing = this._forcing || {};
    if (this._forcing[key]) return this._forcing[key];
    this._forcing[key] = (async () => {
      this._log('[BLE] 链路异常，强制重建连接 dev=' + key);
      this._intentionalDisconnect[key] = true;
      const conn = this.connections[key];
      if (conn) this._rejectPending(conn, 'BLE 链路重建中');
      try { await this._p(wx.closeBLEConnection, { deviceId: key }); } catch (e) { /* ignore */ }
      delete this.connections[key];
      delete this._intentionalDisconnect[key];
      await new Promise((r) => setTimeout(r, 500));
      try {
        const ok = await this.connect(key, AUTO_CONNECT_TIMEOUT, { internalRecovery: true });
        this._log('[BLE] 强制重建' + (ok ? '成功' : '未完成') + ' dev=' + key);
        return ok;
      } catch (e) {
        this._log('[BLE] 强制重建失败: ' + this._fmtErr(e), 'warn');
        return false;
      }
    })().finally(() => { delete this._forcing[key]; });
    return this._forcing[key];
  }

  _withTimeout(promise, ms, label) {
    let timer;
    return Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label)), ms); })])
      .finally(() => clearTimeout(timer));
  }

  // 补开通知通道：部分机型长时间空闲后 CCCD 失效，表现为"能写但不回包"
  async _reenableNotify(deviceId, conn) {
    if (!conn || !conn.notifyChar) return false;
    try {
      await this._withTimeout(this._p(wx.notifyBLECharacteristicValueChange, {
        deviceId,
        serviceId: conn.notifyService || conn.serviceId,
        characteristicId: conn.notifyChar,
        state: true,
      }), 3000, '恢复通知超时');
      await new Promise((resolve) => setTimeout(resolve, 120));
      conn.notifyReady = true;
      this._log('[BLE] 已重新开启通知通道 dev=' + deviceId);
      return true;
    } catch (e) {
      this._log('[BLE] 重新开启通知失败：' + this._fmtErr(e), 'warn');
      return false;
    }
  }

  _cancelReconnect(deviceId) {
    const state = this._reconnects[deviceId];
    if (!state) return;
    state.cancelled = true;
    if (state.timer) clearTimeout(state.timer);
    delete this._reconnects[deviceId];
  }

  _rejectPending(conn, message) {
    if (!conn || !conn.pending) return;
    Object.keys(conn.pending).forEach((func) => {
      const pending = conn.pending[func];
      clearTimeout(pending.timer);
      delete conn.pending[func];
      pending.reject(Object.assign(new Error(message), { kind: 'connection' }));
    });
  }

  // ===== 帧封装 =====
  // 校验码：对(包头+包体)累加和取低 8 位后取反
  // ⚠️ 实测设备（qh-bt-light）用 (~(sum & 0xff))，不做进位折叠，两者在产生进位时差 1
  _checksum(bytes) {
    let sum = 0;
    for (let i = 0; i < bytes.length; i++) sum = (sum + bytes[i]) & 0xff;
    return (~sum) & 0xff;
  }

  _frame(func, data, seq) {
    const pre = [HEADER_APP, func, seq, 0x05 + data.length].concat(data);
    pre.push(this._checksum(pre));
    return pre;
  }

  _toAB(arr) {
    const buf = new ArrayBuffer(arr.length);
    const v = new Uint8Array(buf);
    for (let i = 0; i < arr.length; i++) v[i] = arr[i] & 0xff;
    return buf;
  }

  // 组帧（含 MTU 分包）
  _buildFrames(func, data) {
    const payload = (data || []).slice();
    const frames = [];
    if (payload.length <= this.maxData) {
      frames.push(this._frame(func, payload, 0xff));
    } else {
      let seq = 1;
      for (let i = 0; i < payload.length; i += this.maxData) {
        const chunk = payload.slice(i, i + this.maxData);
        const isLast = i + this.maxData >= payload.length;
        frames.push(this._frame(func, chunk, isLast ? 0xff : seq++));
      }
    }
    return frames;
  }

  // ===== 写指令 + 等待响应（普通控制）=====
  write(deviceId, func, data = [], timeout = 3000) {
    const key = this._connectionKey(deviceId) || deviceId;
    const conn = this.connections[key];
    if (!conn || !conn.connected || !conn.writeChar) return Promise.reject(new Error('设备未连接'));
    if (!conn.notifyReady) return Promise.reject(Object.assign(new Error('设备通知通道未就绪'), { kind: 'notify' }));
    const frames = this._buildFrames(func, data);
    this._log('[BLE][TX] ' + this._now() + ' dev=' + key + ' func=0x' + this._hex2(func) + ' frames=' + frames.length + '\n  ' + frames.map((f) => this._hex(f)).join('\n  '));
    // 串行化：同一连接上的指令顺次发送，避免并发写把 BLE 栈打满
    let retried = false;
    const attempt = () => new Promise((resolve, reject) => this._startWrite(key, func, frames, timeout, resolve, reject));
    const run = () => attempt()
      .then((packet) => { conn.timeoutStreak = 0; conn.notifyRecovered = false; return packet; })
      .catch(async (err) => {
        if (!err || err.kind !== 'timeout') throw err;
        // 链路自检阶段不做恢复动作，由 _connectOne/connect 的失败重连统一处理
        if (conn.handshaking) throw err;
        conn.timeoutStreak = (conn.timeoutStreak || 0) + 1;
        this._log('[BLE] 无回包(连续' + conn.timeoutStreak + '次) func=0x' + this._hex2(func), 'warn');
        // 连续 3 次无回包、且当前没有律动实时流量时才重建连接：
        // 律动期间偶发一次超时不代表掉线，贸然重连会把正在工作的连接直接掐断
        if (conn.timeoutStreak >= 3 && !retried && !conn.rtRunning && conn.cmdActive <= 1) {
          retried = true;
          conn.timeoutStreak = 0;
          this._log('[BLE] 连续无回包，重建连接后自动重试');
          this.disconnect(key);
          await new Promise((resolve) => setTimeout(resolve, 400));
          try {
            const ok = await this.connect(key, AUTO_CONNECT_TIMEOUT, { skipMtu: true, internalRecovery: true });
            if (ok) return attempt();
          } catch (e) {
            this._log('[BLE] 重建连接失败: ' + this._fmtErr(e), 'warn');
          }
          throw err;
        }
        // 首次无回包：补开通知通道后重试一次（律动进行中不动 GATT，避免打断实时流）
        if (!conn.notifyRecovered && !retried && !conn.rtRunning) {
          retried = true;
          conn.notifyRecovered = true;
          if (await this._reenableNotify(key, conn)) return attempt();
        }
        throw err;
      });
    const chained = (conn.commandChain || Promise.resolve()).then(run, run);
    conn.commandChain = chained.catch(() => {});
    return chained;
  }

  _startWrite(deviceId, func, frames, timeout, resolve, reject) {
    const conn = this.connections[deviceId];
    if (!conn || !conn.connected) return reject(Object.assign(new Error('BLE 连接已断开'), { kind: 'connection' }));
    const previous = conn.pending[func];
    if (previous) { clearTimeout(previous.timer); delete conn.pending[func]; previous.reject(Object.assign(new Error('同功能请求被替换'), { kind: 'superseded' })); }
    // 在飞指令计数：实时通道据此让路，避免与指令抢 GATT 造成 10008
    conn.cmdActive = (conn.cmdActive || 0) + 1;
    let settled = false;
    const settle = (fn, arg) => {
      if (settled) return;
      settled = true;
      conn.cmdActive = Math.max(0, (conn.cmdActive || 1) - 1);
      fn(arg);
    };
    const pending = {
      resolve: (packet) => settle(resolve, packet),
      reject: (error) => settle(reject, error),
      timer: null,
    };
    pending.timer = setTimeout(() => {
      if (conn.pending[func] === pending) delete conn.pending[func];
      pending.reject(Object.assign(new Error('指令超时(func=0x' + func.toString(16) + ')'), { kind: 'timeout' }));
    }, timeout);
    conn.pending[func] = pending;
    this._sendFrames(deviceId, frames, 0).catch((error) => {
      if (conn.pending[func] === pending) { clearTimeout(pending.timer); delete conn.pending[func]; pending.reject(error); }
    });
  }

  // ===== 高频实时指令（音乐律动/拖动调色等）=====
  // 独立节拍发送器：同功能只保留最新值，不同功能各留一帧（音量 / 色相）。
  //  1) 不挂在指令链上，避免高频调用让 Promise 链无限增长、延迟越积越大；
  //  2) 有普通指令在飞时让路，避免 10008 系统忙；
  //  3) 写失败只丢这一帧，绝不触发属性探测或自愈重连（否则开律动就掉线）。
  writeNoWait(deviceId, func, data = []) {
    const key = this._connectionKey(deviceId) || deviceId;
    const conn = this.connections[key];
    if (!conn || !conn.connected || !conn.writeChar) return false;
    if (!conn.rtQueue) conn.rtQueue = [];
    const exist = conn.rtQueue.findIndex((it) => it.func === func);
    if (exist >= 0) conn.rtQueue[exist] = { func, data };
    else if (conn.rtQueue.length < 6) conn.rtQueue.push({ func, data });
    this._restartRealtime(key, conn);
    return true;
  }

  _restartRealtime(key, conn) {
    if (conn.rtRunning || !conn.connected || !conn.rtQueue || !conn.rtQueue.length) return;
    conn.rtRunning = true;
    const gap = conn.rtGap || 55;
    (async () => {
      try {
        while (conn.connected && conn.rtQueue.length) {
          if (conn.cmdActive > 0) { await new Promise((r) => setTimeout(r, 20)); continue; }
          const item = conn.rtQueue.shift();
          const frames = this._buildFrames(item.func, item.data);
          for (let i = 0; i < frames.length; i++) {
            const ok = await this._writeSilent(key, conn, frames[i]);
            if (!ok) break;
          }
          await new Promise((r) => setTimeout(r, gap));
        }
      } finally {
        conn.rtRunning = false;
        if (conn.connected && conn.rtQueue.length) this._restartRealtime(key, conn);
      }
    })();
  }

  // 实时通道专用写入：失败只返回 false，不做属性探测、不切换写特征、不自愈重连
  async _writeSilent(deviceId, conn, chunk) {
    const base = conn.writeCombo || {
      serviceId: conn.serviceId,
      charId: conn.writeChar,
      writeType: conn.writeType || null,
    };
    const combos = [];
    // 高频流优先无响应写：不占 GATT 事务，避免律动期间排队与 10008
    if (conn.supportNoResponse && base.writeType !== 'writeNoResponse') {
      combos.push({ serviceId: base.serviceId, charId: base.charId, writeType: 'writeNoResponse' });
    }
    combos.push(base);
    for (let i = 0; i < combos.length; i++) {
      const combo = combos[i];
      try {
        await this._throttle(conn);
        const param = { deviceId, serviceId: combo.serviceId, characteristicId: combo.charId, value: this._toAB(chunk) };
        if (combo.writeType) param.writeType = combo.writeType;
        await this._p(wx.writeBLECharacteristicValue, param);
        conn.writeCombo = combo;
        conn.lastTxAt = Date.now();
        conn.txOk = (conn.txOk || 0) + 1;
        conn.rtFailStreak = 0;
        return true;
      } catch (e) {
        if (i === combos.length - 1) this._silentFail(conn, e);
      }
    }
    return false;
  }

  _silentFail(conn, e) {
    conn.txFail = (conn.txFail || 0) + 1;
    conn.rtFailStreak = (conn.rtFailStreak || 0) + 1;
    // 只在连续失败时记一条，避免高频日志拖慢律动
    if (conn.rtFailStreak === 1 || conn.rtFailStreak % 20 === 0) {
      this._log('[BLE][TX-NOW] 写失败(' + conn.rtFailStreak + '): ' + this._fmtErr(e), 'warn');
    }
    return false;
  }

  // 发送节流：固件解析与写 flash 较慢，连续写太快会丢帧或返回 10008（系统忙）
  async _throttle(conn) {
    const gap = conn.minTxGap || 25;
    const wait = (conn.lastTxAt || 0) + gap - Date.now();
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  }

  // 有序发送一整批"不等待回包"的帧（DIY 分批、分段数据等）。
  // 与 writeNoWait 的区别：这类数据每帧都是有效数据，必须全部按顺序送达，
  // 不能像滑块/律动那样"只保留最新一帧"，否则只有最后一批生效。
  writeBurst(deviceId, frames) {
    const key = this._connectionKey(deviceId) || deviceId;
    const conn = this.connections[key];
    if (!conn || !conn.connected || !conn.writeChar) return false;
    if (!Array.isArray(frames) || !frames.length) return false;
    if (!conn.burstQueue) conn.burstQueue = [];
    frames.forEach((f) => {
      if (f && f.func != null) conn.burstQueue.push({ func: f.func, data: f.data || [] });
    });
    if (conn.burstRunning) return true;
    conn.burstRunning = true;
    const drain = async () => {
      // 批量下发期间让实时通道让路，避免 DIY/分段数据与律动帧互相抢 GATT
      conn.cmdActive = (conn.cmdActive || 0) + 1;
      try {
        while (conn.burstQueue.length) {
          if (!conn.connected) break;
          const item = conn.burstQueue.shift();
          const chunks = this._buildFrames(item.func, item.data);
          this._log('[BLE][TX-BURST] ' + this._now() + ' dev=' + key + ' func=0x' + this._hex2(item.func)
            + ' 剩余=' + conn.burstQueue.length);
          for (let i = 0; i < chunks.length; i++) {
            try {
              await this._writeChunk(key, conn, chunks[i]);
            } catch (e) {
              this._log('[BLE][TX-BURST] 写失败 func=0x' + this._hex2(item.func) + ': ' + this._fmtErr(e), 'warn');
              break;
            }
            if (i < chunks.length - 1) await new Promise((resolve) => setTimeout(resolve, 20));
          }
          // 帧间留出固件解析与写 flash 的时间
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
      } finally {
        conn.cmdActive = Math.max(0, (conn.cmdActive || 1) - 1);
        conn.burstRunning = false;
        // 收尾期间又追加的帧，重新开一轮，避免被吞掉
        if (conn.burstQueue.length) {
          const rest = conn.burstQueue.splice(0);
          this.writeBurst(key, rest);
        }
      }
    };
    const chained = (conn.commandChain || Promise.resolve()).then(drain, drain);
    conn.commandChain = chained.catch(() => {});
    return true;
  }

  async _sendFrames(deviceId, frames, idx) {
    if (idx >= frames.length) return;
    const conn = this.connections[deviceId];
    if (!conn || !conn.connected || this._connectGenerations[deviceId] !== conn.generation) throw Object.assign(new Error('BLE 连接已断开'), { kind: 'connection' });
    conn.lastTrafficAt = Date.now();
    try {
      await this._writeChunk(deviceId, conn, frames[idx]);
    } catch (e) {
      const pending = conn.pending[frames[idx][1]];
      if (pending) { clearTimeout(pending.timer); delete conn.pending[frames[idx][1]]; pending.reject(e); }
      throw e;
    }
    if (idx < frames.length - 1) {
      await new Promise((resolve) => setTimeout(resolve, 30));
      return this._sendFrames(deviceId, frames, idx + 1);
    }
  }

  // ===== 单包写入（写特征 / 写入方式自动回退）=====
  // 真机差异：① FFF3 未声明 write 属性；② Android 部分机型只接受 writeNoResponse。
  // 按「已缓存组合 → 主写特征 → 候选特征」×「默认 / write / writeNoResponse」逐级尝试，
  // 成功的组合缓存到 conn.writeCombo，后续直接复用，避免每次控制都重新试错。
  async _writeChunk(deviceId, conn, chunk) {
    if (!conn || !conn.connected) {
      const err = new Error('设备未连接');
      err.kind = 'write';
      throw err;
    }

    const tryWrite = async (combo) => {
      await this._throttle(conn);
      const value = this._toAB(chunk);
      if (combo.viaPlus) {
        if (typeof plus === 'undefined' || !plus.bluetooth || !plus.bluetooth.writeBLECharacteristicValue) {
          throw new Error('plus.bluetooth 写入通道不可用');
        }
        const res = await new Promise((resolve, reject) => {
          plus.bluetooth.writeBLECharacteristicValue(deviceId, combo.serviceId, combo.charId, value,
            () => resolve(true), (e) => reject(e || new Error('plus.bluetooth write fail')));
        });
        conn.lastTxAt = Date.now();
        return res;
      }
      const param = { deviceId, serviceId: combo.serviceId, characteristicId: combo.charId, value };
      if (combo.writeType) param.writeType = combo.writeType;
      const res = await this._p(wx.writeBLECharacteristicValue, param);
      conn.lastTxAt = Date.now();
      return res;
    };

    if (conn.writeCombo) {
      try {
        await tryWrite(conn.writeCombo);
        conn.writeFailStreak = 0;
        conn.txOk = (conn.txOk || 0) + 1;
        return;
      } catch (e) {
        this._log('[BLE] 缓存写入组合失效: ' + this._fmtErr(e), 'warn');
        conn.writeCombo = null;
      }
    }

    // 写入方式候选：以特征属性推导的首选开头，其余作为回退。
    // 注意：这里只切"写入方式"，不切"写特征"——切到别的特征会写入静默成功、设备永不回包。
    const writeTypes = [];
    const pushType = (t) => { if (writeTypes.indexOf(t) < 0) writeTypes.push(t); };
    pushType(conn.writeType || null);
    pushType('write');
    pushType('writeNoResponse');
    pushType(null);

    let lastError = null;
    for (let ti = 0; ti < writeTypes.length; ti++) {
      const combo = { serviceId: conn.serviceId, charId: conn.writeChar, writeType: writeTypes[ti] };
      try {
        await tryWrite(combo);
        conn.writeCombo = combo;
        conn.txOk = (conn.txOk || 0) + 1;
        conn.writeFailStreak = 0;
        if (writeTypes[ti]) this._log('[BLE] 写入方式: ' + writeTypes[ti] + ' char=' + conn.writeChar);
        return;
      } catch (e) {
        lastError = e;
        conn.txFail = (conn.txFail || 0) + 1;
        const msg = this._fmtErr(e);
        this._log('[BLE] 写入失败 char=' + conn.writeChar + ' type=' + (writeTypes[ti] || 'auto') + ': ' + msg, 'warn');
        if (/not connected|disconnected|-1$|10006/i.test(msg)) break;
        await new Promise((resolve) => setTimeout(resolve, ti === 0 ? 60 : 160));
      }
    }

    // 仅当系统明确回报"该特征不支持写入"时，才在同一服务内换成声明可写的特征
    if (/property not support/i.test(this._fmtErr(lastError))) {
      const repaired = await this._repairWriteChar(deviceId, conn);
      if (repaired) {
        const combos = [conn.writeType || null, 'write', 'writeNoResponse', null];
        for (let i = 0; i < combos.length; i++) {
          try {
            const combo = { serviceId: conn.serviceId, charId: conn.writeChar, writeType: combos[i] };
            await tryWrite(combo);
            conn.writeCombo = combo;
            conn.txOk = (conn.txOk || 0) + 1;
            this._log('[BLE] 修复后写入成功 char=' + conn.writeChar + ' type=' + (combos[i] || 'auto'));
            return;
          } catch (e) { lastError = e; }
        }
      }
    }

    // uni 层写入被拦截时的原生通道兜底
    if (typeof plus !== 'undefined' && plus.bluetooth && plus.bluetooth.writeBLECharacteristicValue) {
      try {
        const combo = { serviceId: conn.serviceId, charId: conn.writeChar, viaPlus: true };
        await tryWrite(combo);
        conn.writeCombo = combo;
        this._log('[BLE] 已切换到 plus.bluetooth 原生写入通道');
        return;
      } catch (e) {
        lastError = e;
        this._log('[BLE] plus.bluetooth 写入也失败: ' + this._fmtErr(e), 'warn');
      }
    }

    // 自愈：只有"连续多次"写入全失败才重建连接（单次失败多为系统忙，重建反而制造掉线）
    conn.writeFailStreak = (conn.writeFailStreak || 0) + 1;
    if (!conn.recovered && conn.writeFailStreak >= 3) {
      conn.recovered = true;
      this._log('[BLE] 连续 ' + conn.writeFailStreak + ' 次写入失败，执行自愈：重建连接');
      conn.writeFailStreak = 0;
      try {
        this.disconnect(deviceId);
        await new Promise((resolve) => setTimeout(resolve, 600));
        await this.connect(deviceId, 10000, { skipMtu: true, internalRecovery: true });
        const fresh = this.connections[deviceId];
        if (fresh && fresh.connected && fresh.notifyReady) {
          const err = new Error('BLE 已自动恢复连接，请重试本次控制');
          err.kind = 'connection';
          throw err;
        }
      } catch (e) {
        if (e && e.kind === 'connection') throw e;
        lastError = e;
        this._log('[BLE] 自愈重建后仍写入失败: ' + this._fmtErr(e), 'warn');
      }
    }

    const error = new Error('写入失败：' + this._fmtErr(lastError) + '\n' + this.getDiagText(deviceId) + '\nlen=' + chunk.length);
    error.kind = 'write';
    error.raw = lastError;
    error.errCode = lastError && lastError.errCode;
    throw error;
  }

  // 写特征属性修复：只有"当前特征确实不支持写"时才会调用。
  // 只允许在同一服务内换成声明了 write / writeNoResponse 的特征，绝不跨服务乱切。
  async _repairWriteChar(deviceId, conn) {
    try {
      const res = await this._p(wx.getBLEDeviceCharacteristics, { deviceId, serviceId: conn.serviceId });
      const list = (res && res.characteristics) || [];
      this._log('[BLE] 刷新特征属性 service=' + conn.serviceId + ' : '
        + list.map((c) => c.uuid + '[' + this._propsText(c) + ']').join(','));
      const current = String(conn.writeChar || '').toUpperCase();
      const writable = list.filter((c) => c.properties && (c.properties.write || c.properties.writeNoResponse));
      if (!writable.length) return false;
      const next = writable.find((c) => (c.uuid || '').toUpperCase() !== current) || writable[0];
      conn.writeType = (next.properties && next.properties.write) ? 'write' : 'writeNoResponse';
      if ((next.uuid || '').toUpperCase() !== current) {
        this._log('[BLE] 写特征切换(当前不支持写入): ' + conn.writeChar + ' -> ' + next.uuid);
        conn.writeChar = next.uuid;
      }
      conn.writeCombo = null;
      return true;
    } catch (e) {
      this._log('[BLE] 刷新特征失败: ' + this._fmtErr(e), 'warn');
      return false;
    }
  }

  // 收包重组：notify 可能把一帧拆成多条通知，也可能把多帧合成一条。
  // 统一先入缓冲区，再按「帧头 + 长度 + 校验」切出完整帧；
  // 长度语义（len=数据长度 → 帧长 len+5；len=整帧长度 → 帧长 len）用校验结果判定。
  _pumpRx(deviceId, conn, chunk) {
    if (!conn.rxBuf) conn.rxBuf = [];
    conn.rxBytes = (conn.rxBytes || 0) + chunk.length;
    conn.rxBuf = conn.rxBuf.concat(chunk);
    const frames = [];
    for (;;) {
      if (conn.rxBuf.length < 5) break;
      if (conn.rxBuf[0] !== HEADER_DEV) {
        const idx = conn.rxBuf.indexOf(HEADER_DEV);
        if (idx < 0) { conn.rxBuf = []; break; }
        conn.rxBuf = conn.rxBuf.slice(idx);
        continue;
      }
      const lenField = conn.rxBuf[3] || 0;
      const primary = lenField + 5;
      if (primary >= 6 && primary <= 512) {
        if (conn.rxBuf.length < primary) break;   // 分包还没到齐，等下一包
        const frame = conn.rxBuf.slice(0, primary);
        if (this._csOK(frame)) {
          frames.push(frame);
          conn.rxBuf = conn.rxBuf.slice(primary);
          continue;
        }
      }
      // 固件变体：len 字段就是整帧长度
      if (lenField >= 6 && lenField <= 512 && conn.rxBuf.length >= lenField) {
        const frame = conn.rxBuf.slice(0, lenField);
        if (this._csOK(frame)) {
          frames.push(frame);
          conn.rxBuf = conn.rxBuf.slice(lenField);
          continue;
        }
      }
      // 当前字节不是合法帧：丢 1 字节重新找帧头，避免死等
      conn.rxParseFail = (conn.rxParseFail || 0) + 1;
      conn.rxBuf = conn.rxBuf.slice(1);
    }
    if (frames.length) {
      conn.rxFrames = (conn.rxFrames || 0) + frames.length;
      conn.lastRxAt = Date.now();
    }
    return frames;
  }

  // 通知按 deviceId 路由到对应连接（逐帧处理，兼容拆包/粘包）
  _onValueChange(res) {
    const u = new Uint8Array(res.value);
    const buf = Array.from(u);
    if (!buf.length) return;
    const deviceId = this._connectionKey(res.deviceId) || res.deviceId;
    const conn = this.connections[deviceId];
    if (!conn) {
      this._log('[BLE][RX-RAW] 收到未匹配连接的数据 dev=' + deviceId + '\n  raw : ' + this._hex(buf), 'warn');
      return;
    }

    const frames = this._pumpRx(deviceId, conn, buf);
    if (!frames.length) {
      // 还没拼成完整帧（多为分包）：记录原始字节，便于判断是丢包还是解析问题
      this._log('[BLE][RX-RAW] 分包累计 dev=' + deviceId + ' buf=' + conn.rxBuf.length
        + '\n  chunk: ' + this._hex(buf), 'warn');
      return; // 仅处理设备→APP
    }
    frames.forEach((packet) => {
      const func = packet[1];
      const pend = conn.pending[func];
      this._logRx(deviceId, packet, !!pend);
      if (pend) {
        clearTimeout(pend.timer);
        delete conn.pending[func];
        pend.resolve(packet);
      }
      if (this._notifyCbs.length) {
        const meta = { solicited: !!pend };
        this._notifyCbs.slice().forEach((cb) => cb(deviceId, packet, meta));
      }
    });
  }

  _onAdapterStateChange(res) {
    this.adapterReady = !!(res && res.available);
    if (this.adapterReady) return;
    const ids = new Set(Object.keys(this.connections).concat(Object.keys(this._connecting)));
    ids.forEach((deviceId) => {
      this._connectGenerations[deviceId] = (this._connectGenerations[deviceId] || 0) + 1;
      this._onConnectionStateChange({ deviceId, connected: false, errMsg: 'Bluetooth adapter unavailable' });
    });
  }

  // 连接状态变化（含自动掉线）按 deviceId 维护
  _onConnectionStateChange(res) {
    const deviceId = this._connectionKey(res.deviceId) || res.deviceId;
    const conn = this.connections[deviceId];
    if (conn) conn.connected = res.connected;
    if (res.connected && conn) {
      conn.connected = true;
      this._notifyConnectionChange(res);
      return;
    }
    if (!res.connected) {
      if (conn) {
        this._rejectPending(conn, 'BLE 连接已断开');
      }
      delete this.connections[deviceId];
      const intentional = this._intentionalDisconnect[deviceId];
      if (!intentional && !this._connecting[deviceId]) this._scheduleReconnect(deviceId);
    } else if (!conn && !this._connecting[deviceId]) {
      this._log('[BLE] 忽略过期 connected 回调 device=' + deviceId, 'warn');
      return;
    }
    this._notifyConnectionChange(res);
  }

  _scheduleReconnect(deviceId) {
    if (!deviceId || this._reconnects[deviceId] || this._intentionalDisconnect[deviceId]) return;
    const state = this._reconnects[deviceId] = { attempts: 0, timer: null, cancelled: false };
    const attempt = async () => {
      if (this._reconnects[deviceId] !== state || state.cancelled) return;
      if (this.connections[deviceId] && this.connections[deviceId].connected) { delete this._reconnects[deviceId]; return; }
      if (state.attempts >= 5) { this._log('[BLE][RECONNECT] 已暂停，需手动重连 device=' + deviceId, 'warn'); delete this._reconnects[deviceId]; return; }
      state.attempts++;
      try {
        // 前两次照常协商 MTU（状态帧才能整包到达）；连续失败后再跳过 MTU 避免陷入死循环
        const opts = state.attempts >= 3
          ? { skipMtu: true, internalReconnect: true }
          : { internalReconnect: true };
        await this.connect(deviceId, AUTO_CONNECT_TIMEOUT, opts);
        if (this._reconnects[deviceId] !== state || state.cancelled) { this.disconnect(deviceId); return; }
        delete this._reconnects[deviceId];
        this._notifyConnectionChange({ deviceId, connected: true, reconnect: true });
      } catch (e) {
        if (this._reconnects[deviceId] !== state || state.cancelled) return;
        this._log('[BLE][RECONNECT] 失败：' + (e.errMsg || e.message || e), 'warn');
        state.timer = setTimeout(attempt, Math.min(1000 * Math.pow(2, state.attempts - 1), 12000));
      }
    };
    state.timer = setTimeout(attempt, 800);
  }

  // 注册设备上报监听：遥控/按键操作后设备主动回传的状态帧、以及指令应答都会回调
  // meta.solicited = true 表示这是对某条指令的应答（已由 write() 的 Promise 消费）；
  // UI 同步场景一般只处理 solicited=false 的主动上报，避免重复刷新
  // 返回取消订阅函数（页面 onUnload 调用，防止页面销毁后回调泄漏）
  onNotify(cb) {
    if (typeof cb !== 'function') return () => {};
    this._notifyCbs.push(cb);
    const that = this;
    return function off() {
      const i = that._notifyCbs.indexOf(cb);
      if (i >= 0) that._notifyCbs.splice(i, 1);
    };
  }
  onConnectionChange(cb) { this._connCb = cb; }

  disconnect(deviceId) {
    if (!deviceId) return;
    this._connectGenerations[deviceId] = (this._connectGenerations[deviceId] || 0) + 1;
    this._cancelReconnect(deviceId);
    this._intentionalDisconnect[deviceId] = true;
    const conn = this.connections[deviceId];
    if (conn) {
      this._rejectPending(conn, 'BLE 连接已主动断开');
      delete this.connections[deviceId];
    }
    try { wx.closeBLEConnection({ deviceId, fail() {} }); } catch (e) { /* ignore */ }
    setTimeout(() => { delete this._intentionalDisconnect[deviceId]; }, 1500);
    this._notifyConnectionChange({ deviceId, connected: false, intentional: true });
  }

  disconnectAll() {
    const ids = new Set(Object.keys(this.connections).concat(Object.keys(this._connecting), Object.keys(this._reconnects)));
    ids.forEach((id) => this.disconnect(id));
    Object.keys(this._reconnects).forEach((id) => this._cancelReconnect(id));
  }

  close() {
    this.disconnectAll();
    if (this.adapterReady) wx.closeBluetoothAdapter({ fail() {} });
    this.adapterReady = false;
  }
}

const ble = new BLEManager();
export { ble, AUTO_CONNECT_TIMEOUT, BLEManager, SERVICE_UUID, WRITE_UUID, NOTIFY_UUID };
export default ble;
